import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig, type Plugin } from 'vite';
import fs from 'node:fs';
import path from 'node:path';
import {
  PUBLIC_LEGAL_LIST,
  SITE_URL,
  renderPublicLegalHtml,
} from './src/pages/publicLegalPages';

/**
 * Pré-renderiza /privacy-policy e /terms como HTML estático em dist/, para que
 * robôs (ex.: verificação Google OAuth) leiam o conteúdo sem executar JavaScript.
 * Gera dist/<slug>/index.html (Vercel / Express / Pages) e dist/<slug>.html
 * (URL limpa no Cloudflare Pages, sem redirecionamentos). Na abertura no browser,
 * a aplicação React assume e mostra a mesma página.
 */
function prerenderLegalPages(): Plugin {
  let dist = path.resolve(process.cwd(), 'dist');
  return {
    name: 'prerender-public-legal-pages',
    apply: 'build',
    configResolved(config) {
      dist = path.resolve(config.root, config.build.outDir);
    },
    closeBundle() {
      const indexPath = path.join(dist, 'index.html');
      if (!fs.existsSync(indexPath)) return;
      const template = fs.readFileSync(indexPath, 'utf-8');
      const rootRe = /<div id="root">[\s\S]*?<\/div>\s*(?=<script|<\/body>)/;
      for (const page of PUBLIC_LEGAL_LIST) {
        const url = `${SITE_URL}${page.path}`;
        let html = template
          .replace(/<title>[\s\S]*?<\/title>/, `<title>${page.docTitle}</title>`)
          .replace(/(<meta name="description" content=")[^"]*(")/, `$1${page.description}$2`)
          .replace(/(<meta property="og:title" content=")[^"]*(")/, `$1${page.docTitle}$2`)
          .replace(/(<meta property="og:description" content=")[^"]*(")/, `$1${page.description}$2`)
          .replace(/(<link rel="canonical" href=")[^"]*(")/, `$1${url}$2`)
          .replace(/(<meta property="og:url" content=")[^"]*(")/, `$1${url}$2`);
        if (!rootRe.test(html)) throw new Error('prerender: #root não encontrado em dist/index.html');
        html = html.replace(rootRe, () => `<div id="root">${renderPublicLegalHtml(page)}</div>\n    `);
        fs.mkdirSync(path.join(dist, page.slug), { recursive: true });
        fs.writeFileSync(path.join(dist, page.slug, 'index.html'), html);
        fs.writeFileSync(path.join(dist, `${page.slug}.html`), html);
      }
    },
  };
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss(), prerenderLegalPages()],
  build: {
    sourcemap: false,
  },
  server: {
    // HMR is disabled in AI Studio via DISABLE_HMR env var.
    // Do not modify—file watching is disabled to prevent flickering during agent edits.
    hmr: process.env.DISABLE_HMR !== 'true',
    // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
    watch: process.env.DISABLE_HMR === 'true' ? null : {},
  },
});
