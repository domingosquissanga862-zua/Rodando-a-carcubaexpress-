-- =============================================================================
-- CARCUBAEXPRESS COMÉRCIO — ENDURECIMENTO DE SEGURANÇA DA BASE DE DADOS (RLS)
-- Data: 2026-11-05
--
-- OBJECTIVO
--   * Só o administrador domingosquissanga862@gmail.com pode criar/editar/apagar
--     produtos, categorias, configurações, despesas e gerir pedidos e utilizadores.
--   * Visitantes: apenas LEEM produtos, categorias e configurações da loja.
--   * Clientes com conta: só vêem e criam os SEUS pedidos e só editam o SEU perfil.
--   * Remove TODAS as políticas abertas/antigas (ex.: "Permitir tudo em categorias",
--     despesas abertas a qualquer cliente, pedidos legíveis por anónimos, etc.).
--
-- COMO USAR (ler antes!)
--   1. Faça uma cópia de segurança (Database > Backups) e guarde o resultado de:
--        select * from pg_policies where schemaname='public';
--   2. Cole este script inteiro no SQL Editor e execute UMA vez.
--      Corre numa única transacção: se algo falhar, NADA é alterado.
--   3. Execute as verificações no fim do ficheiro.
--
-- EFEITOS NA LOJA (esperados)
--   * Seguimento de pedido SEM sessão iniciada deixa de funcionar (era uma fuga de
--     dados: qualquer pessoa lia todos os pedidos). Com sessão iniciada, o cliente
--     vê os seus pedidos. Para voltar a permitir seguimento a convidados com
--     segurança é preciso uma função própria + alteração no código (pedir à parte).
--   * O checkout exige sessão iniciada (já era assim na aplicação).
--
-- NÃO altera: dados, colunas, utilizadores do Auth, chaves, URLs ou credenciais.
-- =============================================================================

BEGIN;

-- -----------------------------------------------------------------------------
-- 1. FUNÇÃO is_admin(): SÓ o e-mail oficial do administrador (sessão autenticada)
--    Não confia em user_metadata (editável pelo próprio utilizador) nem em colunas
--    "role" de tabelas públicas. Lê o e-mail diretamente de auth.users.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT COALESCE(
    auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM auth.users u
      WHERE u.id = auth.uid()
        AND LOWER(TRIM(u.email)) = 'domingosquissanga862@gmail.com'
    ),
    FALSE
  );
$$;

REVOKE ALL ON FUNCTION public.is_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_admin() TO anon, authenticated;

-- -----------------------------------------------------------------------------
-- 2. LIMPAR TODAS AS POLÍTICAS EXISTENTES das tabelas da loja (nomes antigos
--    e abertas incluídos) e garantir RLS ligado em todas.
-- -----------------------------------------------------------------------------
DO $$
DECLARE
  r RECORD;
  t TEXT;
BEGIN
  FOR r IN
    SELECT schemaname, tablename, policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN ('products','categories','store_settings','expenses',
                        'orders','order_items','users','profiles')
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', r.policyname, r.schemaname, r.tablename);
  END LOOP;

  FOREACH t IN ARRAY ARRAY['products','categories','store_settings','expenses',
                           'orders','order_items','users','profiles']
  LOOP
    IF to_regclass('public.' || t) IS NOT NULL THEN
      EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    END IF;
  END LOOP;
END $$;

-- -----------------------------------------------------------------------------
-- 3. PRODUTOS, CATEGORIAS, CONFIGURAÇÕES: leitura pública, escrita só admin
-- -----------------------------------------------------------------------------
CREATE POLICY "products_public_read"  ON public.products
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "products_admin_write"  ON public.products
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "categories_public_read" ON public.categories
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "categories_admin_write" ON public.categories
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "store_settings_public_read" ON public.store_settings
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "store_settings_admin_write" ON public.store_settings
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- -----------------------------------------------------------------------------
-- 4. DESPESAS: confidencial, exclusivo do administrador
-- -----------------------------------------------------------------------------
CREATE POLICY "expenses_admin_only" ON public.expenses
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- -----------------------------------------------------------------------------
-- 5. PEDIDOS: cada cliente só vê/cria os seus; só o admin altera e apaga.
--    to_jsonb(orders) torna a política tolerante a colunas opcionais
--    (customer_id, user_id, customer_email) que possam não existir no seu esquema.
-- -----------------------------------------------------------------------------
CREATE POLICY "orders_select_owner_or_admin" ON public.orders
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR (to_jsonb(orders) ->> 'user_id')     = auth.uid()::text
    OR (to_jsonb(orders) ->> 'customer_id') = auth.uid()::text
    OR (
      COALESCE(auth.jwt() ->> 'email', '') <> ''
      AND LOWER(COALESCE(to_jsonb(orders) ->> 'customer_email', '')) = LOWER(auth.jwt() ->> 'email')
    )
  );

CREATE POLICY "orders_insert_owner_or_admin" ON public.orders
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin()
    OR (to_jsonb(orders) ->> 'user_id')     = auth.uid()::text
    OR (to_jsonb(orders) ->> 'customer_id') = auth.uid()::text
    OR (
      COALESCE(auth.jwt() ->> 'email', '') <> ''
      AND LOWER(COALESCE(to_jsonb(orders) ->> 'customer_email', '')) = LOWER(auth.jwt() ->> 'email')
    )
  );

CREATE POLICY "orders_admin_update" ON public.orders
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "orders_admin_delete" ON public.orders
  FOR DELETE TO authenticated USING (public.is_admin());

-- -----------------------------------------------------------------------------
-- 6. ITENS DE PEDIDO: seguem a propriedade do pedido
-- -----------------------------------------------------------------------------
CREATE POLICY "order_items_select_owner_or_admin" ON public.order_items
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_items.order_id)
  );

CREATE POLICY "order_items_insert_owner_or_admin" ON public.order_items
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin()
    OR EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_items.order_id)
  );

CREATE POLICY "order_items_admin_update" ON public.order_items
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "order_items_admin_delete" ON public.order_items
  FOR DELETE TO authenticated USING (public.is_admin());
-- (O EXISTS acima respeita a RLS de "orders": só encontra pedidos do próprio cliente.)

-- -----------------------------------------------------------------------------
-- 7. UTILIZADORES E PERFIS: cada um vê/edita só o seu e NUNCA pode elevar o
--    próprio papel (role) nem usar o e-mail de outra pessoa.
-- -----------------------------------------------------------------------------
CREATE POLICY "users_select_own_or_admin" ON public.users
  FOR SELECT TO authenticated
  USING (public.is_admin() OR id = auth.uid()::text);

CREATE POLICY "users_insert_own_customer" ON public.users
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin()
    OR (
      id = auth.uid()::text
      AND role = 'customer'
      AND LOWER(email) = LOWER(COALESCE(auth.jwt() ->> 'email', ''))
    )
  );

CREATE POLICY "users_update_own_customer" ON public.users
  FOR UPDATE TO authenticated
  USING (public.is_admin() OR id = auth.uid()::text)
  WITH CHECK (
    public.is_admin()
    OR (
      id = auth.uid()::text
      AND role = 'customer'
      AND LOWER(email) = LOWER(COALESCE(auth.jwt() ->> 'email', ''))
    )
  );

CREATE POLICY "users_admin_delete" ON public.users
  FOR DELETE TO authenticated USING (public.is_admin());

CREATE POLICY "profiles_select_own_or_admin" ON public.profiles
  FOR SELECT TO authenticated
  USING (public.is_admin() OR id = auth.uid());

CREATE POLICY "profiles_insert_own_customer" ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin()
    OR (
      id = auth.uid()
      AND role = 'customer'
      AND LOWER(email) = LOWER(COALESCE(auth.jwt() ->> 'email', ''))
    )
  );

CREATE POLICY "profiles_update_own_customer" ON public.profiles
  FOR UPDATE TO authenticated
  USING (public.is_admin() OR id = auth.uid())
  WITH CHECK (
    public.is_admin()
    OR (
      id = auth.uid()
      AND role = 'customer'
      AND LOWER(email) = LOWER(COALESCE(auth.jwt() ->> 'email', ''))
    )
  );

CREATE POLICY "profiles_admin_delete" ON public.profiles
  FOR DELETE TO authenticated USING (public.is_admin());

-- -----------------------------------------------------------------------------
-- 8. PRIVILÉGIOS (segunda barreira, independente das políticas)
--    Anónimo: só LEITURA de produtos, categorias e configurações.
--    Ninguém usa a API para TRUNCATE / TRIGGER / REFERENCES.
-- -----------------------------------------------------------------------------
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
GRANT SELECT ON public.products, public.categories, public.store_settings TO anon;

REVOKE TRUNCATE, REFERENCES, TRIGGER ON ALL TABLES IN SCHEMA public FROM anon, authenticated;

-- Tabelas futuras não ficam abertas a anónimos por defeito
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon;

-- Recarregar o esquema da API
NOTIFY pgrst, 'reload schema';

COMMIT;

-- =============================================================================
-- VERIFICAÇÕES (executar DEPOIS, uma de cada vez)
-- =============================================================================
-- A) Não deve existir nenhuma política aberta de escrita para anon/public:
--    select tablename, policyname, cmd, roles::text, qual, with_check
--    from pg_policies where schemaname='public' order by 1,2;
--
-- B) Todas as tabelas com RLS ligado (rowsecurity = true):
--    select tablename, rowsecurity from pg_tables where schemaname='public' order by 1;
--
-- C) Teste no site: (1) abrir a loja sem login -> produtos aparecem;
--    (2) cliente com conta -> faz pedido e vê só os seus;
--    (3) admin domingosquissanga862@gmail.com -> painel, produtos, categorias,
--        pedidos e despesas funcionam.
