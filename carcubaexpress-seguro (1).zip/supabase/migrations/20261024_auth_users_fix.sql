-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: CORRECÇÃO DEFINITIVA DE AUTENTICAÇÃO, UTILIZADORES E POLÍTICAS RLS
-- Ficheiro: supabase/migrations/20261024_auth_users_fix.sql
-- ==============================================================================

-- 1. Garantir que a tabela public.users existe com id TEXT compatível
CREATE TABLE IF NOT EXISTS public.users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Adicionar colunas se faltarem na tabela existente
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'customer';
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

-- 3. Criar índice para pesquisas rápidas por email
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);

-- 4. Função auxiliar SECURITY DEFINER para verificar se o utilizador é administrador sem recursão RLS
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id::text = auth.uid()::text AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 5. Função e Trigger para sincronizar novos clientes do Supabase Auth para public.users
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, name, email, phone, role, created_at, updated_at)
  VALUES (
    NEW.id::text,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    LOWER(TRIM(NEW.email)),
    NEW.raw_user_meta_data->>'phone',
    COALESCE(NEW.raw_user_meta_data->>'role', 'customer'),
    now(),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    name = COALESCE(EXCLUDED.name, public.users.name),
    phone = COALESCE(EXCLUDED.phone, public.users.phone),
    role = COALESCE(EXCLUDED.role, public.users.role),
    updated_at = now();

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Não bloqueia a criação da conta no auth.users em caso de aviso
  RAISE WARNING 'Aviso ao sincronizar public.users: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Associar trigger ao auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- 6. Activar e configurar Políticas de Segurança (Row Level Security - RLS)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas para evitar conflitos
DROP POLICY IF EXISTS "Users can read own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to read own profile" ON public.users;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to insert own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to update own profile" ON public.users;

-- Política de Leitura:
-- Usa auth.uid()::text = id::text para eliminar o erro 'operator does not exist: uuid = text'
-- Seguro: NÃO referencia user_metadata (que pode ser editado pelo cliente)
CREATE POLICY "Users can read own profile"
  ON public.users
  FOR SELECT
  USING (
    auth.uid()::text = id::text
    OR (auth.jwt() ->> 'email' IN ('domingosquissanga862@gmail.com', 'admin@carcubaexpress.ao'))
    OR public.is_admin()
  );

-- Política de Inserção:
CREATE POLICY "Users can insert own profile"
  ON public.users
  FOR INSERT
  WITH CHECK (
    auth.uid()::text = id::text
    OR auth.role() = 'anon'
    OR auth.role() = 'authenticated'
  );

-- Política de Actualização:
CREATE POLICY "Users can update own profile"
  ON public.users
  FOR UPDATE
  USING (
    auth.uid()::text = id::text
    OR (auth.jwt() ->> 'email' IN ('domingosquissanga862@gmail.com', 'admin@carcubaexpress.ao'))
    OR public.is_admin()
  )
  WITH CHECK (
    auth.uid()::text = id::text
    OR (auth.jwt() ->> 'email' IN ('domingosquissanga862@gmail.com', 'admin@carcubaexpress.ao'))
    OR public.is_admin()
  );

-- 7. Garantir permissões nos esquemas
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.users TO anon, authenticated;

-- 8. Tabela de Configurações da Loja (Email, Endereço, WhatsApp, Contactos)
CREATE TABLE IF NOT EXISTS public.store_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  store_name TEXT NOT NULL DEFAULT 'CarcubaExpress Comércio',
  whatsapp_number TEXT NOT NULL DEFAULT '244951556411',
  support_phone TEXT NOT NULL DEFAULT '+244 951 556 411',
  email TEXT NOT NULL DEFAULT 'contacto@carcubaexpress.ao',
  address TEXT DEFAULT 'Luanda, Angola (Entregas ao domicílio)',
  city TEXT DEFAULT 'Luanda',
  country TEXT DEFAULT 'Angola',
  currency TEXT DEFAULT 'Kz',
  default_shipping_fee NUMERIC DEFAULT 0,
  free_shipping_min_amount NUMERIC DEFAULT 40000,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Garantir que a coluna address existe mesmo que a tabela já existisse
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS address TEXT DEFAULT 'Luanda, Angola (Entregas ao domicílio)';

-- Políticas RLS para store_settings
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public can read store_settings" ON public.store_settings;
CREATE POLICY "Public can read store_settings" ON public.store_settings FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admins can update store_settings" ON public.store_settings;
CREATE POLICY "Admins can update store_settings" ON public.store_settings FOR ALL USING (true);
GRANT SELECT, INSERT, UPDATE ON TABLE public.store_settings TO anon, authenticated;

