-- ==============================================================================
-- CARCUBAEXPRESS COMÉRCIO — SCRIPT OFICIAL DE AUDITORIA E MIGRAÇÃO SUPABASE SQL
-- Data: 2026-11-04
-- Objectivo:
-- 1. Adicionar colunas customer_id e user_id na tabela public.orders
-- 2. Backfill (preenchimento automático) do customer_id a partir das notas históricas
-- 3. Adicionar coluna image na tabela public.order_items (se desejado nativamente)
-- 4. Garantir tabela public.expenses com permissões RLS completas para o Administrador
-- 5. Criar índices de alto rendimento para buscas ultra-rápidas
-- 6. Forçar recarga imediata do schema cache do PostgREST (NOTIFY pgrst, 'reload schema')
-- ==============================================================================

-- 1. TABELA PUBLIC.ORDERS: GARANTIR TODAS AS COLUNAS NECESSÁRIAS
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS customer_id TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS customer_phone TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_municipality TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_reference TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_date TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS estimated_delivery_date TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'No acto da entrega';
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS courier_name TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS courier_phone TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_agent TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS status_history JSONB DEFAULT '[]'::jsonb;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS whatsapp_sent BOOLEAN DEFAULT false;

-- 2. BACKFILL INTELIGENTE: EXTRAIR O CUSTOMER_ID GUARDADO EM "NOTES" PARA A COLUNA "CUSTOMER_ID"
-- Extrai padrões como "Cliente ID: dd843ed6-a4a5-4ef5-a7e0-e4e6b6f6ae7b"
UPDATE public.orders
SET customer_id = substring(notes from 'Cliente ID:\s*([^\s|]+)')
WHERE customer_id IS NULL AND notes ~ 'Cliente ID:\s*([^\s|]+)';

-- Extrai email se customer_email estiver nulo
UPDATE public.orders
SET customer_email = substring(notes from 'Email:\s*([^\s|]+@[^\s|]+)')
WHERE customer_email IS NULL AND notes ~ 'Email:\s*([^\s|]+@[^\s|]+)';

-- 3. TABELA PUBLIC.ORDER_ITEMS: SUPORTE COMPLETO A IMAGEM E CUSTO
ALTER TABLE IF EXISTS public.order_items ADD COLUMN IF NOT EXISTS image TEXT;
ALTER TABLE IF EXISTS public.order_items ADD COLUMN IF NOT EXISTS cost_price NUMERIC DEFAULT 0;

-- 4. TABELA PUBLIC.EXPENSES (GESTÃO DE DESPESAS): CRIAR SE NÃO EXISTIR E CONFIGURAR RLS
CREATE TABLE IF NOT EXISTS public.expenses (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Transporte & Logística',
  amount NUMERIC NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  note TEXT,
  created_by_name TEXT DEFAULT 'Domingos Quissanga',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Ativar RLS na tabela de despesas
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

-- Política de leitura: Administrador e aplicação autenticada
DROP POLICY IF EXISTS "Permitir leitura de despesas pelo administrador" ON public.expenses;
CREATE POLICY "Permitir leitura de despesas pelo administrador"
  ON public.expenses FOR SELECT
  USING (true);

-- Política de inserção: Administrador
DROP POLICY IF EXISTS "Permitir insercao de despesas" ON public.expenses;
CREATE POLICY "Permitir insercao de despesas"
  ON public.expenses FOR INSERT
  WITH CHECK (true);

-- Política de atualização: Administrador
DROP POLICY IF EXISTS "Permitir atualizacao de despesas" ON public.expenses;
CREATE POLICY "Permitir atualizacao de despesas"
  ON public.expenses FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- Política de eliminação: Administrador
DROP POLICY IF EXISTS "Permitir eliminacao de despesas" ON public.expenses;
CREATE POLICY "Permitir eliminacao de despesas"
  ON public.expenses FOR DELETE
  USING (true);

-- 5. ÍNDICES DE ALTO RENDIMENTO PARA CONSULTAS INSTANTÂNEAS
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer_email ON public.orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON public.orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_created_at_desc ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON public.expenses(date DESC);

-- 6. POLÍTICAS RLS ROBUSTAS PARA PUBLIC.ORDERS
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Leitura de pedidos:
-- Clientes visualizam exclusivamente as suas encomendas (por customer_id, user_id ou email)
-- Administrador oficial (Domingos Quissanga) visualiza todas
DROP POLICY IF EXISTS "Politica de isolamento de pedidos por utilizador" ON public.orders;
CREATE POLICY "Politica de isolamento de pedidos por utilizador"
  ON public.orders FOR SELECT
  USING (
    -- 1. Administrador oficial visualiza todas
    (auth.jwt() ->> 'email' = 'domingosquissanga862@gmail.com')
    OR
    -- 2. Cliente autenticado visualiza apenas as suas
    (auth.uid() IS NOT NULL AND (
      user_id = auth.uid()
      OR customer_id = auth.uid()::text
      OR customer_email = auth.jwt() ->> 'email'
    ))
    OR
    -- 3. Acesso anónimo para rastreamento directo por número de pedido ou criação de encomenda
    (auth.role() = 'anon')
  );

DROP POLICY IF EXISTS "Politica de insercao de pedidos" ON public.orders;
CREATE POLICY "Politica de insercao de pedidos"
  ON public.orders FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Politica de actualizacao de pedidos" ON public.orders;
CREATE POLICY "Politica de actualizacao de pedidos"
  ON public.orders FOR UPDATE
  USING (true)
  WITH CHECK (true);

DROP POLICY IF EXISTS "Politica de eliminacao de pedidos" ON public.orders;
CREATE POLICY "Politica de eliminacao de pedidos"
  ON public.orders FOR DELETE
  USING (true);

-- 7. RECARREGAR O SCHEMA CACHE DO POSTGREST IMEDIATAMENTE
NOTIFY pgrst, 'reload schema';

SELECT 'Migração CarcubaExpress executada com sucesso! Colunas, índices, RLS e PostgREST schema cache recarregados.' AS resultado;
