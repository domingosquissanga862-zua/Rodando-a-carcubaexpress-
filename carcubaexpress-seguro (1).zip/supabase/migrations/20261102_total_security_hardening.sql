-- ==============================================================================
-- CARCUBAEXPRESS COMÉRCIO — TOTAL SECURITY HARDENING MIGRATION
-- Data: 2026-11-02
-- Autor: Equipa de Engenharia & Segurança CarcubaExpress
-- Objectivo: Blindagem completa de RLS, isolamento de dados de clientes, 
--            protecção de despesas, restrição estrita de operações administrativas.
-- ==============================================================================

-- 1. FUNÇÃO DE VERIFICAÇÃO DE ADMINISTRADOR DEFINITIVA E SEGURA
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT COALESCE(
    (LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', ''))) = 'domingosquissanga862@gmail.com') OR
    (auth.jwt() -> 'app_metadata' ->> 'role' = 'admin') OR
    (auth.jwt() -> 'user_metadata' ->> 'role' = 'admin') OR
    (EXISTS (
      SELECT 1 FROM public.users u 
      WHERE u.email = auth.jwt() ->> 'email' AND u.role = 'admin'
    )),
    FALSE
  );
$$;

-- 2. ATIVAÇÃO DE RLS EM TODAS AS TABELAS DO SISTEMA
ALTER TABLE IF EXISTS public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.store_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.profiles ENABLE ROW LEVEL SECURITY;

-- 3. PRODUTOS (Catálogo público de leitura, Modificação exclusiva de Admin)
DROP POLICY IF EXISTS "Permitir leitura de produtos" ON public.products;
DROP POLICY IF EXISTS "Permitir insercao de produtos" ON public.products;
DROP POLICY IF EXISTS "Permitir actualizacao de produtos" ON public.products;
DROP POLICY IF EXISTS "Permitir eliminacao de produtos" ON public.products;
DROP POLICY IF EXISTS "Admin insert products" ON public.products;
DROP POLICY IF EXISTS "Admin update products" ON public.products;
DROP POLICY IF EXISTS "Admin delete products" ON public.products;

CREATE POLICY "Permitir leitura de produtos" ON public.products
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY "Admin insert products" ON public.products
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admin update products" ON public.products
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admin delete products" ON public.products
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- 4. CATEGORIAS (Leitura pública, Gestão exclusiva de Admin)
DROP POLICY IF EXISTS "Permitir leitura de categorias" ON public.categories;
DROP POLICY IF EXISTS "Permitir gestao de categorias para autenticados" ON public.categories;
DROP POLICY IF EXISTS "Admin manage categories" ON public.categories;

CREATE POLICY "Permitir leitura de categorias" ON public.categories
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY "Admin manage categories" ON public.categories
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 5. PEDIDOS (Criação pública no checkout, Leitura isolada por cliente ou Admin, Gestão exclusiva Admin)
DROP POLICY IF EXISTS "Permitir criacao de pedidos" ON public.orders;
DROP POLICY IF EXISTS "Permitir leitura de pedidos" ON public.orders;
DROP POLICY IF EXISTS "Secure orders select" ON public.orders;
DROP POLICY IF EXISTS "Permitir actualizacao de pedidos para autenticados" ON public.orders;
DROP POLICY IF EXISTS "Admin update orders" ON public.orders;
DROP POLICY IF EXISTS "Orders admin delete" ON public.orders;
DROP POLICY IF EXISTS "Admin delete orders" ON public.orders;

CREATE POLICY "Permitir criacao de pedidos" ON public.orders
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Secure orders select" ON public.orders
  FOR SELECT TO anon, authenticated
  USING (
    public.is_admin() OR
    (auth.uid() IS NOT NULL AND customer_id = auth.uid()::text) OR
    (auth.jwt() ->> 'email' IS NOT NULL AND customer_email = auth.jwt() ->> 'email')
  );

CREATE POLICY "Admin update orders" ON public.orders
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admin delete orders" ON public.orders
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- 6. ITENS DE PEDIDOS (Criação com pedido, Leitura isolada do proprietário do pedido ou Admin)
DROP POLICY IF EXISTS "Permitir criacao de itens de pedidos" ON public.order_items;
DROP POLICY IF EXISTS "Permitir leitura de itens de pedidos" ON public.order_items;
DROP POLICY IF EXISTS "Secure order items select" ON public.order_items;
DROP POLICY IF EXISTS "Order items admin delete" ON public.order_items;
DROP POLICY IF EXISTS "Admin delete order items" ON public.order_items;

CREATE POLICY "Permitir criacao de itens de pedidos" ON public.order_items
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Secure order items select" ON public.order_items
  FOR SELECT TO anon, authenticated
  USING (
    public.is_admin() OR
    EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = order_items.order_id AND (
        (auth.uid() IS NOT NULL AND o.customer_id = auth.uid()::text) OR
        (auth.jwt() ->> 'email' IS NOT NULL AND o.customer_email = auth.jwt() ->> 'email')
      )
    )
  );

CREATE POLICY "Admin delete order items" ON public.order_items
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- 7. DESPESAS OPERACIONAIS (Confidencialidade Máxima — Exclusivo Admin)
DROP POLICY IF EXISTS "Permitir gestao de despesas para autenticados" ON public.expenses;
DROP POLICY IF EXISTS "Admin manage expenses" ON public.expenses;

CREATE POLICY "Admin manage expenses" ON public.expenses
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 8. CONFIGURAÇÕES DA LOJA (Leitura pública, Alteração exclusiva Admin)
DROP POLICY IF EXISTS "Permitir leitura de configs da loja" ON public.store_settings;
DROP POLICY IF EXISTS "Permitir gestao de configs para autenticados" ON public.store_settings;
DROP POLICY IF EXISTS "Admin manage settings" ON public.store_settings;

CREATE POLICY "Permitir leitura de configs da loja" ON public.store_settings
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY "Admin manage settings" ON public.store_settings
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 9. PERFIS E UTILIZADORES (Protecção contra elevação de privilégios)
DROP POLICY IF EXISTS "Users view own or admin" ON public.users;
DROP POLICY IF EXISTS "Users update own or admin" ON public.users;

CREATE POLICY "Users view own or admin" ON public.users
  FOR SELECT TO authenticated
  USING (
    public.is_admin() OR 
    id = auth.uid()::text OR 
    email = auth.jwt() ->> 'email'
  );

CREATE POLICY "Users update own non-role" ON public.users
  FOR UPDATE TO authenticated
  USING (
    public.is_admin() OR 
    (id = auth.uid()::text AND role = 'customer')
  )
  WITH CHECK (
    public.is_admin() OR 
    (id = auth.uid()::text AND role = 'customer')
  );

-- 10. REVOGAÇÃO DE PERMISSÕES ANÓNIMAS DESTRUTIVAS
REVOKE DELETE, UPDATE, INSERT ON TABLE public.products FROM anon;
REVOKE DELETE, UPDATE, INSERT ON TABLE public.categories FROM anon;
REVOKE DELETE, UPDATE ON TABLE public.orders FROM anon;
REVOKE DELETE, UPDATE ON TABLE public.order_items FROM anon;
REVOKE ALL ON TABLE public.expenses FROM anon;
REVOKE DELETE, UPDATE, INSERT ON TABLE public.store_settings FROM anon;
REVOKE DELETE, UPDATE, INSERT ON TABLE public.users FROM anon;
