-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: POLÍTICAS RLS E SEGURANÇA PARA ELIMINAÇÃO DE PEDIDOS PELO ADMINISTRADOR
-- Ficheiro: supabase/migrations/20261102_admin_orders_deletion_rls.sql
-- ==============================================================================

-- 1. Verificação da função de administrador oficial
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', ''))) = 'domingosquissanga862@gmail.com'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 2. Activar e Configurar Política RLS para Eliminação em public.orders
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Orders admin delete" ON public.orders;
CREATE POLICY "Orders admin delete"
  ON public.orders
  FOR DELETE
  USING (
    public.is_admin()
  );

-- 3. Activar e Configurar Política RLS para Eliminação em public.order_items
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Order items select" ON public.order_items;
CREATE POLICY "Order items select"
  ON public.order_items
  FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Order items insert" ON public.order_items;
CREATE POLICY "Order items insert"
  ON public.order_items
  FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Order items admin delete" ON public.order_items;
CREATE POLICY "Order items admin delete"
  ON public.order_items
  FOR DELETE
  USING (
    public.is_admin()
  );

-- 4. Conceder Permissões de DELETE aos papéis Supabase (Protegidas estritamente pelas Políticas RLS)
GRANT DELETE ON TABLE public.orders TO authenticated, anon;
GRANT DELETE ON TABLE public.order_items TO authenticated, anon;

-- 5. Actualizar cache de esquema do PostgREST
NOTIFY pgrst, 'reload schema';
