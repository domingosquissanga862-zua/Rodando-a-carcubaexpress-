-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: TAXA ADICIONAL DE ENTREGA E ETIQUETA POR PRODUTO
-- Ficheiro: supabase/migrations/20261029_product_shipping_fee.sql
-- ==============================================================================

-- 1. Adicionar colunas shipping_fee e shipping_fee_label à tabela public.products se não existirem
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS shipping_fee NUMERIC DEFAULT 0;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS shipping_fee_label TEXT;

-- 2. Comentários explicativos para documentação da base de dados
COMMENT ON COLUMN public.products.shipping_fee IS 'Taxa adicional de entrega em Kwanzas (Kz) cobrada para produtos que não possuem frete grátis';
COMMENT ON COLUMN public.products.shipping_fee_label IS 'Etiqueta textual personalizada de entrega exibida no cartão do produto (ex: + Taxa de entrega: 2.000 Kz)';

-- 3. Atualizar produtos existentes que não tenham frete grátis com taxa padrão de 2.000 Kz se estiver a zero
UPDATE public.products
SET shipping_fee = 2000,
    shipping_fee_label = '+ Taxa de entrega: 2.000 Kz'
WHERE free_shipping = false
  AND (shipping_fee IS NULL OR shipping_fee = 0);
