-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL DEFINITIVA: TABELA PUBLIC.PROFILES, AUTENTICAÇÃO E POLÍTICAS RLS
-- Ficheiro: supabase/migrations/20261031_strict_auth_profiles_and_rls.sql
-- ==============================================================================

-- 1. Criação e Estrutura da Tabela public.profiles
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'customer';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles (email);

-- 2. Assegurar Tabela public.users compatível
CREATE TABLE IF NOT EXISTS public.users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.users ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'customer';
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_users_email ON public.users (email);

-- 3. Função de verificação de Administrador Oficial
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', ''))) = 'domingosquissanga862@gmail.com'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 4. Trigger de Sincronização Automática em auth.users para public.profiles & public.users
CREATE OR REPLACE FUNCTION public.handle_auth_user_sync()
RETURNS TRIGGER AS $$
DECLARE
  clean_email TEXT;
  clean_name TEXT;
  clean_phone TEXT;
  user_role TEXT;
BEGIN
  clean_email := LOWER(TRIM(COALESCE(NEW.email, '')));
  clean_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    NEW.raw_user_meta_data->>'user_name',
    split_part(clean_email, '@', 1),
    'Cliente CarcubaExpress'
  );
  clean_phone := COALESCE(NEW.raw_user_meta_data->>'phone', '');

  IF clean_email = 'domingosquissanga862@gmail.com' THEN
    user_role := 'admin';
    clean_name := 'Domingos Quissanga';
  ELSE
    user_role := 'customer';
  END IF;

  -- 1. Sincronizar em public.profiles
  INSERT INTO public.profiles (id, name, email, phone, role, created_at, updated_at)
  VALUES (NEW.id, clean_name, clean_email, clean_phone, user_role, now(), now())
  ON CONFLICT (id) DO UPDATE SET
    name = CASE 
      WHEN public.profiles.name IS NULL OR public.profiles.name = '' OR public.profiles.name = 'Cliente CarcubaExpress'
      THEN EXCLUDED.name 
      ELSE public.profiles.name 
    END,
    phone = COALESCE(NULLIF(EXCLUDED.phone, ''), public.profiles.phone),
    role = user_role,
    updated_at = now();

  -- 2. Sincronizar em public.users
  INSERT INTO public.users (id, name, email, phone, role, created_at, updated_at)
  VALUES (NEW.id::text, clean_name, clean_email, clean_phone, user_role, now(), now())
  ON CONFLICT (id) DO UPDATE SET
    name = CASE 
      WHEN public.users.name IS NULL OR public.users.name = '' OR public.users.name = 'Cliente CarcubaExpress'
      THEN EXCLUDED.name 
      ELSE public.users.name 
    END,
    phone = COALESCE(NULLIF(EXCLUDED.phone, ''), public.users.phone),
    role = user_role,
    updated_at = now();

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'Aviso ao sincronizar perfis: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_auth_user_sync();

-- 5. Activar e Configurar Políticas RLS em public.profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Profiles select policy" ON public.profiles;
DROP POLICY IF EXISTS "Profiles insert policy" ON public.profiles;
DROP POLICY IF EXISTS "Profiles update policy" ON public.profiles;

CREATE POLICY "Profiles select policy"
  ON public.profiles
  FOR SELECT
  USING (
    auth.uid() = id
    OR public.is_admin()
  );

CREATE POLICY "Profiles insert policy"
  ON public.profiles
  FOR INSERT
  WITH CHECK (
    auth.uid() = id
    OR auth.role() = 'authenticated'
    OR auth.role() = 'anon'
  );

CREATE POLICY "Profiles update policy"
  ON public.profiles
  FOR UPDATE
  USING (
    auth.uid() = id
    OR public.is_admin()
  )
  WITH CHECK (
    auth.uid() = id
    OR public.is_admin()
  );

-- 6. Activar e Configurar Políticas RLS em public.users
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can read own profile" ON public.users;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;

CREATE POLICY "Users can read own profile"
  ON public.users
  FOR SELECT
  USING (
    auth.uid()::text = id::text
    OR public.is_admin()
  );

CREATE POLICY "Users can insert own profile"
  ON public.users
  FOR INSERT
  WITH CHECK (
    auth.uid()::text = id::text
    OR auth.role() = 'authenticated'
    OR auth.role() = 'anon'
  );

CREATE POLICY "Users can update own profile"
  ON public.users
  FOR UPDATE
  USING (
    auth.uid()::text = id::text
    OR public.is_admin()
  )
  WITH CHECK (
    auth.uid()::text = id::text
    OR public.is_admin()
  );

-- 7. Activar e Configurar Políticas RLS em public.orders (Isolamento total de pedidos por utilizador)
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Orders client isolation select" ON public.orders;
DROP POLICY IF EXISTS "Orders customer insert" ON public.orders;
DROP POLICY IF EXISTS "Orders admin update" ON public.orders;

-- Leitura: Apenas o próprio cliente que fez o pedido (por email ou customer_id) ou o Administrador Oficial
CREATE POLICY "Orders client isolation select"
  ON public.orders
  FOR SELECT
  USING (
    LOWER(TRIM(COALESCE(customer_email, ''))) = LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', '')))
    OR customer_id = auth.uid()::text
    OR public.is_admin()
  );

-- Inserção: Criar pedido permitido
CREATE POLICY "Orders customer insert"
  ON public.orders
  FOR INSERT
  WITH CHECK (
    true
  );

-- Atualização: Apenas o Administrador Oficial pode alterar encomendas (status, etc.)
CREATE POLICY "Orders admin update"
  ON public.orders
  FOR UPDATE
  USING (
    public.is_admin()
  )
  WITH CHECK (
    public.is_admin()
  );

-- 8. Conceder Permissões aos Roles Supabase
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.profiles TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.users TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.orders TO anon, authenticated;

-- 9. Recarregar Cache de Esquema do PostgREST
NOTIFY pgrst, 'reload schema';
