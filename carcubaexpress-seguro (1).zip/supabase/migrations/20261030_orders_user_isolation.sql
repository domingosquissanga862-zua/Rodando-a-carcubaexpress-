-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: ISOLAMENTO SEGURO DE ENCOMENDAS POR CLIENTE E ÍNDICES DE PERFORMANCE
-- Ficheiro: supabase/migrations/20261030_orders_user_isolation.sql
-- ==============================================================================

-- 1. Assegurar que as colunas essenciais existem na tabela orders
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_phone TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_id TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();

-- 2. Índices de pesquisa rápida para consultas de encomendas por cliente
CREATE INDEX IF NOT EXISTS idx_orders_customer_email ON public.orders (customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_customer_phone ON public.orders (customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_phone ON public.orders (phone);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON public.orders (order_number);

-- 3. Associar formalmente a encomenda existente (id: 135) ao email do utilizador correspondente
UPDATE public.orders
SET customer_email = 'mystast5@gmail.com'
WHERE id = 135 AND (customer_email IS NULL OR customer_email = '');

-- 4. Recarregar schema cache do PostgREST
NOTIFY pgrst, 'reload schema';
