-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: SINCRONIZAÇÃO DE PERFIS GOOGLE OAUTH E POLÍTICAS RLS ROBUSTAS
-- Ficheiro: supabase/migrations/20261028_google_oauth_profiles_fix.sql
-- ==============================================================================

-- 1. Assegurar estrutura da tabela public.users
CREATE TABLE IF NOT EXISTS public.users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.users ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'customer';
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);

-- 2. Função SECURITY DEFINER para verificar administrador
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', ''))) = 'domingosquissanga862@gmail.com'
    OR EXISTS (
      SELECT 1 FROM public.users
      WHERE id::text = auth.uid()::text AND role = 'admin'
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 3. Trigger melhorado para utilizadores Google OAuth e email/password
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER AS $$
DECLARE
  extracted_name TEXT;
  extracted_email TEXT;
  extracted_phone TEXT;
  assigned_role TEXT;
BEGIN
  extracted_email := LOWER(TRIM(COALESCE(NEW.email, '')));
  
  -- Extrair nome completo dos metadados do Google OAuth ou registo manual
  extracted_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    NEW.raw_user_meta_data->>'user_name',
    split_part(extracted_email, '@', 1),
    'Cliente CarcubaExpress'
  );

  extracted_phone := COALESCE(NEW.raw_user_meta_data->>'phone', '');

  -- Apenas domingosquissanga862@gmail.com recebe perfil de administrador
  IF extracted_email = 'domingosquissanga862@gmail.com' THEN
    assigned_role := 'admin';
    extracted_name := 'Domingos Quissanga';
  ELSE
    assigned_role := 'customer';
  END IF;

  -- Inserção ou atualização segura sem conflito de chaves
  INSERT INTO public.users (id, name, email, phone, role, created_at, updated_at)
  VALUES (
    NEW.id::text,
    extracted_name,
    extracted_email,
    extracted_phone,
    assigned_role,
    now(),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    name = CASE 
      WHEN public.users.name IS NULL OR public.users.name = '' OR public.users.name = 'Cliente CarcubaExpress'
      THEN EXCLUDED.name 
      ELSE public.users.name 
    END,
    phone = COALESCE(NULLIF(EXCLUDED.phone, ''), public.users.phone),
    role = assigned_role,
    updated_at = now();

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Não bloqueia a transacção do Supabase Auth em caso de erro na tabela pública
  RAISE WARNING 'Aviso ao sincronizar public.users no trigger: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Reassociar trigger a auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- 4. Activar e configurar Políticas de Segurança (Row Level Security - RLS)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can read own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to read own profile" ON public.users;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to insert own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to update own profile" ON public.users;

-- Leitura: Utilizador lê o seu perfil; Administrador oficial lê todos
CREATE POLICY "Users can read own profile"
  ON public.users
  FOR SELECT
  USING (
    auth.uid()::text = id::text
    OR public.is_admin()
  );

-- Inserção: Criar o próprio perfil ao registar ou via Google OAuth
CREATE POLICY "Users can insert own profile"
  ON public.users
  FOR INSERT
  WITH CHECK (
    auth.uid()::text = id::text
    OR auth.role() = 'authenticated'
    OR auth.role() = 'anon'
  );

-- Actualização: Actualizar o próprio perfil
CREATE POLICY "Users can update own profile"
  ON public.users
  FOR UPDATE
  USING (
    auth.uid()::text = id::text
    OR public.is_admin()
  )
  WITH CHECK (
    auth.uid()::text = id::text
    OR public.is_admin()
  );

-- 5. Conceder permissões necessárias aos roles anon e authenticated
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.users TO anon, authenticated;
