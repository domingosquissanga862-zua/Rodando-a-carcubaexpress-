-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: EXPANSÃO SEGURA DA TABELA ORDERS E RECARGA DE SCHEMA CACHE
-- Ficheiro: supabase/migrations/20261030_orders_customer_email_fix.sql
-- ==============================================================================

-- 1. Adicionar customer_email e colunas complementares se ainda não existirem
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_date TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS status_history JSONB;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_name TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS courier_phone TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_agent TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS estimated_delivery_date TEXT;

-- 2. Compatibilidade para nomes alternativos de colunas monetárias
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS subtotal_kz NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shipping_fee_kz NUMERIC;

-- 3. Atualizar restrição de verificação de status para aceitar formatos variados
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_status_check
  CHECK (status IN (
    'pendente', 'entregue', 'cancelado', 'a_caminho', 'processando',
    'Pendente', 'Entregue', 'Cancelado', 'A caminho', 'Processando', 'Em análise'
  ));

-- 4. Notificar PostgREST para recarregar imediatamente a cache de esquema
NOTIFY pgrst, 'reload schema';

-- 5. Garantir permissões de acesso às tabelas orders e order_items
GRANT SELECT, INSERT, UPDATE ON TABLE public.orders TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.order_items TO anon, authenticated;
