-- ==============================================================================
-- CARCUBAEXPRESS COMÉRCIO — MIGRATION: ADD ORDERS CUSTOMER_ID & SCHEMA CACHE FIX
-- Data: 2026-11-03
-- Objectivo: Adicionar a coluna customer_id e colunas auxiliares na tabela orders,
--            recarregar o schema cache do PostgREST e garantir compatibilidade total.
-- ==============================================================================

-- 1. ADICIONAR COLUNA customer_id E DEMAIS COLUNAS NA TABELA ORDERS
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS customer_id TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_municipality TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_reference TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS delivery_date TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS estimated_delivery_date TEXT;
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS whatsapp_sent BOOLEAN DEFAULT false;

-- 2. CRIAR ÍNDICE DE PERFORMANCE PARA BUSCAS DE CLIENTE E RASTREAMENTO
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer_email ON public.orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON public.orders(order_number);

-- 3. FORÇAR A ATUALIZAÇÃO DO SCHEMA CACHE DO POSTGREST
NOTIFY pgrst, 'reload schema';

SELECT 'Colunas customer_id e schema cache atualizados com sucesso na tabela public.orders!' AS status;
