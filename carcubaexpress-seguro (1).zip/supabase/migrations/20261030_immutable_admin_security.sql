-- ==============================================================================
-- PROJECTO: CARCUBAEXPRESS COMÉRCIO
-- MIGRAÇÃO SQL: BLINDAGEM ABSOLUTA DE SEGURANÇA DO PAPEL DE ADMINISTRADOR E RLS
-- Ficheiro: supabase/migrations/20261030_immutable_admin_security.sql
-- ==============================================================================

-- 1. Assegurar tabela public.users
CREATE TABLE IF NOT EXISTS public.users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_email_lower ON public.users (LOWER(TRIM(email)));

-- 2. Gatilho de segurança BEFORE INSERT OR UPDATE
-- Impede categoricamente qualquer atribuição do papel 'admin' a qualquer conta
-- que não seja o email oficial exclusivo: domingosquissanga862@gmail.com
CREATE OR REPLACE FUNCTION public.protect_admin_role()
RETURNS TRIGGER AS $$
BEGIN
  -- Normalizar email
  NEW.email := LOWER(TRIM(COALESCE(NEW.email, '')));

  -- Se for tentada atribuição de 'admin' por qualquer utilizador não-oficial,
  -- o papel é automaticamente despromovido para 'customer'
  IF NEW.role = 'admin' AND NEW.email != 'domingosquissanga862@gmail.com' THEN
    NEW.role := 'customer';
  END IF;

  -- Se o email for o do administrador oficial, o papel 'admin' é sempre assegurado
  IF NEW.email = 'domingosquissanga862@gmail.com' THEN
    NEW.role := 'admin';
  END IF;

  NEW.updated_at := now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_protect_admin_role ON public.users;
CREATE TRIGGER trigger_protect_admin_role
  BEFORE INSERT OR UPDATE ON public.users
  FOR EACH ROW
  EXECUTE FUNCTION public.protect_admin_role();

-- 3. Função auxiliar para verificar administrador nos RLS
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', ''))) = 'domingosquissanga862@gmail.com'
    OR EXISTS (
      SELECT 1 FROM public.users
      WHERE id::text = auth.uid()::text AND role = 'admin' AND LOWER(TRIM(email)) = 'domingosquissanga862@gmail.com'
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 4. Activar e renovar Políticas de Segurança (Row Level Security - RLS)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can read own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to read own profile" ON public.users;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to insert own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;
DROP POLICY IF EXISTS "Allow users to update own profile" ON public.users;

-- Leitura: Utilizador lê o seu perfil; Administrador oficial lê todos os perfis
CREATE POLICY "Users can read own profile"
  ON public.users
  FOR SELECT
  USING (
    auth.uid()::text = id::text
    OR public.is_admin()
  );

-- Inserção: Criar o próprio perfil
CREATE POLICY "Users can insert own profile"
  ON public.users
  FOR INSERT
  WITH CHECK (
    auth.uid()::text = id::text
    OR auth.role() = 'authenticated'
    OR auth.role() = 'anon'
  );

-- Actualização: Apenas o próprio utilizador ou o administrador oficial pode atualizar
-- E com a restrição explícita de que utilizadores comuns nunca podem atualizar role para 'admin'
CREATE POLICY "Users can update own profile"
  ON public.users
  FOR UPDATE
  USING (
    auth.uid()::text = id::text
    OR public.is_admin()
  )
  WITH CHECK (
    (
      auth.uid()::text = id::text
      AND (role = 'customer' OR email = 'domingosquissanga862@gmail.com')
    )
    OR public.is_admin()
  );

-- Conceder permissões operacionais mínimas
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.users TO anon, authenticated;
