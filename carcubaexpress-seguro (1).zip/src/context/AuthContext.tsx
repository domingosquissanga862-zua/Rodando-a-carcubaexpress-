import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import type { User } from '../types';
import { supabase } from '../services/supabase';
import { api, setAuthToken, removeAuthToken } from '../services/api';
import {
  supabaseSignUp,
  supabaseSignIn,
  supabaseGetCurrentUser,
  supabaseSignOut,
  supabaseSignInWithOAuth,
  supabaseResetPasswordForEmail,
  supabaseUpdatePassword,
  handleOAuthCallback,
  syncUserProfile,
  ADMIN_EMAILS,
  type SignUpResult,
} from '../services/auth';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAdmin: boolean;
  isCustomer: boolean;
  isRecoveryMode: boolean;
  setIsRecoveryMode: (val: boolean) => void;
  authError: string | null;
  clearAuthError: () => void;
  login: (email: string, pass: string, isAdminTab?: boolean) => Promise<User>;
  register: (data: { name: string; email: string; phone: string; password: string }) => Promise<SignUpResult>;
  setupAdmin: (data: { name?: string; email: string; phone?: string; password: string; adminKey?: string }) => Promise<User>;
  signInWithOAuth: (provider: 'google' | 'apple') => Promise<void>;
  resetPasswordForEmail: (email: string) => Promise<void>;
  updatePassword: (password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

// Expiração da sessão por inatividade (30 minutos sem qualquer interação)
const SESSION_IDLE_TIMEOUT_MS = 30 * 60 * 1000;
const LAST_ACTIVITY_KEY = 'carcuba_last_activity';
const SESSION_EXPIRED_MESSAGE =
  'A sua sessão expirou após 30 minutos de inatividade. Por segurança, inicie sessão novamente.';

const readLastActivity = (): number => {
  try {
    return Number(window.localStorage.getItem(LAST_ACTIVITY_KEY)) || 0;
  } catch {
    return 0;
  }
};
const writeLastActivity = () => {
  try {
    window.localStorage.setItem(LAST_ACTIVITY_KEY, String(Date.now()));
  } catch {
    // armazenamento bloqueado: o temporizador em memória continua a funcionar
  }
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isRecoveryMode, setIsRecoveryMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash || '';
      const search = window.location.search || '';
      return hash.includes('type=recovery') || search.includes('type=recovery');
    }
    return false;
  });

  const clearAuthError = () => {
    setAuthError(null);
  };

  // Estado inicial da página: inatividade anterior e se chegou por ligação de login/recuperação
  const initialIdleRef = useRef<{ stale: boolean; fromAuthLink: boolean } | null>(null);
  if (initialIdleRef.current === null) {
    const last = typeof window !== 'undefined' ? readLastActivity() : 0;
    const href = typeof window !== 'undefined' ? window.location.href : '';
    initialIdleRef.current = {
      stale: last > 0 && Date.now() - last > SESSION_IDLE_TIMEOUT_MS,
      fromAuthLink: /[?&#](code|access_token|type=recovery|error)/.test(href),
    };
  }
  const idleCheckedRef = useRef(false);

  const refreshUser = async () => {
    try {
      const currentUser = await supabaseGetCurrentUser();
      if (currentUser) {
        const isStoreAdmin = (currentUser.email || '').toLowerCase().trim() === 'domingosquissanga862@gmail.com';
        currentUser.role = isStoreAdmin ? 'admin' : 'customer';
        if (isStoreAdmin) {
          currentUser.name = 'Domingos Quissanga';
        } else if (currentUser.name === 'Administrador CarcubaExpress') {
          currentUser.name = 'Cliente CarcubaExpress';
        }
      }
      setUser(currentUser);
    } catch (err) {
      console.warn('[AuthContext] Erro ao carregar sessão actual:', err);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;

    // 1. Process OAuth callback if arriving from redirect (code or error in query/hash)
    const initAuth = async () => {
      const wasRecoveryLink = window.location.href.includes('type=recovery');
      try {
        const { user: oauthUser, error: oauthError } = await handleOAuthCallback();
        if (oauthError && isMounted) {
          setAuthError(oauthError);
          // Ligação de recuperação inválida/expirada: não abrir o formulário sem sessão válida
          if (wasRecoveryLink) setIsRecoveryMode(false);
        }
        if (oauthUser && isMounted) {
          setUser(oauthUser);
          setIsLoading(false);
          return;
        }
      } catch (err: any) {
        if (isMounted) {
          setAuthError(err.message || 'Erro ao processar autenticação com o Google.');
        }
      }

      // 2. Fetch active session if no fresh OAuth code
      if (isMounted) {
        await refreshUser();
      }
    };

    initAuth();

    // 3. Listen to Supabase authentication state changes (login, logout, token refresh, OAuth callback)
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        setIsRecoveryMode(true);
      } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED') {
        if (session?.user && isMounted) {
          // Synchronize profile to public.users table in Supabase
          try {
            const synced = await syncUserProfile(session.user);
            setUser(synced);
          } catch {
            const email = (session.user.email || '').toLowerCase().trim();
            const isStoreAdmin = email === 'domingosquissanga862@gmail.com';
            let name = isStoreAdmin
              ? 'Domingos Quissanga'
              : (session.user.user_metadata?.full_name ||
                 session.user.user_metadata?.name ||
                 email.split('@')[0] ||
                 'Cliente CarcubaExpress');
            setUser({
              id: session.user.id,
              name,
              email,
              phone: session.user.user_metadata?.phone || '',
              role: isStoreAdmin ? 'admin' : 'customer',
              createdAt: session.user.created_at || new Date().toISOString(),
            });
          }

          if (session.access_token) {
            setAuthToken(session.access_token);
          }
        }
      } else if (event === 'SIGNED_OUT') {
        if (isMounted) {
          setUser(null);
          removeAuthToken();
        }
      }
    });

    return () => {
      isMounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  // Terminar a sessão após 30 minutos sem interação (cliques, teclado, toque, scroll)
  useEffect(() => {
    if (!user) {
      idleCheckedRef.current = false;
      return;
    }

    const expireSession = async () => {
      try {
        window.localStorage.removeItem(LAST_ACTIVITY_KEY);
      } catch {
        // ignore
      }
      await supabaseSignOut();
      setUser(null);
      setAuthError(SESSION_EXPIRED_MESSAGE);
    };

    // Sessão guardada de há mais de 30 min (ex.: navegador reaberto): expira ao carregar,
    // exceto se o utilizador acabou de chegar por ligação de login Google / recuperação.
    if (!idleCheckedRef.current) {
      idleCheckedRef.current = true;
      const init = initialIdleRef.current;
      if (init?.stale && !init.fromAuthLink) {
        void expireSession();
        return;
      }
      writeLastActivity();
    }

    let lastWrite = Date.now();
    const onActivity = () => {
      const now = Date.now();
      if (now - lastWrite > 5000) {
        lastWrite = now;
        writeLastActivity();
      }
    };
    const check = () => {
      const last = readLastActivity() || lastWrite;
      if (Date.now() - last > SESSION_IDLE_TIMEOUT_MS) {
        void expireSession();
      }
    };
    const onVisible = () => {
      if (document.visibilityState === 'visible') check();
    };

    const events = ['click', 'keydown', 'touchstart', 'scroll', 'mousemove'] as const;
    events.forEach(e => window.addEventListener(e, onActivity, { passive: true }));
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', check);
    const timer = window.setInterval(check, 15000);

    return () => {
      events.forEach(e => window.removeEventListener(e, onActivity));
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', check);
      window.clearInterval(timer);
    };
  }, [user?.id]);

  const login = async (email: string, pass: string, isAdminTab: boolean = false): Promise<User> => {
    setAuthError(null);
    const cleanEmail = email.toLowerCase().trim();
    if (isAdminTab && cleanEmail !== 'domingosquissanga862@gmail.com') {
      throw new Error('Acesso restrito. Apenas o administrador oficial domingosquissanga862@gmail.com tem autorização para aceder ao Painel de Administração.');
    }
    const loggedUser = await supabaseSignIn(email, pass, isAdminTab);
    if (loggedUser) {
      const isStoreAdmin = (loggedUser.email || '').toLowerCase().trim() === 'domingosquissanga862@gmail.com';
      loggedUser.role = isStoreAdmin ? 'admin' : 'customer';
      if (isStoreAdmin) {
        loggedUser.name = 'Domingos Quissanga';
      } else if (loggedUser.name === 'Administrador CarcubaExpress') {
        loggedUser.name = 'Cliente CarcubaExpress';
      }
    }
    setUser(loggedUser);
    return loggedUser;
  };

  const register = async (data: { name: string; email: string; phone: string; password: string }): Promise<SignUpResult> => {
    setAuthError(null);
    const result = await supabaseSignUp(data);
    if (result.user && !result.requiresEmailConfirmation) {
      setUser(result.user);
    } else {
      setUser(null);
    }
    return result;
  };

  const setupAdmin = async (data: { name?: string; email: string; phone?: string; password: string; adminKey?: string }): Promise<User> => {
    setAuthError(null);
    const res = await api.setupAdmin(data);
    setUser(res.user);
    return res.user;
  };

  const signInWithOAuth = async (provider: 'google' | 'apple'): Promise<void> => {
    setAuthError(null);
    await supabaseSignInWithOAuth(provider);
  };

  const resetPasswordForEmail = async (email: string): Promise<void> => {
    setAuthError(null);
    await supabaseResetPasswordForEmail(email);
  };

  const updatePassword = async (newPassword: string): Promise<void> => {
    setAuthError(null);
    await supabaseUpdatePassword(newPassword);
  };

  const logout = async () => {
    await supabaseSignOut();
    setUser(null);
  };

  // Strictly enforce that only domingosquissanga862@gmail.com has administrator access
  const isAdmin = Boolean(user && user.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com');
  const isCustomer = user !== null && !isAdmin;

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAdmin,
        isCustomer,
        isRecoveryMode,
        setIsRecoveryMode,
        authError,
        clearAuthError,
        login,
        register,
        setupAdmin,
        signInWithOAuth,
        resetPasswordForEmail,
        updatePassword,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
