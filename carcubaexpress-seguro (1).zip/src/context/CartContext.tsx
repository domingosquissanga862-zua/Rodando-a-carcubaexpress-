import React, { createContext, useContext, useState, useEffect } from 'react';
import type { Product, StoreSettings } from '../types';
import { api } from '../services/api';
import { useAuth } from './AuthContext';

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product, quantity?: number, selectedSize?: string, selectedColor?: string) => void;
  removeItem: (productId: string, selectedSize?: string, selectedColor?: string) => void;
  updateQuantity: (productId: string, quantity: number, selectedSize?: string, selectedColor?: string) => void;
  clearCart: () => void;
  itemCount: number;
  subtotal: number;
  shippingFee: number;
  total: number;
  hasFreeShipping: boolean;
  selectedMunicipality: string;
  setSelectedMunicipality: (municipality: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  settings: StoreSettings | null;
  refreshSettings: () => Promise<void>;
}

const CART_STORAGE_KEY = 'carcuba_cart_items';
const MUNICIPALITY_STORAGE_KEY = 'carcuba_selected_municipality';

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [selectedMunicipality, setSelectedMunicipality] = useState<string>(() => {
    return localStorage.getItem(MUNICIPALITY_STORAGE_KEY) || 'Luanda (Ingombota, Maianga, Rangel, Sambizanga)';
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [settings, setSettings] = useState<StoreSettings | null>(null);

  const refreshSettings = async () => {
    try {
      const res = await api.getSettings();
      setSettings(res.settings);
    } catch (err) {
      console.error('Erro ao carregar configurações da loja:', err);
    }
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (err) {
      console.error('Erro ao salvar carrinho:', err);
    }
  }, [items]);



  useEffect(() => {
    localStorage.setItem(MUNICIPALITY_STORAGE_KEY, selectedMunicipality);
  }, [selectedMunicipality]);

  const matchesItem = (
    item: CartItem,
    productId: string,
    selectedSize?: string,
    selectedColor?: string
  ) => {
    return (
      item.product.id === productId &&
      (item.selectedSize || '') === (selectedSize || '') &&
      (item.selectedColor || '') === (selectedColor || '')
    );
  };

  const addItem = (
    product: Product,
    quantity = 1,
    selectedSize?: string,
    selectedColor?: string
  ) => {
    // Requisito rigoroso: não permite adicionar produtos ao carrinho sem conta criada
    if (!user) {
      return;
    }

    setItems(prev => {
      const existing = prev.find(i => matchesItem(i, product.id, selectedSize, selectedColor));
      if (existing) {
        const newQty = Math.min(product.stock, existing.quantity + quantity);
        return prev.map(i =>
          matchesItem(i, product.id, selectedSize, selectedColor) ? { ...i, quantity: newQty } : i
        );
      }
      return [
        ...prev,
        {
          product,
          quantity: Math.min(product.stock, Math.max(1, quantity)),
          selectedSize: selectedSize || (product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined),
          selectedColor: selectedColor || (product.colors && product.colors.length > 0 ? product.colors[0] : undefined),
        },
      ];
    });
    setIsCartOpen(true);
  };

  const removeItem = (productId: string, selectedSize?: string, selectedColor?: string) => {
    setItems(prev => prev.filter(i => !matchesItem(i, productId, selectedSize, selectedColor)));
  };

  const updateQuantity = (
    productId: string,
    quantity: number,
    selectedSize?: string,
    selectedColor?: string
  ) => {
    if (quantity <= 0) {
      removeItem(productId, selectedSize, selectedColor);
      return;
    }
    setItems(prev =>
      prev.map(i => {
        if (matchesItem(i, productId, selectedSize, selectedColor)) {
          const max = i.product.stock;
          return { ...i, quantity: Math.min(max, quantity) };
        }
        return i;
      })
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  // Check if every item in cart has freeShipping flag OR order reaches free shipping threshold
  const allItemsFreeShipping = items.length > 0 && items.every(i => i.product.freeShipping);
  const meetsMinThreshold = settings ? subtotal >= settings.freeShippingMinAmount : subtotal >= 40000;
  const hasFreeShipping = allItemsFreeShipping || meetsMinThreshold;

  // Calculate delivery fee for Luanda
  let shippingFee = 0;
  if (!hasFreeShipping && items.length > 0) {
    const productShippingFees = items
      .filter(i => !i.product.freeShipping && i.product.shippingFee && i.product.shippingFee > 0)
      .map(i => Number(i.product.shippingFee) || 0);

    const maxProductShippingFee = productShippingFees.length > 0 ? Math.max(...productShippingFees) : 0;

    if (maxProductShippingFee > 0) {
      shippingFee = maxProductShippingFee;
    } else if (settings?.deliveryMunicipalities) {
      const muni = settings.deliveryMunicipalities.find(
        m => m.name.toLowerCase() === selectedMunicipality.toLowerCase()
      );
      shippingFee = muni ? (muni.fee ?? 0) : (settings.defaultShippingFee ?? 0);
    } else {
      shippingFee = 0;
    }
  }

  const total = subtotal + shippingFee;

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        itemCount,
        subtotal,
        shippingFee,
        total,
        hasFreeShipping,
        selectedMunicipality,
        setSelectedMunicipality,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        settings,
        refreshSettings,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart deve ser utilizado dentro de CartProvider');
  }
  return context;
};
