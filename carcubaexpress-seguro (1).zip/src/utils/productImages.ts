/**
 * Smart Product Image and Name Resolver for CarcubaExpress
 * Ensures every product (Perfume Asad da Lattafa, Pijamas, Microfones) displays its authentic photo
 * and prevents microphone images from appearing on perfume orders.
 */

export const ASAD_LATTAFA_IMAGE = '/assets/aistudio/IMG-20261018-WA0022_10800326.jpg';
export const PIJAMAS_IMAGE = '/assets/aistudio/IMG-20261016-WA0016_36cb656c.jpg';
export const MIC_LAPELA_IMAGE = '/assets/aistudio/mic-quadrado_3e698234.jpg';

export function resolveProductImage(
  itemOrProduct: {
    productName?: string;
    name?: string;
    productId?: string | number;
    id?: string | number;
    image?: string;
    images?: string[];
  } | null | undefined
): string {
  if (!itemOrProduct) return ASAD_LATTAFA_IMAGE;

  // 1. Highest Priority: Explicit item image (historical purchase image or catalog photo)
  if (itemOrProduct.image && typeof itemOrProduct.image === 'string' && itemOrProduct.image.trim()) {
    const trimmed = itemOrProduct.image.trim();
    if (!trimmed.includes('mic-circular') && (trimmed.startsWith('data:') || trimmed.startsWith('http') || trimmed.startsWith('/'))) {
      return trimmed;
    }
  }

  // 2. High Priority: First valid image from images array
  if (Array.isArray(itemOrProduct.images) && itemOrProduct.images.length > 0) {
    const firstImg = itemOrProduct.images[0];
    if (firstImg && typeof firstImg === 'string' && firstImg.trim() && !firstImg.includes('mic-circular')) {
      return firstImg.trim();
    }
  }

  const rawName = itemOrProduct.productName || itemOrProduct.name || '';
  const nameLower = rawName.toLowerCase();
  const idStr = String(itemOrProduct.productId || itemOrProduct.id || '');

  // 3. Strict match for Perfumes (Asad da Lattafa / Azabda Latava / Fragrâncias)
  if (
    nameLower.includes('asad') ||
    nameLower.includes('lattafa') ||
    nameLower.includes('latava') ||
    nameLower.includes('azabda') ||
    nameLower.includes('perfume') ||
    nameLower.includes('fragr') ||
    idStr === '28' ||
    idStr === 'cat-perfumes-e-fragrancia' ||
    idStr === 'perfumaria'
  ) {
    return ASAD_LATTAFA_IMAGE;
  }

  // 4. Strict match for Pijamas & Moda Feminina
  if (nameLower.includes('pijama') || nameLower.includes('vestido') || idStr === '29') {
    return PIJAMAS_IMAGE;
  }

  // 5. Strict match for Microfones
  if (
    nameLower.includes('microfone') ||
    nameLower.includes('lapela') ||
    nameLower.includes('audio') ||
    nameLower.includes('áudio') ||
    idStr === '30'
  ) {
    return MIC_LAPELA_IMAGE;
  }

  // 6. Default fallback to Asad da Lattafa official image
  return ASAD_LATTAFA_IMAGE;
}

export function cleanAndNormalizeProductName(name?: string, productId?: string | number): string {
  if (!name || !name.trim()) {
    if (String(productId) === '28') return 'Asad da Lattafa';
    if (String(productId) === '29') return 'Pijamas';
    if (String(productId) === '30') return 'Microfone lapela TX';
    return 'Artigo CarcubaExpress';
  }

  const cleaned = name.replace(/<!--VARIATIONS:(\{.*?\})-->/g, '').trim();
  const lower = cleaned.toLowerCase();

  if (
    lower.includes('asad') ||
    lower.includes('lattafa') ||
    lower.includes('latava') ||
    lower.includes('azabda') ||
    String(productId) === '28'
  ) {
    return 'Asad da Lattafa';
  }

  return cleaned || 'Artigo CarcubaExpress';
}
