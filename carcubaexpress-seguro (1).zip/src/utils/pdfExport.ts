import { jsPDF } from 'jspdf';
import type { FinancialSummary, Expense, StoreSettings, Order } from '../types';

export function generateFinancialPDF(
  summary: FinancialSummary,
  expenses?: Expense[],
  customDate?: string,
  settings?: StoreSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 16;

  // Colors
  const navy = [11, 30, 54] as const;
  const amber = [217, 119, 6] as const;
  const green = [5, 150, 105] as const;
  const red = [220, 38, 38] as const;
  const slate = [100, 116, 139] as const;

  // Header Background Bar
  doc.setFillColor(navy[0], navy[1], navy[2]);
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Title in Header
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text((settings?.storeName || 'CARCUBAEXPRESS COMÉRCIO').toUpperCase(), 14, 12);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(254, 243, 199);
  const locationText = settings?.city ? `Relatório Financeiro & Operacional de Vendas · ${settings.city}, ${settings.country || 'Angola'}` : 'Relatório Financeiro & Operacional de Vendas · Luanda, Angola';
  doc.text(locationText, 14, 18);
  const phone = settings?.supportPhone || '+244 951 556 411';
  const email = settings?.email || 'contacto@carcubaexpress.ao';
  doc.text(`Contacto: ${phone} · ${email}`, 14, 23);

  y = 36;

  // Period / Date Banner
  const periodLabel = customDate
    ? `Data Específica Selecionada: ${new Date(customDate + 'T00:00:00').toLocaleDateString('pt-PT')}`
    : summary.selectedDate
    ? `Data Específica Selecionada: ${new Date(summary.selectedDate + 'T00:00:00').toLocaleDateString('pt-PT')}`
    : summary.period === '7d'
    ? 'Período: Últimos 7 Dias'
    : summary.period === '30d'
    ? 'Período: Últimos 30 Dias'
    : 'Período: Todo o Histórico Geral';

  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, pageWidth - 28, 14, 2, 2, 'FD');

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(periodLabel, 18, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text(`Data de Emissão: ${new Date().toLocaleDateString('pt-PT')} às ${new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}  |  Moeda: Kwanza (Kz)`, 18, y + 10.5);

  y += 20;

  // Section 1: Desempenho Financeiro Global
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('1. DESEMPENHO FINANCEIRO & MARGENS DE LUCRO', 14, y);
  y += 4;

  const financialItems = [
    { label: 'Receita Bruta Total (Pedidos Activos)', value: `${(summary.totalRevenue || 0).toLocaleString('pt-AO')} Kz`, color: navy },
    { label: 'Receita com Pagamento Confirmado', value: `${(summary.confirmedPaidRevenue || 0).toLocaleString('pt-AO')} Kz`, color: green },
    { label: 'Custo das Mercadorias Vendidas (CPV)', value: `-${(summary.cogsTotal || 0).toLocaleString('pt-AO')} Kz`, color: amber },
    { label: 'Despesas Operacionais Registadas', value: `-${(summary.totalExpenses || 0).toLocaleString('pt-AO')} Kz`, color: red },
    { label: 'Lucro Líquido Estimado', value: `${(summary.estimatedNetProfit || 0).toLocaleString('pt-AO')} Kz`, color: green, bold: true },
  ];

  financialItems.forEach((item, idx) => {
    const isOdd = idx % 2 === 1;
    if (item.bold) {
      doc.setFillColor(254, 243, 199);
      doc.rect(14, y, pageWidth - 28, 8, 'F');
    } else if (isOdd) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y, pageWidth - 28, 7, 'F');
    }

    doc.setFont('helvetica', item.bold ? 'bold' : 'normal');
    doc.setFontSize(item.bold ? 10 : 9);
    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text(item.label, 18, y + (item.bold ? 5.5 : 5));

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(item.color[0], item.color[1], item.color[2]);
    doc.text(item.value, pageWidth - 18, y + (item.bold ? 5.5 : 5), { align: 'right' });

    y += item.bold ? 9 : 7.5;
  });

  y += 4;

  // Section 2: Vendas por Departamento / Categoria
  if (summary.categorySales && summary.categorySales.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text('2. VENDAS POR DEPARTAMENTO / CATEGORIA', 14, y);
    y += 5;

    // Header Table
    doc.setFillColor(navy[0], navy[1], navy[2]);
    doc.rect(14, y, pageWidth - 28, 6.5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('CATEGORIA', 18, y + 4.5);
    doc.text('UNIDADES VENDIDAS', 120, y + 4.5);
    doc.text('TOTAL FATURADO (Kz)', pageWidth - 18, y + 4.5, { align: 'right' });
    y += 6.5;

    summary.categorySales.forEach((cat, idx) => {
      const isOdd = idx % 2 === 1;
      if (isOdd) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, pageWidth - 28, 6.5, 'F');
      }

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(navy[0], navy[1], navy[2]);
      doc.text(cat.name, 18, y + 4.5);
      doc.text(`${cat.unitsSold} unidade(s)`, 120, y + 4.5);

      doc.setFont('helvetica', 'bold');
      doc.text(`${cat.totalSales.toLocaleString('pt-AO')} Kz`, pageWidth - 18, y + 4.5, { align: 'right' });

      y += 6.5;
    });

    y += 4;
  }

  // Section 3: Balanço de Pedidos & Entregas
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('3. BALANÇO DE ENCOMENDAS & LOGÍSTICA', 14, y);
  y += 5;

  const orderStats = [
    { label: 'Total de Encomendas Registadas', val: `${summary.statusCounts?.total || 0}` },
    { label: 'Entregues com Sucesso (Luanda)', val: `${summary.statusCounts?.entregues || 0}` },
    { label: 'Em Preparação / Em Transporte', val: `${(summary.statusCounts?.emPreparacao || 0) + (summary.statusCounts?.emTransporte || 0)}` },
    { label: 'Aguardando Pagamento / Pendentes', val: `${(summary.statusCounts?.pendentes || 0) + (summary.statusCounts?.aguardandoPagamento || 0)}` },
    { label: 'Canceladas', val: `${summary.statusCounts?.cancelados || 0}` },
  ];

  orderStats.forEach((st, idx) => {
    const isOdd = idx % 2 === 1;
    if (isOdd) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y, pageWidth - 28, 6, 'F');
    }

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(slate[0], slate[1], slate[2]);
    doc.text(st.label, 18, y + 4);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text(st.val, pageWidth - 18, y + 4, { align: 'right' });

    y += 6;
  });

  y += 4;

  // Section 4: Despesas Recentes (if provided)
  if (expenses && expenses.length > 0 && y < 240) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text('4. REGISTO DETALHADO DE DESPESAS', 14, y);
    y += 5;

    doc.setFillColor(navy[0], navy[1], navy[2]);
    doc.rect(14, y, pageWidth - 28, 6.5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('DATA', 18, y + 4.5);
    doc.text('DESCRIÇÃO', 50, y + 4.5);
    doc.text('CATEGORIA', 120, y + 4.5);
    doc.text('VALOR (Kz)', pageWidth - 18, y + 4.5, { align: 'right' });
    y += 6.5;

    const listToDisplay = expenses.slice(0, 8);
    listToDisplay.forEach((exp, idx) => {
      if (y > 275) return;
      const isOdd = idx % 2 === 1;
      if (isOdd) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, pageWidth - 28, 6, 'F');
      }

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(navy[0], navy[1], navy[2]);
      doc.text(new Date(exp.date).toLocaleDateString('pt-PT'), 18, y + 4);
      doc.text((exp.title || '').slice(0, 32), 50, y + 4);
      doc.text(exp.category, 120, y + 4);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(red[0], red[1], red[2]);
      doc.text(`-${exp.amount.toLocaleString('pt-AO')} Kz`, pageWidth - 18, y + 4, { align: 'right' });

      y += 6;
    });
  }

  // Footer on page bottom
  const footerY = 286;
  doc.setDrawColor(226, 232, 240);
  doc.line(14, footerY - 4, pageWidth - 14, footerY - 4);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text('CarcubaExpress Comércio · Relatório Oficial Contabilístico emitido no Sistema', 14, footerY);
  doc.text('Luanda, Angola', pageWidth - 14, footerY, { align: 'right' });

  // Save file directly to device
  const filenameDate = customDate || summary.selectedDate || new Date().toISOString().slice(0, 10);
  doc.save(`Relatorio_CarcubaExpress_${filenameDate}.pdf`);
}

/**
 * Generates an official, printable CarcubaExpress A4 Invoice / Receipt (Fatura Recibo) for delivered & paid orders.
 * Includes official 1-Week Warranty (7 days) and customer product variations (Size & Color).
 */
export function generateOrderInvoicePDF(order: Order, settings?: StoreSettings | null) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Theme Brand Colors
  const navy = [11, 30, 54] as const;
  const amber = [217, 119, 6] as const;
  const green = [5, 150, 105] as const;
  const slate = [100, 116, 139] as const;
  const darkText = [30, 41, 59] as const;

  // Safe variables
  const orderNumber = order?.orderNumber || '0000';
  const customerName = order?.customerName || 'Cliente Estimado';
  const customerPhone = order?.customerPhone || 'Não especificado';
  const customerEmail = order?.customerEmail || '';
  const deliveryMunicipality = order?.deliveryMunicipality || 'Luanda';
  const deliveryAddress = order?.deliveryAddress || 'Endereço Luanda';
  const statusStr = (order?.status || 'Entregue').toUpperCase();
  const paymentStatusStr = (order?.paymentStatus || 'Confirmado').toUpperCase();
  const paymentMethodStr = order?.paymentMethod || 'No acto da entrega';
  const items = Array.isArray(order?.items) ? order.items : [];
  const subtotal = Number(order?.subtotal || 0);
  const shippingFee = Number(order?.shippingFee || 0);
  const total = Number(order?.total || subtotal + shippingFee);

  // 1. Header Dark Banner (Clean separation of left and right meta columns)
  const headerHeight = 39;
  doc.setFillColor(navy[0], navy[1], navy[2]);
  doc.rect(0, 0, pageWidth, headerHeight, 'F');

  // Gold accent line under header
  doc.setFillColor(amber[0], amber[1], amber[2]);
  doc.rect(0, headerHeight, pageWidth, 2, 'F');

  // Brand Name (Left)
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('CARCUBA', 14, 12.5);
  const brandWidth = doc.getTextWidth('CARCUBA');
  doc.setTextColor(251, 191, 36);
  doc.text('EXPRESS', 14 + brandWidth + 1.5, 12.5);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(226, 232, 240);
  doc.text('COMÉRCIO & DISTRIBUIÇÃO EM LUANDA · ANGOLA', 14, 18);

  const phone = settings?.supportPhone || '+244 951 556 411';
  const email = settings?.email || 'carcubaexpresscomercio@gmail.com';
  const address = settings?.address || 'Luanda, Angola (Entregas ao domicílio)';

  doc.setFontSize(7.2);
  doc.setTextColor(203, 213, 225);
  doc.text(`Tel / WhatsApp: ${phone}`, 14, 23.5);
  doc.text(`Email: ${email}`, 14, 28.5);
  doc.text(`Endereço: ${address}`, 14, 33.5);

  // Document Title & Invoice Meta on Right side of Header (Separated with right margin)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11.5);
  doc.setTextColor(255, 255, 255);
  doc.text('FATURA / RECIBO', pageWidth - 14, 12.5, { align: 'right' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(251, 191, 36);
  doc.text(`Nº FR-${orderNumber}`, pageWidth - 14, 18, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.setTextColor(226, 232, 240);
  const nowStr = new Date().toLocaleDateString('pt-PT') + ' ' + new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
  doc.text(`Data de Emissão: ${nowStr}`, pageWidth - 14, 23.5, { align: 'right' });
  doc.text(`Via do Cliente · Luanda, Angola`, pageWidth - 14, 28.5, { align: 'right' });

  let y = 46;

  // 2. Status Badge / Validation Banner
  const isDelivered = order?.status === 'Entregue';
  const isPaid = order?.paymentStatus === 'Confirmado' || isDelivered;

  doc.setFillColor(240, 253, 244); // light green bg
  doc.setDrawColor(187, 247, 208); // green border
  doc.roundedRect(14, y, pageWidth - 28, 13, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(green[0], green[1], green[2]);
  doc.text(isPaid ? 'COMPROVATIVO DE VENDA E PAGAMENTO LIQUIDADO' : 'FATURA / ENCOMENDA REGISTADA', 18, y + 5.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text(`Estado da Entrega: ${statusStr}  |  Estado do Pagamento: ${paymentStatusStr}`, 18, y + 10);

  y += 18;

  // 3. Customer & Logistics Two-Column Box
  const colWidth = (pageWidth - 32) / 2;

  // Left Column: Customer details
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, colWidth, 36, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('DADOS DO CLIENTE', 18, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(darkText[0], darkText[1], darkText[2]);
  doc.text(`Nome: ${customerName}`, 18, y + 13);
  doc.text(`Telefone: ${customerPhone}`, 18, y + 19);
  if (customerEmail) {
    doc.text(`Email: ${customerEmail}`, 18, y + 25);
  }
  doc.text(`Nº Encomenda: ${orderNumber}`, 18, y + (customerEmail ? 31 : 25));

  // Right Column: Delivery location & courier
  const rightX = 14 + colWidth + 4;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(rightX, y, colWidth, 36, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('LOCALIZAÇÃO & ESTAFETA (LUANDA)', rightX + 4, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(darkText[0], darkText[1], darkText[2]);
  doc.text(`Município: ${deliveryMunicipality}`, rightX + 4, y + 13);
  const splitAddress = doc.splitTextToSize(`Endereço: ${deliveryAddress}`, colWidth - 8);
  doc.text(splitAddress.slice(0, 2), rightX + 4, y + 19);

  const courierInfo = order?.courierName || order?.deliveryAgent
    ? `Estafeta: ${order.courierName || order.deliveryAgent}${order.courierPhone ? ` (${order.courierPhone})` : ''}`
    : 'Estafeta: Equipa de Distribuição CarcubaExpress';
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(amber[0], amber[1], amber[2]);
  doc.text(courierInfo, rightX + 4, y + 31);

  y += 41;

  // 4. Products Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('DISCRIMINAÇÃO DOS ARTIGOS VENDIDOS', 14, y);
  y += 4;

  // Table Header
  doc.setFillColor(navy[0], navy[1], navy[2]);
  doc.rect(14, y, pageWidth - 28, 6.5, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text('#', 18, y + 4.5);
  doc.text('DESCRIÇÃO DO ARTIGO & ESPECIFICAÇÕES', 26, y + 4.5);
  doc.text('QTD', 125, y + 4.5);
  doc.text('PREÇO UNIT.', 143, y + 4.5);
  doc.text('TOTAL (Kz)', pageWidth - 18, y + 4.5, { align: 'right' });
  y += 6.5;

  // Rows
  if (items.length === 0) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    doc.setTextColor(slate[0], slate[1], slate[2]);
    doc.text('Nenhum artigo especificado nesta fatura.', 18, y + 5);
    y += 8;
  } else {
    items.forEach((item, idx) => {
      const isOdd = idx % 2 === 1;
      if (isOdd) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, pageWidth - 28, 7.5, 'F');
      }

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(darkText[0], darkText[1], darkText[2]);
      doc.text(String(idx + 1), 18, y + 5);

      // Build item label with size and color if available
      const parts = [item.productName || 'Artigo CarcubaExpress'];
      const specs = [];
      if (item.size) specs.push(`Tam: ${item.size}`);
      if (item.color) specs.push(`Cor: ${item.color}`);
      if (specs.length > 0) parts.push(`[${specs.join(', ')}]`);
      const itemDesc = parts.join(' ').slice(0, 56);
      doc.text(itemDesc, 26, y + 5);

      const qty = Number(item.quantity || 1);
      const unitPrice = Number(item.price || 0);

      doc.text(String(qty), 125, y + 5);
      doc.text(`${unitPrice.toLocaleString('pt-AO')} Kz`, 143, y + 5);

      doc.setFont('helvetica', 'bold');
      doc.text(`${(unitPrice * qty).toLocaleString('pt-AO')} Kz`, pageWidth - 18, y + 5, { align: 'right' });

      y += 7.5;
    });
  }

  y += 4;

  // 5. Financial Totals & Payment Method Box
  const summaryBoxWidth = 85;
  const summaryBoxX = pageWidth - 14 - summaryBoxWidth;

  // Payment note box on left
  const paymentBoxWidth = pageWidth - 28 - summaryBoxWidth - 6;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, paymentBoxWidth, 32, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('CONDIÇÕES DE PAGAMENTO', 18, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(darkText[0], darkText[1], darkText[2]);
  doc.text(`Forma de Pagamento: ${paymentMethodStr}`, 18, y + 13);
  doc.text(`Estado da Liquidação: ${paymentStatusStr}`, 18, y + 19);
  doc.setFontSize(7.5);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text('Pagamento conferido no acto da recepção da encomenda.', 18, y + 25);

  // Totals box on right
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(summaryBoxX, y, summaryBoxWidth, 32, 2, 2, 'FD');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text('Subtotal Mercadorias:', summaryBoxX + 4, y + 7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(darkText[0], darkText[1], darkText[2]);
  doc.text(`${subtotal.toLocaleString('pt-AO')} Kz`, pageWidth - 18, y + 7, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text('Taxa de Entrega:', summaryBoxX + 4, y + 13.5);
  doc.setFont('helvetica', 'bold');
  doc.text(shippingFee === 0 ? 'GRÁTIS' : `${shippingFee.toLocaleString('pt-AO')} Kz`, pageWidth - 18, y + 13.5, { align: 'right' });

  // Highlighted Total Bar
  doc.setFillColor(254, 243, 199); // light amber
  doc.rect(summaryBoxX + 1, y + 19, summaryBoxWidth - 2, 11, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text('TOTAL PAGO:', summaryBoxX + 4, y + 26);

  doc.setFontSize(10.5);
  doc.setTextColor(amber[0], amber[1], amber[2]);
  doc.text(`${total.toLocaleString('pt-AO')} Kz`, pageWidth - 18, y + 26, { align: 'right' });

  y += 38;

  // 6. Highlighted Warranty Banner: GARANTIA OFICIAL DE 1 SEMANA (7 DIAS)
  doc.setFillColor(255, 251, 235); // amber-50
  doc.setDrawColor(245, 158, 11); // amber-500
  doc.roundedRect(14, y, pageWidth - 28, 18, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(180, 83, 9); // amber-700
  doc.text('GARANTIA OFICIAL CARCUBAEXPRESS: 1 SEMANA (7 DIAS)', 18, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(darkText[0], darkText[1], darkText[2]);
  doc.text('Garantia válida por 7 dias corridos após a recepção física do artigo em Luanda.', 18, y + 11);
  doc.text('Cobre defeitos de fabrico e anomalias de funcionamento, com direito a assistência técnica ou troca imediata.', 18, y + 15);

  y += 22;

  // 7. Legal Notice Box
  doc.setFillColor(250, 250, 250);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, pageWidth - 28, 13, 2, 2, 'FD');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text('Declaração: O presente documento comprova a entrega física dos bens e a respectiva quitação financeira em Luanda.', 18, y + 5);
  doc.text('Guarde esta fatura/recibo impressa ou em PDF para acionar a garantia oficial de 1 semana se necessário.', 18, y + 9.5);

  // 8. Footer
  const footerY = pageHeight - 12;
  doc.setDrawColor(226, 232, 240);
  doc.line(14, footerY - 4, pageWidth - 14, footerY - 4);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(slate[0], slate[1], slate[2]);
  doc.text(`CarcubaExpress Comércio Geral · Luanda, Angola · Apoio ao Cliente: ${phone}`, 14, footerY);
  doc.text(`Documento emitido por computador · FR-${orderNumber}`, pageWidth - 14, footerY, { align: 'right' });

  // Trigger download safely
  try {
    doc.save(`Fatura_Recibo_CarcubaExpress_${orderNumber}.pdf`);
  } catch (err) {
    console.error('Erro ao descarregar PDF da fatura:', err);
  }
}

/**
 * Builds a formatted WhatsApp invoice / receipt text to be sent directly to the customer.
 */
export function buildInvoiceWhatsAppMessage(order: Order, settings?: StoreSettings | null): string {
  const storeName = settings?.storeName || 'CarcubaExpress Comércio';
  const phone = settings?.supportPhone || '+244 951 556 411';
  const orderNumber = order?.orderNumber || '0000';
  const customerName = order?.customerName || 'Estimado(a) Cliente';
  const items = Array.isArray(order?.items) ? order.items : [];
  const subtotal = Number(order?.subtotal || 0);
  const shippingFee = Number(order?.shippingFee || 0);
  const total = Number(order?.total || subtotal + shippingFee);

  const itemsList = items.length > 0
    ? items
        .map(it => {
          const specs = [];
          if (it.size) specs.push(`Tam: ${it.size}`);
          if (it.color) specs.push(`Cor: ${it.color}`);
          const specStr = specs.length > 0 ? ` (${specs.join(', ')})` : '';
          const lineTotal = ((Number(it.price) || 0) * (Number(it.quantity) || 1)).toLocaleString('pt-AO');
          return `• ${it.quantity}x *${it.productName}*${specStr} — ${lineTotal} Kz`;
        })
        .join('\n')
    : '• Artigos adquiridos na CarcubaExpress';

  const lines = [
    `🧾 *FATURA / RECIBO DE VENDA — ${storeName.toUpperCase()}*`,
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    `Olá *${customerName}*, segue o seu comprovativo oficial de entrega e pagamento da CarcubaExpress:`,
    ``,
    `📋 *Documento:* FR-${orderNumber}`,
    `📅 *Data da Compra:* ${order?.createdAt ? new Date(order.createdAt).toLocaleDateString('pt-PT') : new Date().toLocaleDateString('pt-PT')}`,
    `📍 *Local de Entrega:* ${order?.deliveryMunicipality || 'Luanda'}, ${order?.deliveryAddress || ''}`,
    order?.deliveryReference ? `📌 *Referência:* ${order.deliveryReference}` : '',
    order?.courierName || order?.deliveryAgent ? `🏍️ *Estafeta:* ${order.courierName || order.deliveryAgent}${order.courierPhone ? ` (${order.courierPhone})` : ''}` : '',
    ``,
    `📦 *ARTIGOS ENTREGUES:*`,
    itemsList,
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    `Subtotal: ${subtotal.toLocaleString('pt-AO')} Kz`,
    `Taxa de Entrega: ${shippingFee === 0 ? 'GRÁTIS' : `${shippingFee.toLocaleString('pt-AO')} Kz`}`,
    `💰 *TOTAL PAGO:* *${total.toLocaleString('pt-AO')} Kz*`,
    `💳 *Forma de Pagamento:* ${order?.paymentMethod || 'No acto da entrega'}`,
    `✅ *Estado:* Pedido Entregue e Pagamento Concluído com Sucesso`,
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    `🛡️ *GARANTIA OFICIAL: 1 SEMANA (7 DIAS)*`,
    `Todos os seus artigos têm garantia de 7 dias a contar da entrega para troca ou assistência técnica em caso de anomalia de fabrico.`,
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    `Agradecemos sinceramente pela sua preferência e confiança na CarcubaExpress!`,
    `Qualquer dúvida ou assistência, contacte-nos pelo WhatsApp oficial: ${phone}`,
  ];

  return lines.filter(line => line !== '').join('\n');
}

/**
 * Directly opens customer's WhatsApp with pre-filled invoice receipt.
 */
export function openInvoiceWhatsApp(order: Order, settings?: StoreSettings | null) {
  const rawPhone = order?.customerPhone || '';
  const cleanPhone = rawPhone.replace(/\D/g, '');
  const targetPhone = cleanPhone
    ? cleanPhone.startsWith('244')
      ? cleanPhone
      : '244' + cleanPhone
    : '244951556411';
  const message = buildInvoiceWhatsAppMessage(order, settings);
  const url = `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

