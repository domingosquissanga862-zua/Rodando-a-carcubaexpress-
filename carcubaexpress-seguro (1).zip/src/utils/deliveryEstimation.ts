/**
 * Utility functions for Estimated Delivery Date calculation and formatting for Luanda, Angola
 */

export function calculateEstimatedDeliveryDate(createdAtStr?: string, municipality?: string): {
  date: Date;
  formattedDate: string;
  relativeLabel: string;
  timeWindow: string;
} {
  const baseDate = createdAtStr ? new Date(createdAtStr) : new Date();
  const validBase = isNaN(baseDate.getTime()) ? new Date() : baseDate;

  // Determine days based on Luanda municipality
  const munLower = (municipality || '').toLowerCase();
  let daysToAdd = 1;

  if (munLower.includes('icolo') || munLower.includes('bengo') || munLower.includes('quiçama')) {
    daysToAdd = 3;
  } else if (munLower.includes('viana') || munLower.includes('cacuaco') || munLower.includes('belas') || munLower.includes('kilamba')) {
    daysToAdd = 2;
  } else {
    // Luanda urbana, Maianga, Talatona, Ingombota, etc.
    daysToAdd = 1;
  }

  // Calculate target date
  const target = new Date(validBase.getTime() + daysToAdd * 24 * 60 * 60 * 1000);

  // If falls on Sunday, push to Monday
  if (target.getDay() === 0) {
    target.setDate(target.getDate() + 1);
  }

  const formattedDate = target.toLocaleDateString('pt-PT', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // Capitalize first letter of weekday
  const capitalized = formattedDate.charAt(0).toUpperCase() + formattedDate.slice(1);

  // Check if today or tomorrow
  const now = new Date();
  const isSameDay =
    now.getDate() === target.getDate() &&
    now.getMonth() === target.getMonth() &&
    now.getFullYear() === target.getFullYear();

  let relativeLabel = `${daysToAdd === 1 ? 'Em 24h úteis' : `${daysToAdd} dias úteis`}`;
  if (isSameDay) {
    relativeLabel = 'Hoje (No próprio dia)';
  }

  return {
    date: target,
    formattedDate: capitalized,
    relativeLabel,
    timeWindow: '08h30 às 18h00 (Horário Comercial)',
  };
}

export function formatEstimatedDeliveryDate(dateStr?: string, createdAtStr?: string, municipality?: string): {
  formattedDate: string;
  timeWindow: string;
  relativeLabel: string;
  isCustom: boolean;
} {
  if (dateStr && dateStr.trim()) {
    try {
      // Handles both "YYYY-MM-DD" and full ISO
      const parts = dateStr.includes('T') ? dateStr.split('T')[0].split('-') : dateStr.split('-');
      let dateObj: Date;
      if (parts.length === 3) {
        dateObj = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]), 12, 0, 0);
      } else {
        dateObj = new Date(dateStr);
      }

      if (!isNaN(dateObj.getTime())) {
        const formatted = dateObj.toLocaleDateString('pt-PT', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        });
        const capitalized = formatted.charAt(0).toUpperCase() + formatted.slice(1);
        return {
          formattedDate: capitalized,
          timeWindow: '08h30 às 18h00 (Horário Comercial)',
          relativeLabel: 'Data Confirmada pela Distribuição',
          isCustom: true,
        };
      }
    } catch {
      // Fallback
    }
  }

  // Calculate default estimate
  const calc = calculateEstimatedDeliveryDate(createdAtStr, municipality);
  return {
    formattedDate: calc.formattedDate,
    timeWindow: calc.timeWindow,
    relativeLabel: calc.relativeLabel,
    isCustom: false,
  };
}
