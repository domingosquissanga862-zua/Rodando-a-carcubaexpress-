import { createRoot } from 'react-dom/client';
import App from './App';
import { CookieBanner } from './components/common/CookieBanner';
import { PublicLegalPage } from './pages/PublicLegalPage';
import { matchPublicLegalPath } from './pages/publicLegalPages';
import './index.css';

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  // Rotas públicas permanentes (/privacy-policy e /terms): não exigem sessão
  // e não inicializam o fluxo de autenticação da loja.
  const legalPage = matchPublicLegalPath(window.location.pathname);
  root.render(
    <>
      {legalPage ? <PublicLegalPage page={legalPage} /> : <App />}
      <CookieBanner />
    </>
  );
}
