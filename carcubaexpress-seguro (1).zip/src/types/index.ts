export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'admin' | 'customer';
  createdAt?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  costPrice: number;
  promoPrice?: number;
  categoryId: string;
  categoryName: string;
  images: string[];
  stock: number;
  sizes?: string[];
  colors?: string[];
  isActive: boolean;
  isFeatured: boolean;
  freeShipping: boolean;
  shippingFee?: number;
  shippingFeeLabel?: string;
  createdAt: string;
  updatedAt: string;
}

export type OrderStatus =
  | 'Pendente'
  | 'A aguardar pagamento'
  | 'Pagamento confirmado'
  | 'Em preparação'
  | 'Em transporte'
  | 'Entregue'
  | 'Cancelado';

export type PaymentStatus =
  | 'Pendente'
  | 'Confirmado'
  | 'No acto da entrega'
  | 'Cancelado'
  | 'Reembolsado';

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  costPrice: number;
  quantity: number;
  image: string;
  size?: string;
  color?: string;
}

export interface StatusHistoryEntry {
  status: OrderStatus;
  timestamp: string;
  changedBy: string;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId?: string;
  customerName: string;
  customerEmail?: string;
  customerPhone: string;
  deliveryAddress: string;
  deliveryMunicipality: string;
  deliveryReference?: string;
  items: OrderItem[];
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'Dinheiro (no acto da entrega)' | 'Multicaixa Express' | 'Pagamento no acto da entrega' | 'Transferência Multicaixa';
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  statusHistory: StatusHistoryEntry[];
  deliveryAgent?: string;
  courierName?: string;
  courierPhone?: string;
  estimatedDeliveryDate?: string;
  notes?: string;
  whatsappSent?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  title: string;
  category: 'Transporte & Logística' | 'Embalagens' | 'Marketing & Publicidade' | 'Comunicação & Net' | 'Salários & Operacional' | 'Outros';
  amount: number;
  date: string;
  note?: string;
  createdById: string;
  createdByName: string;
  createdAt: string;
}

export interface MunicipalityConfig {
  name: string;
  fee: number;
  estimatedHours: string;
}

export interface StoreSettings {
  storeName: string;
  storeDescription?: string;
  whatsappNumber: string;
  supportPhone: string;
  email: string;
  city: string;
  country: string;
  address?: string;
  currency: string;
  currencySymbol: string;
  defaultShippingFee: number;
  freeShippingMinAmount: number;
  deliveryMunicipalities: MunicipalityConfig[];
  // Informative texts / descriptions
  deliveryPolicyTitle?: string;
  deliveryPolicyText?: string;
  paymentPolicyTitle?: string;
  paymentPolicyText?: string;
  termsPolicyTitle?: string;
  termsPolicyText?: string;
  supportPolicyTitle?: string;
  supportPolicyText?: string;
  footerDepartments?: string[];
}

export interface FinancialSummary {
  period: string;
  selectedDate?: string | null;
  currency: string;
  totalRevenue: number;
  confirmedPaidRevenue: number;
  deliveredRevenue: number;
  cogsTotal: number;
  totalExpenses: number;
  estimatedNetProfit: number;
  confirmedNetProfit: number;
  averageOrderValue: number;
  statusCounts: {
    total: number;
    pendentes: number;
    aguardandoPagamento: number;
    emPreparacao: number;
    emTransporte: number;
    entregues: number;
    cancelados: number;
  };
  productStats: {
    total: number;
    available: number;
    lowStockCount: number;
    outOfStockCount: number;
    lowStockList: Product[];
    allProductsList?: Product[];
  };
  last7Days: { date: string; label: string; sales: number; count: number }[];
  categorySales: { name: string; totalSales: number; unitsSold: number }[];
  formulaDescription: string;
}

export interface CustomerData {
  id: string;
  name: string;
  email: string;
  phone: string;
  createdAt: string;
  ordersCount: number;
  totalSpent: number;
  lastOrderDate: string | null;
}
