import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { api } from './services/api';
import type { Product, Category, Order } from './types';

// Common Components
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { HeroBanner } from './components/store/HeroBanner';
import { ProductCard } from './components/store/ProductCard';
import { ProductDetailModal } from './components/store/ProductDetailModal';
import { CartDrawer } from './components/store/CartDrawer';
import { CheckoutModal } from './components/store/CheckoutModal';
import { OrderSuccessModal } from './components/store/OrderSuccessModal';

// Customer Components
import { OrderTrackingView } from './components/customer/OrderTrackingView';
import { CustomerPortal } from './components/customer/CustomerPortal';
import { AuthModal } from './components/auth/AuthModal';
import { ResetPasswordModal } from './components/auth/ResetPasswordModal';
import { LegalModal } from './components/legal/LegalModal';

// Admin Components
import { AdminLayout, type AdminTab } from './components/admin/AdminLayout';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminOrders } from './components/admin/AdminOrders';
import { AdminProducts } from './components/admin/AdminProducts';
import { AdminCategories } from './components/admin/AdminCategories';
import { AdminCustomers } from './components/admin/AdminCustomers';
import { AdminDeliveries } from './components/admin/AdminDeliveries';
import { AdminFinancials } from './components/admin/AdminFinancials';
import { AdminReports } from './components/admin/AdminReports';
import { AdminSettings } from './components/admin/AdminSettings';

import { Sparkles, Truck, ShieldCheck, RefreshCw, Filter, AlertCircle, X } from 'lucide-react';

function StorefrontApp() {
  const { user, isAdmin, isLoading: isAuthLoading, isRecoveryMode, setIsRecoveryMode, authError, clearAuthError } = useAuth();
  const { setIsCartOpen, setIsCheckoutOpen, isCheckoutOpen } = useCart();

  // Navigation & View state
  const [view, setView] = useState<'store' | 'admin' | 'tracking' | 'customer-portal'>('store');
  const [trackingOrderNumber, setTrackingOrderNumber] = useState<string>('');

  // Catalog state with instant localStorage hydration (0ms load)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('carcuba_cached_products_v2');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('carcuba_cached_categories_v2');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [onlyFreeShipping, setOnlyFreeShipping] = useState<boolean>(false);
  const [isLoadingProducts, setIsLoadingProducts] = useState<boolean>(() => {
    try {
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('carcuba_cached_products_v2');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return false;
        }
      }
    } catch {
      // ignore
    }
    return true;
  });

  // Modals state
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authInitialTab, setAuthInitialTab] = useState<'login' | 'register' | 'admin'>('login');
  const [legalModalTab, setLegalModalTab] = useState<'terms' | 'privacy' | 'shipping' | 'warranty' | null>(null);

  // Successful Order receipt
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);
  const [successWhatsAppUrl, setSuccessWhatsAppUrl] = useState<string>('');
  const [successWhatsAppMessage, setSuccessWhatsAppMessage] = useState<string>('');

  // Admin Dashboard sub-tab state
  const [adminTab, setAdminTab] = useState<AdminTab>('dashboard');
  const [adminNewProductFlag, setAdminNewProductFlag] = useState<boolean>(false);

  const loadCatalog = async () => {
    // Only display spinner if catalog is completely empty
    if (products.length === 0) {
      setIsLoadingProducts(true);
    }
    try {
      const [prodRes, catRes] = await Promise.all([
        api.getProducts({ activeOnly: true }),
        api.getCategories(),
      ]);
      if (prodRes?.products && prodRes.products.length > 0) {
        setProducts(prodRes.products);
        try {
          localStorage.setItem('carcuba_cached_products_v2', JSON.stringify(prodRes.products));
        } catch {
          // ignore
        }
      }
      if (catRes?.categories && catRes.categories.length > 0) {
        setCategories(catRes.categories);
        try {
          localStorage.setItem('carcuba_cached_categories_v2', JSON.stringify(catRes.categories));
        } catch {
          // ignore
        }
      }
    } catch (err) {
      console.error('Erro ao carregar catálogo da loja:', err);
    } finally {
      setIsLoadingProducts(false);
    }
  };

  useEffect(() => {
    loadCatalog();
  }, []);

  const handleOrderSuccess = (order: Order, whatsappUrl: string, whatsappMessage: string) => {
    setSuccessOrder(order);
    setSuccessWhatsAppUrl(whatsappUrl);
    setSuccessWhatsAppMessage(whatsappMessage);
  };

  const handleTrackOrderFromSuccess = (orderNumber: string) => {
    setSuccessOrder(null);
    setTrackingOrderNumber(orderNumber);
    setView('tracking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAccount = () => {
    if (!user) {
      setAuthInitialTab('login');
      setIsAuthModalOpen(true);
    } else {
      setView('customer-portal');
    }
  };

  const isOfficialAdmin = Boolean(isAdmin && user?.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com');

  // Proteção rigorosa de rotas privadas (Painel do Cliente e Painel de Administração)
  // Redireciona imediatamente para o login se não existir sessão válida no Supabase
  useEffect(() => {
    if (!isAuthLoading) {
      if (view === 'customer-portal' && !user) {
        setView('store');
        setAuthInitialTab('login');
        setIsAuthModalOpen(true);
      } else if (view === 'admin' && !isOfficialAdmin) {
        setView('store');
        setAuthInitialTab('login');
        setIsAuthModalOpen(true);
      }
    }
  }, [view, user, isAuthLoading, isOfficialAdmin]);

  const handleOpenAdminFromHeader = () => {
    if (isOfficialAdmin) {
      setView('admin');
    } else {
      setAuthInitialTab('login');
      setIsAuthModalOpen(true);
    }
  };

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'name'>('featured');

  // Filtered and sorted products list
  const filteredProducts = products
    .filter(p => {
      const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
      const matchesShipping = !onlyFreeShipping || p.freeShipping;
      const term = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !term ||
        p.name.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term) ||
        p.categoryName.toLowerCase().includes(term);
      return matchesCategory && matchesShipping && matchesSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (a.isFeatured !== b.isFeatured) return a.isFeatured ? -1 : 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  const featuredProducts = products.filter(p => p.isFeatured);

  // If in Admin View and authenticated strictly as domingosquissanga862@gmail.com
  if (view === 'admin') {
    if (!isOfficialAdmin) {
      setView('store');
      return null;
    }

    return (
      <AdminLayout
        currentTab={adminTab}
        onSelectTab={setAdminTab}
        onExitAdmin={() => setView('store')}
        onNewProduct={() => {
          setAdminTab('products');
          setAdminNewProductFlag(true);
        }}
      >
        {adminTab === 'dashboard' && (
          <AdminDashboard
            onNavigateTab={setAdminTab}
            onOpenProductModal={() => {
              setAdminTab('products');
              setAdminNewProductFlag(true);
            }}
            onViewOrder={order => {
              setAdminTab('orders');
            }}
          />
        )}
        {adminTab === 'orders' && <AdminOrders />}
        {adminTab === 'products' && (
          <AdminProducts
            initialOpenNewModal={adminNewProductFlag}
            onResetNewModalFlag={() => setAdminNewProductFlag(false)}
          />
        )}
        {adminTab === 'categories' && <AdminCategories />}
        {adminTab === 'customers' && <AdminCustomers />}
        {adminTab === 'deliveries' && <AdminDeliveries />}
        {adminTab === 'financials' && <AdminFinancials />}
        {adminTab === 'reports' && <AdminReports />}
        {adminTab === 'settings' && <AdminSettings />}
      </AdminLayout>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans text-slate-800">
      {/* Navigation Top Bar */}
      <Header
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={catId => {
          setSelectedCategory(catId);
          setView('store');
        }}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onOpenAuth={handleOpenAccount}
        onOpenAdmin={handleOpenAdminFromHeader}
        onNavigateHome={() => setView('store')}
        onNavigateTracking={() => setView('tracking')}
        onOpenLegal={tab => setLegalModalTab(tab || 'terms')}
      />

      {/* Global Auth Error Notification */}
      {authError && (
        <div className="bg-rose-50 border-b border-rose-200 px-4 py-3 text-xs text-rose-800 flex items-center justify-between shadow-sm animate-fade-in">
          <div className="max-w-7xl mx-auto flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="font-medium">{authError}</span>
          </div>
          <button
            onClick={clearAuthError}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors cursor-pointer"
            title="Fechar aviso"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main View Area */}
      <main className="flex-1">
        {view === 'tracking' ? (
          <OrderTrackingView
            initialOrderNumber={trackingOrderNumber}
            onBackToStore={() => setView('store')}
          />
        ) : view === 'customer-portal' ? (
          <CustomerPortal
            onTrackOrder={orderNumber => {
              setTrackingOrderNumber(orderNumber);
              setView('tracking');
            }}
            onBackToStore={() => setView('store')}
            onNavigateAdmin={() => {
              if (isOfficialAdmin) {
                setView('admin');
                setAdminTab('dashboard');
              }
            }}
          />
        ) : (
          /* Public Storefront */
          <>
            {/* Hero Section */}
            <HeroBanner
              onScrollToCatalog={() => {
                const el = document.getElementById('catalogo');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              onQuickView={setQuickViewProduct}
              featuredProducts={products}
            />

            {/* Catalog Section */}
            <section id="catalogo" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
              {/* Category Filter Tabs & Toolbar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl sm:text-2xl font-extrabold text-[#0B1E36] tracking-tight">
                      Catálogo de Produtos em Luanda
                    </h2>
                    <span className="bg-amber-100 text-amber-900 text-xs font-bold px-2.5 py-0.5 rounded-full font-mono">
                      {filteredProducts.length}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Artigos com garantia CarcubaExpress e pagamento seguro no acto da entrega
                  </p>
                </div>

                {/* Filter Controls: Sort, Free Shipping, Refresh */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Sorting dropdown */}
                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 shadow-xs">
                    <span className="text-[11px] text-slate-400 font-medium whitespace-nowrap">Ordenar:</span>
                    <select
                      value={sortBy}
                      onChange={e => setSortBy(e.target.value as any)}
                      className="text-xs font-semibold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
                    >
                      <option value="featured">Destaques</option>
                      <option value="price-asc">Menor Preço</option>
                      <option value="price-desc">Maior Preço</option>
                      <option value="name">Nome (A - Z)</option>
                    </select>
                  </div>

                  <button
                    onClick={() => setOnlyFreeShipping(!onlyFreeShipping)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                      onlyFreeShipping
                        ? 'bg-emerald-600 text-white'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Entrega Grátis</span>
                  </button>

                  <button
                    onClick={loadCatalog}
                    className="p-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:text-slate-900 transition-colors shadow-xs cursor-pointer"
                    title="Atualizar produtos"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingProducts ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Segmented Category Buttons */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === 'all'
                      ? 'bg-[#0B1E36] text-white shadow-md'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  Todos ({products.length})
                </button>
                {categories.map(cat => {
                  const count = products.filter(p => p.categoryId === cat.id).length;
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#0B1E36] text-white shadow-md'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      {cat.name} ({count})
                    </button>
                  );
                })}
              </div>

              {/* Active filter chip */}
              {(selectedCategory !== 'all' || onlyFreeShipping || searchTerm) && (
                <div className="flex items-center gap-2 flex-wrap text-xs text-slate-600 pt-1">
                  <span className="font-medium text-slate-500">Filtros ativos:</span>
                  {selectedCategory !== 'all' && (
                    <span className="bg-amber-100 text-amber-900 px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1">
                      {categories.find(c => c.id === selectedCategory)?.name || selectedCategory}
                      <button onClick={() => setSelectedCategory('all')} className="hover:text-rose-600 ml-1">×</button>
                    </span>
                  )}
                  {onlyFreeShipping && (
                    <span className="bg-emerald-100 text-emerald-900 px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1">
                      Entrega Grátis
                      <button onClick={() => setOnlyFreeShipping(false)} className="hover:text-rose-600 ml-1">×</button>
                    </span>
                  )}
                  {searchTerm && (
                    <span className="bg-slate-200 text-slate-800 px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1">
                      "{searchTerm}"
                      <button onClick={() => setSearchTerm('')} className="hover:text-rose-600 ml-1">×</button>
                    </span>
                  )}
                  <button
                    onClick={() => {
                      setSelectedCategory('all');
                      setOnlyFreeShipping(false);
                      setSearchTerm('');
                    }}
                    className="text-amber-600 hover:underline font-bold text-[11px] ml-1"
                  >
                    Limpar todos
                  </button>
                </div>
              )}

              {/* Products Grid: 2 columns on mobile, 3 on md, 4 on lg */}
              {isLoadingProducts ? (
                <div className="py-20 text-center text-slate-400 space-y-3">
                  <RefreshCw className="w-8 h-8 animate-spin mx-auto text-amber-500" />
                  <p className="text-xs">A carregar produtos da CarcubaExpress...</p>
                </div>
              ) : filteredProducts.length === 0 ? (
                <div className="py-16 text-center bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
                  <p className="font-bold text-slate-800 text-sm">Nenhum produto encontrado</p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Não encontramos nenhum artigo correspondente aos filtros selecionados.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCategory('all');
                      setSearchTerm('');
                      setOnlyFreeShipping(false);
                    }}
                    className="mt-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs cursor-pointer shadow-sm"
                  >
                    Ver Todo o Catálogo
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
                  {filteredProducts.map(product => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onQuickView={setQuickViewProduct}
                      onRequireAuth={(tab) => {
                        setAuthInitialTab(tab || 'login');
                        setIsAuthModalOpen(true);
                      }}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenAdmin={handleOpenAdminFromHeader}
        onNavigateTracking={() => {
          setView('tracking');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenLegal={tab => setLegalModalTab(tab || 'terms')}
      />

      {/* Cart Drawer */}
      <CartDrawer
        onProceedToCheckout={() => {
          if (!user) {
            setAuthInitialTab('login');
            setIsAuthModalOpen(true);
            return;
          }
          setIsCheckoutOpen(true);
        }}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Order Success Modal with direct WhatsApp forwarder */}
      <OrderSuccessModal
        order={successOrder}
        whatsappUrl={successWhatsAppUrl}
        whatsappMessage={successWhatsAppMessage}
        onClose={() => setSuccessOrder(null)}
        onTrackOrder={handleTrackOrderFromSuccess}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onDirectCheckout={() => {
          if (!user) {
            setAuthInitialTab('login');
            setIsAuthModalOpen(true);
            return;
          }
          setIsCheckoutOpen(true);
        }}
        onRequireAuth={() => {
          setQuickViewProduct(null);
          setAuthInitialTab('login');
          setIsAuthModalOpen(true);
        }}
      />

      {/* Auth Modal (Customer & Admin) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAdminLoginSuccess={() => {
          setView('admin');
          setAdminTab('dashboard');
        }}
        onCustomerLoginSuccess={() => {
          setView('customer-portal');
        }}
        initialTab={authInitialTab}
      />

      {/* Password Reset Modal (Supabase PASSWORD_RECOVERY Flow) */}
      <ResetPasswordModal
        isOpen={isRecoveryMode}
        onSuccess={() => {
          setIsRecoveryMode(false);
          setView('store');
        }}
        onClose={() => setIsRecoveryMode(false)}
      />

      {/* Official Legal Policies Modal */}
      <LegalModal
        isOpen={Boolean(legalModalTab)}
        onClose={() => setLegalModalTab(null)}
        initialTab={legalModalTab || 'terms'}
      />

      {/* Floating Action Button: WhatsApp */}
      <FloatingWhatsApp />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <StorefrontApp />
      </CartProvider>
    </AuthProvider>
  );
}
