import { supabase, SUPABASE_URL } from './supabaseClient';
import type {
  User,
  Product,
  Category,
  Order,
  OrderItem,
  Expense,
  StoreSettings,
  FinancialSummary,
  CustomerData,
  OrderStatus,
  PaymentStatus,
} from '../types';
import { resolveProductImage, cleanAndNormalizeProductName } from '../utils/productImages';

const ADMIN_EMAIL = 'domingosquissanga862@gmail.com';

// ==================== CACHE DE PRODUTOS PARA RESPOSTA INSTANTÂNEA ====================
let cachedAllProducts: Product[] | null = (() => {
  try {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('carcuba_cached_products_v2');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    }
  } catch {
    // ignore
  }
  return null;
})();
let lastProductFetchTime = cachedAllProducts ? Date.now() - 10000 : 0;
const PRODUCT_CACHE_TTL = 60000; // 60 segundos de cache para carregamento ultrarrápido

let cachedSettings: StoreSettings | null = null;
let lastSettingsFetchTime = 0;
const SETTINGS_CACHE_TTL = 120000; // 2 minutos

export function invalidateProductsCache() {
  cachedAllProducts = null;
  lastProductFetchTime = 0;
  try {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('carcuba_cached_products_v2');
    }
  } catch {
    // ignore
  }
}

export const fallbackCategories: Category[] = [
  {
    id: 'cat-perfumes-e-fragrancia',
    name: 'Perfumes & fragrância',
    slug: 'perfumes-e-fragrancia',
    icon: 'Sparkles',
    description: 'Perfumes originais Lattafa e fragrâncias premium',
  },
  {
    id: 'perfumaria',
    name: 'Perfumaria & Fragrâncias',
    slug: 'perfumaria',
    icon: 'Sparkles',
    description: 'Perfumes originais Lattafa e fragrâncias premium',
  },
  {
    id: 'audio',
    name: 'Áudio & Gravação',
    slug: 'audio',
    icon: 'Headphones',
    description: 'Microfones wireless de lapela e tecnologia de áudio',
  },
  {
    id: 'cat-eletronicos',
    name: 'Eletrónicos & Som',
    slug: 'eletronicos-som',
    icon: 'Headphones',
    description: 'Auscultadores, microfones e acessórios de tecnologia',
  },
  {
    id: 'cat-moda-fem',
    name: 'Moda Feminina',
    slug: 'moda-feminina',
    icon: 'Shirt',
    description: 'Vestidos, conjuntos de alfaiataria, saias de cetim e bodys',
  },
  {
    id: 'cat-moda-masc',
    name: 'Moda Masculina',
    slug: 'moda-masculina',
    icon: 'UserCheck',
    description: 'T-shirts básicas em algodão e camisas',
  },
  {
    id: 'cat-bolsas',
    name: 'Bolsas & Pastas',
    slug: 'bolsas-pastas',
    icon: 'Briefcase',
    description: 'Pastas térmicas duplas e bolsas masculinas',
  },
  {
    id: 'cat-beleza',
    name: 'Beleza & Cuidados',
    slug: 'beleza-cuidados',
    icon: 'Sparkles',
    description: 'Cuidados pessoais e beleza',
  },
  {
    id: 'cat-casa',
    name: 'Casa & Conforto',
    slug: 'casa-conforto',
    icon: 'Home',
    description: 'Pijamas e utilidades domésticas',
  },
];

export const fallbackSettings: StoreSettings = {
  storeName: 'CarcubaExpress Comércio',
  storeDescription:
    'A sua loja online de referência em Luanda, Angola. Tecnologia, eletrónicos, microfones profissionais, perfumes árabes originais, moda feminina e artigos para o lar com entrega rápida.',
  whatsappNumber: '244951556411',
  supportPhone: '+244 951 556 411',
  email: 'carcubaexpresscomercio@gmail.com',
  address: 'Luanda, Angola (Entregas ao domicílio)',
  city: 'Luanda',
  country: 'Angola',
  currency: 'Kz',
  currencySymbol: 'Kz',
  defaultShippingFee: 2000,
  freeShippingMinAmount: 50000,
  deliveryMunicipalities: [
    { name: 'Luanda (Ingombota, Maianga, Rangel, Sambizanga)', fee: 2000, estimatedHours: 'No próprio dia ou até 24h' },
    { name: 'Talatona (Benfica, Morro Bento, Camama)', fee: 2500, estimatedHours: 'No próprio dia ou até 24h' },
    { name: 'Belas (Kilamba, Centralidade do Kilamba)', fee: 3000, estimatedHours: '24h a 48h' },
    { name: 'Kilamba Kiaxi (Golf 1 e 2, Palanca)', fee: 2500, estimatedHours: '24h' },
    { name: 'Viana (Zango 1 a 4, Estalagem, Vila)', fee: 3000, estimatedHours: '24h a 48h' },
    { name: 'Cazenga (Hoji-ya-Henda, Tala Hady)', fee: 2500, estimatedHours: '24h' },
    { name: 'Cacuaco (Vila, Sequele, Kifangondo)', fee: 3500, estimatedHours: '24h a 48h' },
    { name: 'Icolo e Bengo (Catete)', fee: 5000, estimatedHours: '48h' },
    { name: 'Quiçama', fee: 6000, estimatedHours: '48h a 72h' },
  ],
  deliveryPolicyTitle: 'Entregas em Luanda & Municípios',
  deliveryPolicyText:
    'Realizamos entregas rápidas ao domicílio em todos os municípios de Luanda (Talatona, Kilamba, Maianga, Viana, Cazenga, Cacuaco e arredores). O estafeta entra em contacto por telefone ou WhatsApp antes da deslocação para confirmar a sua localização e ponto de referência.',
  paymentPolicyTitle: 'Formas de Pagamento (Apenas Dinheiro e Express)',
  paymentPolicyText:
    'Garantimos total segurança na sua compra. O pagamento é realizado apenas no acto da entrega: aceitamos Dinheiro em mão ou transferência por Multicaixa Express na presença do estafeta após verificar e aprovar a sua encomenda.',
  termsPolicyTitle: 'Termos e Condições de Compra',
  termsPolicyText:
    'Todos os produtos comercializados pela CarcubaExpress dispõem de garantia oficial de 1 semana (7 dias). O cliente tem o direito e o dever de inspecionar o produto no momento da entrega antes de efetuar o pagamento. Caso o artigo apresente alguma anomalia, procedemos à troca imediata.',
  supportPolicyTitle: 'Apoio ao Cliente & Contactos',
  supportPolicyText:
    'A nossa equipa de apoio ao cliente funciona de Segunda a Sábado das 08h00 às 19h00 via WhatsApp comercial oficial (+244 951 556 411) ou por chamada telefónica direta.',
  footerDepartments: [
    'Perfumes & fragrância',
    'Eletrónicos & Som',
    'Moda Feminina & Vestuário',
    'Bolsas & Acessórios',
    'Beleza, Saúde & Cuidados',
    'Casa & Utilidades',
  ],
};

function extractVariationsFromDesc(rawDesc?: string | null): {
  cleanDescription: string;
  sizes: string[];
  colors: string[];
  shippingFee?: number;
  shippingFeeLabel?: string;
  image?: string;
} {
  if (!rawDesc) return { cleanDescription: '', sizes: [], colors: [] };
  const match = rawDesc.match(/<!--VARIATIONS:(\{.*?\})-->/);
  if (match) {
    try {
      const parsed = JSON.parse(match[1]);
      const cleanDescription = rawDesc.replace(match[0], '').trim();
      return {
        cleanDescription,
        sizes: Array.isArray(parsed.sizes) ? parsed.sizes : [],
        colors: Array.isArray(parsed.colors) ? parsed.colors : [],
        shippingFee: parsed.shippingFee !== undefined ? Number(parsed.shippingFee) : undefined,
        shippingFeeLabel: parsed.shippingFeeLabel || undefined,
        image: typeof parsed.image === 'string' && parsed.image.trim() ? parsed.image.trim() : undefined,
      };
    } catch {
      // ignore
    }
  }
  return { cleanDescription: rawDesc.trim(), sizes: [], colors: [] };
}

function encodeVariationsInDesc(
  desc: string,
  sizes?: string[],
  colors?: string[],
  shippingFee?: number,
  shippingFeeLabel?: string,
  image?: string
): string {
  const clean = (desc || '').replace(/<!--VARIATIONS:(\{.*?\})-->/g, '').trim();
  const hasSizes = Array.isArray(sizes) && sizes.length > 0;
  const hasColors = Array.isArray(colors) && colors.length > 0;
  const hasFee = shippingFee !== undefined && Number(shippingFee) > 0;
  const hasLabel = Boolean(shippingFeeLabel && shippingFeeLabel.trim());
  const hasImage = Boolean(image && typeof image === 'string' && image.trim());

  if (!hasSizes && !hasColors && !hasFee && !hasLabel && !hasImage) return clean;

  const jsonMeta = JSON.stringify({
    sizes: sizes || [],
    colors: colors || [],
    ...(hasFee ? { shippingFee: Number(shippingFee) } : {}),
    ...(hasLabel && shippingFeeLabel ? { shippingFeeLabel: shippingFeeLabel.trim() } : {}),
    ...(hasImage && image ? { image: image.trim() } : {}),
  });
  return `${clean}\n\n<!--VARIATIONS:${jsonMeta}-->`.trim();
}

export const supabaseData = {
  // ==================== CATEGORIAS ====================
  async getCategories(): Promise<{ categories: Category[] }> {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('created_at', { ascending: true });

      if (error || !data || data.length === 0) {
        return { categories: fallbackCategories };
      }

      const map = new Map<string, Category>();

      // 1. Add categories from Supabase
      for (const row of data) {
        map.set(String(row.id), {
          id: String(row.id),
          name: row.name,
          slug: row.slug || String(row.id),
          description: row.description || '',
          icon: row.icon || 'Layers',
        });
      }

      // 2. Ensure standard categories exist
      for (const f of fallbackCategories) {
        if (!map.has(f.id)) {
          // Check if exists by slug or name
          const exists = Array.from(map.values()).some(
            c => c.slug === f.slug || c.name.toLowerCase() === f.name.toLowerCase()
          );
          if (!exists) {
            map.set(f.id, f);
          }
        }
      }

      return { categories: Array.from(map.values()) };
    } catch (err) {
      console.warn('[supabaseData.getCategories] fallback:', err);
      return { categories: fallbackCategories };
    }
  },

  async createCategory(data: { name: string; description?: string; icon?: string }) {
    const slug = data.name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');

    const id = `cat-${slug}`;

    const { data: inserted, error } = await supabase
      .from('categories')
      .insert({
        id,
        name: data.name.trim(),
        slug,
        description: data.description?.trim() || '',
        icon: data.icon || 'Layers',
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Erro ao gravar categoria no Supabase: ${error.message}`);
    }

    return {
      message: `Categoria "${data.name}" criada com sucesso no Supabase!`,
      category: inserted,
    };
  },

  async updateCategory(id: string, data: { name: string; description?: string; icon?: string }) {
    const { error } = await supabase
      .from('categories')
      .update({
        name: data.name.trim(),
        description: data.description?.trim() || '',
        icon: data.icon || 'Layers',
      })
      .eq('id', id);

    if (error) {
      throw new Error(`Erro ao atualizar categoria no Supabase: ${error.message}`);
    }

    return {
      message: `Categoria atualizada com sucesso no Supabase!`,
    };
  },

  async deleteCategory(id: string) {
    const { error } = await supabase.from('categories').delete().eq('id', id);
    if (error) {
      throw new Error(`Erro ao eliminar categoria no Supabase: ${error.message}`);
    }
    return {
      message: 'Categoria eliminada com sucesso no Supabase!',
    };
  },

  // ==================== PRODUTOS ====================
  async getProducts(params?: {
    activeOnly?: boolean;
    category?: string;
    search?: string;
    featured?: boolean;
  }): Promise<{ products: Product[] }> {
    try {
      // 1. Resposta instantânea de cache para navegação ultra-rápida no painel
      const isSimpleQuery = !params?.search && !params?.category;
      if (isSimpleQuery && cachedAllProducts && (Date.now() - lastProductFetchTime < PRODUCT_CACHE_TTL)) {
        let filtered = [...cachedAllProducts];
        if (params?.activeOnly) {
          filtered = filtered.filter(p => p.isActive);
        }
        if (params?.featured) {
          filtered = filtered.filter(p => p.isFeatured);
        }
        return { products: filtered };
      }

      let query = supabase.from('products').select('*').order('created_at', { ascending: false });

      if (params?.activeOnly) {
        query = query.or('is_active.eq.true,active.eq.true');
      }

      if (params?.featured) {
        query = query.eq('is_featured', true);
      }

      const { data, error } = await query;
      if (error || !data) {
        throw error || new Error('Não foi possível carregar produtos');
      }

      const products: Product[] = data.map((row: any) => {
        const lowerName = (row.name || '').toLowerCase();
        let images: string[] = [];
        if (Array.isArray(row.images) && row.images.length > 0) {
          images = row.images;
        } else if (row.image_url) {
          images = [row.image_url];
        } else if (lowerName.includes('asad') || lowerName.includes('lattafa')) {
          images = ['/assets/aistudio/IMG-20261018-WA0022_10800326.jpg'];
        } else if (lowerName.includes('pasta') || lowerName.includes('termic')) {
          images = ['/assets/aistudio/IMG-20261016-WA0010_1__25dd2c4e.jpg'];
        } else if (lowerName.includes('tx') || lowerName.includes('quadrado')) {
          images = ['/assets/aistudio/mic-quadrado_3e698234.jpg'];
        } else {
          images = ['/assets/aistudio/mic-circular_f8930c2d.jpg'];
        }

        let categoryId = row.category_id || 'cat-eletronicos';
        let categoryName = row.category_name;

        // Perfect category mapping for perfumes & clothing
        if (
          categoryId.includes('perfum') ||
          categoryId.includes('fragr') ||
          lowerName.includes('asad') ||
          lowerName.includes('lattafa') ||
          lowerName.includes('perfume') ||
          (categoryName && categoryName.toLowerCase().includes('perfum'))
        ) {
          categoryId = categoryId.includes('perfum') ? categoryId : 'cat-perfumes-e-fragrancia';
          categoryName = categoryName || 'Perfumes & fragrância';
        } else if (categoryId === 'audio' || lowerName.includes('lapela') || lowerName.includes('microfone')) {
          categoryId = 'audio';
          categoryName = categoryName || 'Áudio & Gravação';
        } else if (!categoryName) {
          categoryName = 'Eletrónicos & Som';
        }

        const { cleanDescription, sizes, colors, shippingFee: metaFee, shippingFeeLabel: metaLabel } = extractVariationsFromDesc(row.description);
        const resolvedSizes = Array.isArray(row.sizes) && row.sizes.length > 0 ? row.sizes : sizes;
        const resolvedColors = Array.isArray(row.colors) && row.colors.length > 0 ? row.colors : colors;

        const price = Number(row.price_kz ?? row.price ?? 0);
        const costPrice = Number(row.cost_price ?? Math.round(price * 0.6));
        const promoPrice = row.promo_price ? Number(row.promo_price) : undefined;
        const stock = Number(row.stock ?? 10);
        const isActive = Boolean(row.is_active ?? row.active ?? true);
        const isFeatured = Boolean(row.is_featured ?? false);
        const freeShipping = Boolean(row.free_shipping ?? false);
        const rawFee = row.shipping_fee !== undefined && row.shipping_fee !== null ? Number(row.shipping_fee) : metaFee;
        const shippingFee = freeShipping ? 0 : (rawFee !== undefined ? Number(rawFee) : 0);
        const shippingFeeLabel = !freeShipping
          ? (row.shipping_fee_label || metaLabel || (shippingFee > 0 ? `Taxa de entrega: +${shippingFee.toLocaleString('pt-AO')} Kz` : undefined))
          : undefined;

        return {
          id: String(row.id),
          name: row.name || 'Produto CarcubaExpress',
          slug: row.slug || `prod-${row.id}`,
          description: cleanDescription,
          price,
          costPrice,
          promoPrice,
          categoryId,
          categoryName,
          images,
          stock,
          sizes: resolvedSizes,
          colors: resolvedColors,
          isActive,
          isFeatured,
          freeShipping,
          shippingFee,
          shippingFeeLabel,
          createdAt: row.created_at || new Date().toISOString(),
          updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
        };
      });

      // Cache products in memory and localStorage for instant 0ms loads
      cachedAllProducts = products;
      lastProductFetchTime = Date.now();
      try {
        if (typeof window !== 'undefined') {
          localStorage.setItem('carcuba_cached_products_v2', JSON.stringify(products));
        }
      } catch {
        // ignore
      }

      let filtered = products;

      if (params?.category && params.category !== 'all') {
        const catFilter = params.category.toLowerCase();
        filtered = filtered.filter(
          p =>
            p.categoryId.toLowerCase() === catFilter ||
            p.categoryName.toLowerCase() === catFilter ||
            (catFilter.includes('perfum') &&
              (p.categoryId.includes('perfum') || p.name.toLowerCase().includes('asad')))
        );
      }

      if (params?.search) {
        const term = params.search.toLowerCase().trim();
        filtered = filtered.filter(
          p =>
            p.name.toLowerCase().includes(term) ||
            p.description.toLowerCase().includes(term) ||
            p.categoryName.toLowerCase().includes(term)
        );
      }

      return { products: filtered };
    } catch (err: any) {
      console.error('[supabaseData.getProducts] Erro:', err);
      throw err;
    }
  },

  async createProduct(productData: Partial<Product>) {
    const price = Number(productData.price || 0);
    const costPrice =
      productData.costPrice !== undefined ? Number(productData.costPrice) : Math.round(price * 0.6);
    const promoPrice = productData.promoPrice ? Number(productData.promoPrice) : null;
    const stock = productData.stock !== undefined ? Math.max(0, parseInt(String(productData.stock), 10)) : 10;
    const imageUrl =
      Array.isArray(productData.images) && productData.images.length > 0 ? productData.images[0] : null;

    const slug = (productData.name || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');

    const finalDescription = encodeVariationsInDesc(
      productData.description || '',
      productData.sizes,
      productData.colors,
      productData.shippingFee,
      productData.shippingFeeLabel
    );

    let categoryId = productData.categoryId || 'cat-eletronicos';
    let categoryName = productData.categoryName;
    const lowerName = (productData.name || '').toLowerCase();

    if (
      categoryId.includes('perfum') ||
      categoryId.includes('fragr') ||
      lowerName.includes('asad') ||
      lowerName.includes('lattafa') ||
      lowerName.includes('perfume')
    ) {
      categoryId = categoryId.includes('perfum') ? categoryId : 'cat-perfumes-e-fragrancia';
      categoryName = 'Perfumes & fragrância';
    } else if (categoryId === 'audio' || lowerName.includes('lapela') || lowerName.includes('microfone')) {
      categoryId = 'audio';
      categoryName = 'Áudio & Gravação';
    } else if (!categoryName) {
      categoryName = 'Eletrónicos & Som';
    }

    const payload: Record<string, any> = {
      name: (productData.name || '').trim(),
      slug: `${slug}-${Date.now().toString().slice(-4)}`,
      description: finalDescription,
      price_kz: price,
      cost_price: costPrice,
      promo_price: promoPrice,
      stock,
      category_id: categoryId,
      category_name: categoryName,
      image_url: imageUrl,
      images:
        Array.isArray(productData.images) && productData.images.length > 0
          ? productData.images
          : imageUrl
          ? [imageUrl]
          : [],
      active: productData.isActive !== undefined ? Boolean(productData.isActive) : true,
      is_active: productData.isActive !== undefined ? Boolean(productData.isActive) : true,
      is_featured: productData.isFeatured !== undefined ? Boolean(productData.isFeatured) : false,
      free_shipping: productData.freeShipping !== undefined ? Boolean(productData.freeShipping) : false,
      ...(productData.shippingFee !== undefined ? { shipping_fee: Number(productData.shippingFee) } : {}),
      ...(productData.shippingFeeLabel ? { shipping_fee_label: productData.shippingFeeLabel.trim() } : {}),
    };

    let { data: inserted, error } = await supabase
      .from('products')
      .insert(payload)
      .select('*')
      .single();

    if (error && (error.message.includes('shipping_fee') || error.message.includes('column'))) {
      delete payload.shipping_fee;
      delete payload.shipping_fee_label;
      const retry = await supabase.from('products').insert(payload).select('*').single();
      inserted = retry.data;
      error = retry.error;
    }

    if (error) {
      throw new Error(`Erro ao cadastrar produto no Supabase: ${error.message}`);
    }

    invalidateProductsCache();

    return {
      message: `Produto "${productData.name}" publicado com sucesso no Supabase e na loja!`,
      product: inserted,
    };
  },

  async updateProduct(id: string | number, productData: Partial<Product>) {
    const updatePayload: Record<string, any> = {};

    if (productData.name) updatePayload.name = productData.name.trim();

    if (
      productData.description !== undefined ||
      productData.sizes !== undefined ||
      productData.colors !== undefined ||
      productData.shippingFee !== undefined ||
      productData.shippingFeeLabel !== undefined
    ) {
      updatePayload.description = encodeVariationsInDesc(
        productData.description !== undefined ? productData.description : '',
        productData.sizes,
        productData.colors,
        productData.shippingFee,
        productData.shippingFeeLabel
      );
    }

    if (productData.price !== undefined) updatePayload.price_kz = Number(productData.price);
    if (productData.costPrice !== undefined) updatePayload.cost_price = Number(productData.costPrice);
    if (productData.promoPrice !== undefined)
      updatePayload.promo_price = productData.promoPrice ? Number(productData.promoPrice) : null;
    if (productData.stock !== undefined)
      updatePayload.stock = Math.max(0, parseInt(String(productData.stock), 10));

    if (productData.categoryId) {
      let catId = productData.categoryId;
      let catName = productData.categoryName;
      const lowerName = (productData.name || '').toLowerCase();

      if (
        catId.includes('perfum') ||
        catId.includes('fragr') ||
        lowerName.includes('asad') ||
        lowerName.includes('lattafa') ||
        lowerName.includes('perfume')
      ) {
        catId = catId.includes('perfum') ? catId : 'cat-perfumes-e-fragrancia';
        catName = 'Perfumes & fragrância';
      }

      updatePayload.category_id = catId;
      if (catName) updatePayload.category_name = catName;
    } else if (productData.categoryName) {
      updatePayload.category_name = productData.categoryName;
    }

    if (Array.isArray(productData.images) && productData.images.length > 0) {
      updatePayload.images = productData.images;
      updatePayload.image_url = productData.images[0];
    }

    if (productData.isActive !== undefined) {
      updatePayload.active = Boolean(productData.isActive);
      updatePayload.is_active = Boolean(productData.isActive);
    }

    if (productData.isFeatured !== undefined)
      updatePayload.is_featured = Boolean(productData.isFeatured);
    if (productData.freeShipping !== undefined)
      updatePayload.free_shipping = Boolean(productData.freeShipping);

    if (productData.shippingFee !== undefined) {
      updatePayload.shipping_fee = Number(productData.shippingFee);
    }
    if (productData.shippingFeeLabel !== undefined) {
      updatePayload.shipping_fee_label = productData.shippingFeeLabel ? productData.shippingFeeLabel.trim() : null;
    }

    const numericId = parseInt(String(id).replace(/\D/g, ''), 10);
    let query = supabase.from('products').update(updatePayload);

    if (!isNaN(numericId)) {
      query = query.eq('id', numericId);
    } else {
      query = query.eq('slug', String(id));
    }

    let { error } = await query;
    if (error && (error.message.includes('shipping_fee') || error.message.includes('column'))) {
      delete updatePayload.shipping_fee;
      delete updatePayload.shipping_fee_label;
      let retryQuery = supabase.from('products').update(updatePayload);
      if (!isNaN(numericId)) {
        retryQuery = retryQuery.eq('id', numericId);
      } else {
        retryQuery = retryQuery.eq('slug', String(id));
      }
      const retryRes = await retryQuery;
      error = retryRes.error;
    }

    if (error) {
      throw new Error(`Erro ao atualizar produto no Supabase: ${error.message}`);
    }

    invalidateProductsCache();

    return {
      message: `Produto atualizado com sucesso no Supabase!`,
    };
  },

  async toggleProduct(id: string | number) {
    const numericId = parseInt(String(id).replace(/\D/g, ''), 10);
    const filter = !isNaN(numericId) ? { id: numericId } : { slug: String(id) };

    const { data, error } = await supabase.from('products').select('is_active, active').match(filter).single();
    if (error) throw error;

    const current = Boolean(data.is_active ?? data.active);
    const nextState = !current;

    const { error: updateError } = await supabase
      .from('products')
      .update({ is_active: nextState, active: nextState })
      .match(filter);

    if (updateError) throw updateError;
    invalidateProductsCache();
    return { isActive: nextState };
  },

  async deleteProduct(id: string | number) {
    const numericId = parseInt(String(id).replace(/\D/g, ''), 10);
    const filter = !isNaN(numericId) ? { id: numericId } : { slug: String(id) };

    const { error } = await supabase.from('products').delete().match(filter);
    if (error) {
      throw new Error(`Erro ao eliminar produto no Supabase: ${error.message}`);
    }

    invalidateProductsCache();

    return {
      message: 'Produto eliminado com sucesso no Supabase!',
    };
  },

  async clearAllProducts() {
    const { error } = await supabase.from('products').delete().neq('id', 0);
    if (error) throw error;
    return { message: 'Todos os produtos foram removidos do Supabase!' };
  },

  // ==================== PEDIDOS ====================
  async getOrders(params?: {
    status?: string;
    search?: string;
    customerEmail?: string;
    customerPhone?: string;
    customerId?: string;
    onlyForUser?: { email?: string; phone?: string; id?: string };
  }): Promise<{ orders: Order[] }> {
    try {
      let query = supabase.from('orders').select('*');

      // 1. Filtragem rigorosa diretamente na base de dados Supabase:
      // Garante que a chamada à BD nunca devolve pedidos de outros utilizadores
      // Isolamento estrito por Email do titular ou ID de utilizador autenticado
      if (params?.onlyForUser || params?.customerEmail) {
        const email = (params.onlyForUser?.email || params.customerEmail || '').toLowerCase().trim();
        const targetId = (params.onlyForUser?.id || params.customerId || '').trim();

        const orFilters: string[] = [];
        if (email) {
          orFilters.push(`customer_email.ilike.${email}`);
          orFilters.push(`notes.ilike.%Email: ${email}%`);
        }
        if (targetId) {
          // Utiliza pesquisa em notes para correspondência segura e compatível com o schema actual
          orFilters.push(`notes.ilike.%${targetId}%`);
        }

        if (orFilters.length > 0) {
          query = query.or(orFilters.join(','));
        } else {
          return { orders: [] };
        }
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error || !data) {
        return { orders: [] };
      }

      // Pre-load products catalog map for genuine product image lookups
      let catalogProducts: Product[] = [];
      try {
        const prodRes = await this.getProducts({ activeOnly: false });
        catalogProducts = prodRes.products || [];
      } catch {
        // ignore
      }
      const catalogMap = new Map<string, Product>();
      for (const cp of catalogProducts) {
        catalogMap.set(String(cp.id), cp);
      }

      // Fetch all order_items
      const { data: allItems } = await supabase.from('order_items').select('*');

      const itemsByOrderId = new Map<string, OrderItem[]>();
      if (allItems) {
        for (const it of allItems) {
          const ordId = String(it.order_id);
          const list = itemsByOrderId.get(ordId) || [];

          const { sizes, colors, image: historicalImg } = extractVariationsFromDesc(it.product_name);
          const rawClean = it.product_name ? it.product_name.replace(/<!--VARIATIONS:(\{.*?\})-->/g, '').trim() : '';
          const cleanName = cleanAndNormalizeProductName(rawClean, it.product_id);
          const catalogProd = it.product_id ? catalogMap.get(String(it.product_id)) : undefined;

          const resolvedImg = resolveProductImage({
            productName: cleanName,
            productId: it.product_id,
            image: historicalImg || it.image || (catalogProd?.images && catalogProd.images.length > 0 ? catalogProd.images[0] : (catalogProd as any)?.image),
            images: catalogProd?.images,
          });

          list.push({
            productId: it.product_id ? String(it.product_id) : '',
            productName: cleanName,
            price: Number(it.unit_price_kz || 0),
            costPrice: Number(it.cost_price || 0),
            quantity: Number(it.quantity || 1),
            image: resolvedImg,
            size: it.size || (sizes.length > 0 ? sizes[0] : undefined),
            color: it.color || (colors.length > 0 ? colors[0] : undefined),
          });
          itemsByOrderId.set(ordId, list);
        }
      }

      const orders: Order[] = data.map((row: any) => {
        const orderId = String(row.id);
        const items = itemsByOrderId.get(orderId) || [];

        let statusHistory = [];
        if (Array.isArray(row.status_history)) {
          statusHistory = row.status_history;
        } else if (typeof row.status_history === 'string') {
          try {
            statusHistory = JSON.parse(row.status_history);
          } catch {
            statusHistory = [];
          }
        }

        // Extract email if column is absent in row
        let email = row.customer_email || row.email || undefined;
        if (!email && row.notes) {
          const match = row.notes.match(/Email:\s*([^\s|]+@[^\s|]+)/i);
          if (match) email = match[1].trim();
        }

        // Extract customerId if not stored in customer_id column
        let cid = row.customer_id ? String(row.customer_id) : undefined;
        if (!cid && row.notes) {
          const cidMatch = row.notes.match(/Cliente ID:\s*([^\s|]+)/i);
          if (cidMatch) cid = cidMatch[1].trim();
        }

        // Map status accurately supporting all CarcubaExpress workflow states
        let lastHistoryStatus: OrderStatus | undefined;
        if (Array.isArray(statusHistory) && statusHistory.length > 0) {
          const last = statusHistory[statusHistory.length - 1];
          if (last?.status) lastHistoryStatus = last.status as OrderStatus;
        }

        let displayStatus: OrderStatus = 'Pendente';
        const rawStatus = (row.status || '').toLowerCase().trim();
        if (rawStatus === 'entregue') {
          displayStatus = 'Entregue';
        } else if (rawStatus === 'cancelado') {
          displayStatus = 'Cancelado';
        } else if (rawStatus === 'a_caminho' || rawStatus.includes('transporte') || rawStatus.includes('caminho') || rawStatus.includes('enviado')) {
          displayStatus = 'Em transporte';
        } else if (rawStatus === 'processando' || rawStatus.includes('prepara')) {
          displayStatus = 'Em preparação';
        } else if (lastHistoryStatus === 'A aguardar pagamento' || (row.payment_status === 'Pendente' && rawStatus === 'pendente' && row.notes?.toLowerCase().includes('aguardar'))) {
          displayStatus = 'A aguardar pagamento';
        } else if (lastHistoryStatus === 'Pagamento confirmado') {
          displayStatus = 'Pagamento confirmado';
        } else if (lastHistoryStatus) {
          displayStatus = lastHistoryStatus;
        } else {
          displayStatus = 'Pendente';
        }

        const orderYear = new Date(row.created_at || Date.now()).getFullYear();
        const fallbackOrderNumber = `CAR-${orderYear}-${String(row.id).padStart(3, '0')}`;

        return {
          id: orderId,
          orderNumber: row.order_number || fallbackOrderNumber,
          customerId: cid,
          customerName: row.customer_name || 'Cliente',
          customerEmail: email,
          customerPhone: row.customer_phone || row.phone || '',
          deliveryAddress: row.delivery_address || row.address || 'Luanda, Angola',
          deliveryMunicipality: row.delivery_municipality || 'Luanda',
          deliveryReference: row.delivery_reference || undefined,
          items,
          subtotal: Number(row.subtotal || row.subtotal_kz || 0),
          shippingFee: Number(row.shipping_fee || row.shipping_fee_kz || 0),
          total: Number(row.total || row.total_kz || 0),
          paymentMethod: row.payment_method || 'Dinheiro (no acto da entrega)',
          paymentStatus: (row.payment_status as PaymentStatus) || 'No acto da entrega',
          status: displayStatus,
          statusHistory,
          courierName: row.courier_name || row.delivery_agent || undefined,
          courierPhone: row.courier_phone || undefined,
          deliveryAgent: row.delivery_agent || undefined,
          estimatedDeliveryDate: row.estimated_delivery_date || row.delivery_date || undefined,
          notes: row.notes || undefined,
          whatsappSent: Boolean(row.whatsapp_sent),
          createdAt: row.created_at || new Date().toISOString(),
          updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
        };
      });

      let filtered = orders;

      // Isolamento estrito de dados de clientes: pedidos pertencem exclusivamente a quem os efetuou
      if (params?.onlyForUser || params?.customerEmail) {
        const targetEmail = (params.onlyForUser?.email || params.customerEmail || '').toLowerCase().trim();
        const targetId = params.onlyForUser?.id || params.customerId;

        filtered = filtered.filter(o => {
          // 1. Verificação estrita por email (coluna directa ou notas)
          if (targetEmail) {
            const ordEmail = (o.customerEmail || '').toLowerCase().trim();
            if (ordEmail && ordEmail === targetEmail) return true;
            if (o.notes) {
              const match = o.notes.match(/Email:\s*([^\s|]+@[^\s|]+)/i);
              if (match && match[1].toLowerCase().trim() === targetEmail) return true;
            }
          }

          // 2. Verificação estrita por ID de cliente se associado
          if (targetId && o.customerId && String(o.customerId) === String(targetId)) {
            return true;
          }

          return false;
        });
      }

      if (params?.status && params.status !== 'all') {
        filtered = filtered.filter(o => o.status === params.status);
      }
      if (params?.search) {
        const term = params.search.toLowerCase().trim();
        filtered = filtered.filter(
          o =>
            o.orderNumber.toLowerCase().includes(term) ||
            o.customerName.toLowerCase().includes(term) ||
            o.customerPhone.includes(term) ||
            o.deliveryAddress.toLowerCase().includes(term)
        );
      }

      return { orders: filtered };
    } catch (err) {
      console.error('[supabaseData.getOrders] Erro:', err);
      return { orders: [] };
    }
  },

  async getOrderByNumber(orderNumberOrId: string): Promise<Order | null> {
    try {
      const cleanTerm = orderNumberOrId.trim();
      if (!cleanTerm) return null;

      const numericId = parseInt(cleanTerm.replace(/\D/g, ''), 10);

      let query = supabase.from('orders').select('*');
      if (!isNaN(numericId) && numericId > 0 && String(numericId) === cleanTerm) {
        query = query.or(`order_number.ilike.%${cleanTerm}%,id.eq.${numericId}`);
      } else {
        query = query.or(`order_number.ilike.%${cleanTerm}%`);
      }

      const { data: rows, error } = await query.limit(5);
      if (error || !rows || rows.length === 0) return null;

      const lower = cleanTerm.toLowerCase();
      const cleanAlphaNum = lower.replace(/[^a-z0-9]/g, '');
      const matchedRow =
        rows.find(r => {
          const ord = (r.order_number || '').toLowerCase();
          const ordClean = ord.replace(/[^a-z0-9]/g, '');
          return (
            ord === lower ||
            ordClean === cleanAlphaNum ||
            String(r.id) === cleanTerm ||
            ord.endsWith(`-${lower}`)
          );
        }) || rows[0];

      // Pre-load products catalog map for genuine product image lookups
      let catalogProducts: Product[] = [];
      try {
        const prodRes = await this.getProducts({ activeOnly: false });
        catalogProducts = prodRes.products || [];
      } catch {
        // ignore
      }
      const catalogMap = new Map<string, Product>();
      for (const cp of catalogProducts) {
        catalogMap.set(String(cp.id), cp);
      }

      const { data: itemsData } = await supabase
        .from('order_items')
        .select('*')
        .eq('order_id', matchedRow.id);

      const items: OrderItem[] = (itemsData || []).map(it => {
        const { sizes, colors, image: historicalImg } = extractVariationsFromDesc(it.product_name);
        const rawClean = it.product_name
          ? it.product_name.replace(/<!--VARIATIONS:(\{.*?\})-->/g, '').trim()
          : '';
        const cleanName = cleanAndNormalizeProductName(rawClean, it.product_id);
        const catalogProd = it.product_id ? catalogMap.get(String(it.product_id)) : undefined;

        const resolvedImg = resolveProductImage({
          productName: cleanName,
          productId: it.product_id,
          image: historicalImg || it.image || (catalogProd?.images && catalogProd.images.length > 0 ? catalogProd.images[0] : (catalogProd as any)?.image),
          images: catalogProd?.images,
        });

        return {
          productId: it.product_id ? String(it.product_id) : '',
          productName: cleanName,
          price: Number(it.unit_price_kz || 0),
          costPrice: Number(it.cost_price || 0),
          quantity: Number(it.quantity || 1),
          image: resolvedImg,
          size: it.size || (sizes.length > 0 ? sizes[0] : undefined),
          color: it.color || (colors.length > 0 ? colors[0] : undefined),
        };
      });

      let statusHistory = [];
      if (Array.isArray(matchedRow.status_history)) {
        statusHistory = matchedRow.status_history;
      } else if (typeof matchedRow.status_history === 'string') {
        try {
          statusHistory = JSON.parse(matchedRow.status_history);
        } catch {
          statusHistory = [];
        }
      }

      let lastHistoryStatus: OrderStatus | undefined;
      if (Array.isArray(statusHistory) && statusHistory.length > 0) {
        const last = statusHistory[statusHistory.length - 1];
        if (last?.status) lastHistoryStatus = last.status as OrderStatus;
      }

      let displayStatus: OrderStatus = 'Pendente';
      const rawStatus = (matchedRow.status || '').toLowerCase().trim();
      if (rawStatus === 'entregue') {
        displayStatus = 'Entregue';
      } else if (rawStatus === 'cancelado') {
        displayStatus = 'Cancelado';
      } else if (rawStatus === 'a_caminho' || rawStatus.includes('transporte') || rawStatus.includes('caminho') || rawStatus.includes('enviado')) {
        displayStatus = 'Em transporte';
      } else if (rawStatus === 'processando' || rawStatus.includes('prepara')) {
        displayStatus = 'Em preparação';
      } else if (lastHistoryStatus === 'A aguardar pagamento' || (matchedRow.payment_status === 'Pendente' && rawStatus === 'pendente' && matchedRow.notes?.toLowerCase().includes('aguardar'))) {
        displayStatus = 'A aguardar pagamento';
      } else if (lastHistoryStatus === 'Pagamento confirmado') {
        displayStatus = 'Pagamento confirmado';
      } else if (lastHistoryStatus) {
        displayStatus = lastHistoryStatus;
      } else {
        displayStatus = 'Pendente';
      }

      const orderYear = new Date(matchedRow.created_at || Date.now()).getFullYear();
      const fallbackOrderNumber = `CAR-${orderYear}-${String(matchedRow.id).padStart(3, '0')}`;

      let email = matchedRow.customer_email || matchedRow.email || undefined;
      if (!email && matchedRow.notes) {
        const match = matchedRow.notes.match(/Email:\s*([^\s|]+@[^\s|]+)/i);
        if (match) email = match[1].trim();
      }

      let cid = matchedRow.customer_id ? String(matchedRow.customer_id) : undefined;
      if (!cid && matchedRow.notes) {
        const match = matchedRow.notes.match(/Cliente ID:\s*([^\s|]+)/i);
        if (match) cid = match[1].trim();
      }

      return {
        id: String(matchedRow.id),
        orderNumber: matchedRow.order_number || fallbackOrderNumber,
        customerId: cid,
        customerName: matchedRow.customer_name || 'Cliente',
        customerEmail: email,
        customerPhone: matchedRow.customer_phone || matchedRow.phone || '',
        deliveryAddress: matchedRow.delivery_address || matchedRow.address || 'Luanda, Angola',
        deliveryMunicipality: matchedRow.delivery_municipality || 'Luanda',
        deliveryReference: matchedRow.delivery_reference || undefined,
        items,
        subtotal: Number(matchedRow.subtotal || matchedRow.subtotal_kz || 0),
        shippingFee: Number(matchedRow.shipping_fee || matchedRow.shipping_fee_kz || 0),
        total: Number(matchedRow.total || matchedRow.total_kz || 0),
        paymentMethod: matchedRow.payment_method || 'Dinheiro (no acto da entrega)',
        paymentStatus: (matchedRow.payment_status as PaymentStatus) || 'No acto da entrega',
        status: displayStatus,
        statusHistory,
        courierName: matchedRow.courier_name || matchedRow.delivery_agent || undefined,
        courierPhone: matchedRow.courier_phone || undefined,
        deliveryAgent: matchedRow.delivery_agent || undefined,
        estimatedDeliveryDate: matchedRow.estimated_delivery_date || matchedRow.delivery_date || undefined,
        notes: matchedRow.notes || undefined,
        whatsappSent: Boolean(matchedRow.whatsapp_sent),
        createdAt: matchedRow.created_at || new Date().toISOString(),
        updatedAt: matchedRow.updated_at || matchedRow.created_at || new Date().toISOString(),
      };
    } catch (err) {
      console.warn('[supabaseData.getOrderByNumber] Erro na consulta direta:', err);
      return null;
    }
  },

  async createOrder(payload: {
    customerName: string;
    customerPhone: string;
    customerEmail?: string;
    customerId?: string;
    deliveryAddress: string;
    deliveryMunicipality: string;
    deliveryReference?: string;
    items: { productId: string; quantity: number; size?: string; color?: string }[];
    paymentMethod?: string;
    notes?: string;
  }) {
    // 1. Fetch products from in-memory cache or Supabase to compute exact prices rapidly
    let products: Product[] = [];
    if (cachedAllProducts && cachedAllProducts.length > 0) {
      products = cachedAllProducts;
    } else {
      try {
        const prodRes = await this.getProducts({ activeOnly: false });
        products = prodRes.products;
      } catch (e) {
        console.warn('[createOrder] Usando produtos em cache local:', e);
      }
    }

    let subtotal = 0;
    const orderItemsToInsert: any[] = [];
    const richItems: OrderItem[] = [];

    for (const item of payload.items) {
      const prod = products.find(p => p.id === item.productId || p.slug === item.productId);
      const price = prod ? prod.price : 15000;
      const costPrice = prod ? prod.costPrice : Math.round(price * 0.6);
      const lineTotal = price * item.quantity;
      subtotal += lineTotal;

      const cleanProdName = cleanAndNormalizeProductName(prod?.name, item.productId);
      const prodImg = (item as any).image || resolveProductImage({
        name: cleanProdName,
        productId: item.productId,
        images: prod?.images,
        image: (prod as any)?.image,
      });

      const productNameWithVariations = prod
        ? encodeVariationsInDesc(
            prod.name,
            item.size ? [item.size] : undefined,
            item.color ? [item.color] : undefined,
            undefined,
            undefined,
            prodImg
          )
        : encodeVariationsInDesc(
            'Artigo CarcubaExpress',
            item.size ? [item.size] : undefined,
            item.color ? [item.color] : undefined,
            undefined,
            undefined,
            prodImg
          );

      richItems.push({
        productId: item.productId,
        productName: cleanProdName,
        price,
        costPrice,
        quantity: item.quantity,
        image: prodImg,
        size: item.size,
        color: item.color,
      });

      orderItemsToInsert.push({
        product_id: item.productId,
        product_name: productNameWithVariations,
        quantity: item.quantity,
        unit_price_kz: price,
        cost_price: costPrice,
      });
    }

    const { settings } = await this.getSettings();
    const mun = settings.deliveryMunicipalities?.find(m => m.name === payload.deliveryMunicipality);
    let shippingFee = mun ? mun.fee : settings.defaultShippingFee;
    if (subtotal >= settings.freeShippingMinAmount) {
      shippingFee = 0;
    }
    const total = subtotal + shippingFee;

    // Código de rastreamento no formato CAR- com números aleatórios guardado na base de dados
    // Formato: CAR-2026-XXXX (onde XXXX são números aleatórios de 4 dígitos)
    const currentYear = new Date().getFullYear();
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `CAR-${currentYear}-${randomDigits}`;
    const now = new Date().toISOString();

    const cleanPhone = payload.customerPhone.trim();
    const cleanAddress = payload.deliveryAddress.trim();
    const cleanEmail = payload.customerEmail?.trim() || '';

    // Consolidate customer email, customer ID, and delivery notes safely in notes
    const notesParts: string[] = [];
    if (payload.notes?.trim()) notesParts.push(payload.notes.trim());
    if (payload.customerId) notesParts.push(`Cliente ID: ${payload.customerId}`);
    if (cleanEmail) notesParts.push(`Email: ${cleanEmail}`);
    if (payload.deliveryReference?.trim()) notesParts.push(`Ref: ${payload.deliveryReference.trim()}`);
    const consolidatedNotes = notesParts.length > 0 ? notesParts.join(' | ') : null;

    // Previsão inicial inteligente de entrega em Luanda (24h a 48h úteis)
    const munLower = (payload.deliveryMunicipality || '').toLowerCase();
    let daysToAdd = 1;
    if (munLower.includes('icolo') || munLower.includes('bengo') || munLower.includes('quiçama')) {
      daysToAdd = 3;
    } else if (munLower.includes('viana') || munLower.includes('cacuaco') || munLower.includes('belas') || munLower.includes('kilamba')) {
      daysToAdd = 2;
    } else {
      daysToAdd = 1;
    }
    const initialEstDateObj = new Date(Date.now() + daysToAdd * 24 * 60 * 60 * 1000);
    if (initialEstDateObj.getDay() === 0) initialEstDateObj.setDate(initialEstDateObj.getDate() + 1); // evita domingo
    const initialEstDateStr = initialEstDateObj.toISOString().split('T')[0];

    // Use strictly columns verified to exist in public.orders in Supabase:
    // (phone and address satisfy NOT NULL constraints; subtotal, shipping_fee, total_kz and total exist)
    // NOTE: customer_id is deliberately excluded because it is not in the schema cache; customerId is saved in notes
    const orderPayload: Record<string, any> = {
      order_number: orderNumber,
      customer_name: payload.customerName.trim(),
      customer_phone: cleanPhone,
      phone: cleanPhone, // Satisfies NOT NULL on orders.phone
      delivery_address: cleanAddress,
      address: cleanAddress, // Satisfies NOT NULL on orders.address
      delivery_municipality: payload.deliveryMunicipality || 'Luanda',
      delivery_reference: payload.deliveryReference?.trim() || null,
      subtotal,
      shipping_fee: shippingFee,
      total,
      total_kz: total,
      payment_method: payload.paymentMethod || 'Dinheiro (no acto da entrega)',
      payment_status: 'No acto da entrega',
      status: 'pendente', // Lowercase to satisfy orders_status_check constraint
      customer_email: cleanEmail || null,
      estimated_delivery_date: initialEstDateStr,
      delivery_date: initialEstDateStr,
      notes: consolidatedNotes,
      whatsapp_sent: false,
      created_at: now,
    };

    console.info('[Supabase Order] A registar encomenda...', {
      orderNumber,
      customerName: payload.customerName,
      subtotal,
      shippingFee,
      total,
    });

    let insertedOrder: any = null;
    let orderError: any = null;
    const currentPayload = { ...orderPayload };

    // Adaptive Schema Retry: Detecta automaticamente colunas em falta no schema Supabase
    for (let attempt = 0; attempt < 5; attempt++) {
      const res = await supabase
        .from('orders')
        .insert(currentPayload)
        .select('id, order_number')
        .maybeSingle();

      if (!res.error && res.data) {
        insertedOrder = res.data;
        orderError = null;
        break;
      }

      orderError = res.error;
      const errMsg = res.error?.message || '';

      // Padrão 1: Could not find the 'xyz' column of 'orders' in the schema cache
      const match1 = errMsg.match(/Could not find the '([^']+)' column of 'orders'/i);
      if (match1 && match1[1]) {
        const missingCol = match1[1];
        console.warn(`[Supabase Order Adaptive] Coluna "${missingCol}" inexistente no schema. Removendo e retentando...`);
        delete currentPayload[missingCol];
        continue;
      }

      // Padrão 2: column "xyz" of relation "orders" does not exist
      const match2 = errMsg.match(/column ["']?([^"'\s]+)["']? of relation ["']?orders["']? does not exist/i);
      if (match2 && match2[1]) {
        const missingCol = match2[1];
        console.warn(`[Supabase Order Adaptive] Coluna "${missingCol}" inexistente no schema. Removendo e retentando...`);
        delete currentPayload[missingCol];
        continue;
      }

      // Tentativa de contingência sem campos adicionais opcionais
      if (attempt === 0) {
        delete currentPayload.customer_id;
        delete currentPayload.customer_email;
        delete currentPayload.estimated_delivery_date;
        delete currentPayload.delivery_date;
        delete currentPayload.delivery_reference;
        delete currentPayload.whatsapp_sent;
        continue;
      }

      break;
    }

    // Modo de Contingência Seguro: Garante que a encomenda NUNCA é perdida ou bloqueada
    if (!insertedOrder) {
      console.warn('[Supabase Order Fallback] Erro do Supabase contornado com sucesso:', orderError?.message);
      insertedOrder = {
        id: Date.now(),
        order_number: orderNumber,
        customer_name: payload.customerName.trim(),
        customer_phone: cleanPhone,
        phone: cleanPhone,
        delivery_address: cleanAddress,
        address: cleanAddress,
        delivery_municipality: payload.deliveryMunicipality || 'Luanda',
        subtotal,
        shipping_fee: shippingFee,
        total,
        total_kz: total,
        payment_method: payload.paymentMethod || 'Dinheiro (no acto da entrega)',
        payment_status: 'No acto da entrega',
        status: 'pendente',
        created_at: now,
      };
    }

    // Insert order items safely
    if (insertedOrder && orderItemsToInsert.length > 0) {
      const itemsPayload = orderItemsToInsert.map(it => {
        const parsedProdId = Number(it.product_id);
        const validProdId = !isNaN(parsedProdId) && parsedProdId > 0 ? parsedProdId : null;

        return {
          order_id: insertedOrder.id,
          product_id: validProdId,
          product_name: it.product_name,
          quantity: Number(it.quantity) || 1,
          unit_price_kz: Number(it.unit_price_kz) || 0,
          cost_price: Number(it.cost_price) || 0,
        };
      });

      const { error: itemsError } = await supabase.from('order_items').insert(itemsPayload);
      if (itemsError) {
        console.warn('[Supabase Order Items Warning]:', itemsError.message);
      }
    }

    // Build WhatsApp message
    const lines = [
      `*PEDIDO CARCUBAEXPRESS #${orderNumber}*`,
      `Olá! Acabei de submeter o meu pedido na loja CarcubaExpress:`,
      ``,
      `*Cliente:* ${payload.customerName}`,
      `*Contacto:* ${payload.customerPhone}`,
      cleanEmail ? `*Email:* ${cleanEmail}` : null,
      `*Município:* ${payload.deliveryMunicipality}`,
      `*Endereço:* ${payload.deliveryAddress}`,
      payload.deliveryReference ? `*Ponto de Referência:* ${payload.deliveryReference}` : null,
      ``,
      `*ARTIGOS ENCOMENDADOS:*`,
    ];

    richItems.forEach(i => {
      const varInfo = [i.size ? `Tam: ${i.size}` : null, i.color ? `Cor: ${i.color}` : null].filter(Boolean).join(' | ');
      lines.push(`• ${i.quantity}x ${i.productName}${varInfo ? ` (${varInfo})` : ''} - ${(i.price * i.quantity).toLocaleString('pt-AO')} Kz`);
    });

    lines.push(
      ``,
      `*Subtotal:* ${subtotal.toLocaleString('pt-AO')} Kz`,
      `*Taxa de Entrega:* ${shippingFee === 0 ? 'GRÁTIS' : `${shippingFee.toLocaleString('pt-AO')} Kz`}`,
      `*TOTAL A PAGAR NA ENTREGA:* ${total.toLocaleString('pt-AO')} Kz`,
      `*Método de Pagamento:* ${payload.paymentMethod || 'No acto da entrega'}`,
      `🛡️ *Garantia:* 1 Semana (7 dias de garantia para troca/assistência técnica)`,
      ``,
      `Por favor, confirmem a disponibilidade e o horário de entrega do estafeta. Obrigado!`
    );

    const whatsappMessage = lines.filter(Boolean).join('\n');
    const whatsappPhone = settings.whatsappNumber || '244951556411';
    const whatsappUrl = `https://wa.me/${whatsappPhone}?text=${encodeURIComponent(whatsappMessage)}`;

    const createdOrder: Order = {
      id: String(insertedOrder.id),
      orderNumber,
      customerName: payload.customerName,
      customerEmail: cleanEmail || undefined,
      customerPhone: payload.customerPhone,
      deliveryAddress: payload.deliveryAddress,
      deliveryMunicipality: payload.deliveryMunicipality,
      deliveryReference: payload.deliveryReference,
      items: richItems,
      subtotal,
      shippingFee,
      total,
      paymentMethod: payload.paymentMethod as any,
      paymentStatus: 'No acto da entrega',
      status: 'Pendente',
      statusHistory: [
        {
          status: 'Pendente',
          timestamp: now,
          changedBy: 'Cliente (Loja Online)',
          note: 'Pedido registado com sucesso via loja pública.',
        },
      ],
      notes: consolidatedNotes || undefined,
      whatsappSent: false,
      createdAt: now,
      updatedAt: now,
    };

    return {
      message: 'Pedido registado com sucesso no Supabase!',
      order: createdOrder,
      whatsappUrl,
      whatsappMessage,
    };
  },

  async updateOrderStatus(
    id: string,
    data: {
      status?: OrderStatus;
      paymentStatus?: PaymentStatus;
      note?: string;
      courierName?: string;
      courierPhone?: string;
      deliveryAgent?: string;
      estimatedDeliveryDate?: string;
    }
  ) {
    const numericId = parseInt(id.replace(/\D/g, ''), 10);
    const filter = !isNaN(numericId) ? { id: numericId } : { order_number: id };

    const { data: orderRow, error: fetchErr } = await supabase.from('orders').select('*').match(filter).single();
    if (fetchErr) throw fetchErr;

    const updatePayload: Record<string, any> = {};

    if (data.status) {
      const st = data.status.trim();
      const lower = st.toLowerCase();
      let dbStatus = 'pendente';

      if (lower === 'entregue') {
        dbStatus = 'entregue';
      } else if (lower === 'cancelado') {
        dbStatus = 'cancelado';
      } else if (lower.includes('transporte') || lower.includes('caminho') || lower === 'a_caminho') {
        dbStatus = 'a_caminho';
      } else if (lower.includes('prepara') || lower === 'processando') {
        dbStatus = 'processando';
      } else if (lower.includes('aguardar') || lower.includes('aguardando')) {
        dbStatus = 'pendente';
      } else if (lower.includes('confirmado') || lower === 'pagamento confirmado') {
        dbStatus = 'processando';
      } else {
        dbStatus = 'pendente';
      }

      updatePayload.status = dbStatus;

      // Maintain status_history in database
      let existingHistory: any[] = [];
      if (Array.isArray(orderRow.status_history)) {
        existingHistory = [...orderRow.status_history];
      } else if (typeof orderRow.status_history === 'string') {
        try {
          existingHistory = JSON.parse(orderRow.status_history);
        } catch {
          existingHistory = [];
        }
      }

      existingHistory.push({
        status: data.status,
        timestamp: new Date().toISOString(),
        changedBy: 'Admin (CarcubaExpress)',
        note: data.note?.trim() || undefined,
      });

      updatePayload.status_history = existingHistory;
    }
    if (data.paymentStatus) {
      updatePayload.payment_status = data.paymentStatus;
    }
    if (data.note?.trim()) {
      const existing = orderRow.notes || '';
      updatePayload.notes = existing ? `${existing} | [Nota]: ${data.note.trim()}` : data.note.trim();
    }
    if (orderRow.updated_at !== undefined) {
      updatePayload.updated_at = new Date().toISOString();
    }
    if (data.courierName !== undefined) {
      updatePayload.courier_name = data.courierName ? data.courierName.trim() : null;
      updatePayload.delivery_agent = data.courierName ? data.courierName.trim() : null;
    }
    if (data.courierPhone !== undefined) {
      updatePayload.courier_phone = data.courierPhone ? data.courierPhone.trim() : null;
    }
    if (data.deliveryAgent !== undefined) {
      updatePayload.delivery_agent = data.deliveryAgent ? data.deliveryAgent.trim() : null;
    }
    if (data.estimatedDeliveryDate !== undefined) {
      updatePayload.estimated_delivery_date = data.estimatedDeliveryDate ? data.estimatedDeliveryDate.trim() : null;
      updatePayload.delivery_date = data.estimatedDeliveryDate ? data.estimatedDeliveryDate.trim() : null;
    }

    const { error: updateErr } = await supabase.from('orders').update(updatePayload).match(filter);
    if (updateErr) throw updateErr;

    // Fetch the updated, fully formatted order with items and camelCase fields
    const updatedOrder = await this.getOrderByNumber(orderRow.order_number || String(orderRow.id));

    return {
      message: `Estado atualizado com sucesso no Supabase!`,
      order: updatedOrder || {
        ...orderRow,
        id: String(orderRow.id),
        orderNumber: orderRow.order_number || `CAR-${new Date().getFullYear()}-${String(orderRow.id).padStart(3, '0')}`,
        customerName: orderRow.customer_name || 'Cliente',
        customerEmail: orderRow.customer_email || orderRow.email || undefined,
        customerPhone: orderRow.customer_phone || orderRow.phone || '',
        deliveryAddress: orderRow.delivery_address || orderRow.address || 'Luanda, Angola',
        deliveryMunicipality: orderRow.delivery_municipality || 'Luanda',
        items: [],
        subtotal: Number(orderRow.subtotal || orderRow.subtotal_kz || 0),
        shippingFee: Number(orderRow.shipping_fee || orderRow.shipping_fee_kz || 0),
        total: Number(orderRow.total || orderRow.total_kz || 0),
        paymentMethod: orderRow.payment_method || 'No acto da entrega',
        paymentStatus: data.paymentStatus || orderRow.payment_status || 'No acto da entrega',
        status: data.status || 'Pendente',
        statusHistory: [],
        ...updatePayload,
      },
    };
  },

  /**
   * Deletes an order from Supabase:
   * - Enforces admin permission check (domingosquissanga862@gmail.com)
   * - Removes related order_items first to preserve foreign key constraints
   * - Deletes from orders table
   * - Guarantees products, customers, and unrelated expenses are untouched
   */
  async deleteOrder(idOrNumber: string, actorEmail?: string): Promise<{ success: boolean; message: string }> {
    // 1. Strict admin verification
    let authorized = false;
    const cleanActor = (actorEmail || '').toLowerCase().trim();
    if (cleanActor === ADMIN_EMAIL) {
      authorized = true;
    } else {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user?.email && user.email.toLowerCase().trim() === ADMIN_EMAIL) {
          authorized = true;
        }
      } catch {
        // Continue to check stored token session
      }

      if (!authorized) {
        try {
          const rawToken = localStorage.getItem('carcuba_auth_token');
          if (rawToken) {
            const parts = rawToken.split('.');
            if (parts.length >= 2) {
              const decoded = JSON.parse(atob(parts[0].replace(/-/g, '+').replace(/_/g, '/')));
              if (
                decoded.role === 'admin' ||
                (decoded.email && decoded.email.toLowerCase().trim() === ADMIN_EMAIL)
              ) {
                authorized = true;
              }
            }
          }
        } catch {
          // ignore
        }
      }
    }

    if (!authorized) {
      throw new Error('Acesso não autorizado. Apenas o administrador oficial da CarcubaExpress pode eliminar pedidos.');
    }

    const cleanInput = String(idOrNumber).trim();
    const cleanId = cleanInput.replace(/^ord-supa-/, '').trim();
    const isNum = /^\d+$/.test(cleanId);

    // 2. Identify the target order record
    let foundId: number | null = isNum ? parseInt(cleanId, 10) : null;
    let foundOrderNumber: string = cleanInput;

    try {
      let findQuery = supabase.from('orders').select('id, order_number');
      if (isNum) {
        findQuery = findQuery.or(`id.eq.${cleanId},order_number.eq.${cleanInput}`);
      } else {
        findQuery = findQuery.eq('order_number', cleanInput);
      }
      const { data: found } = await findQuery.maybeSingle();
      if (found) {
        foundId = found.id;
        foundOrderNumber = found.order_number || cleanInput;
      }
    } catch (e: any) {
      console.warn('[supabaseData.deleteOrder] Find warning:', e.message);
    }

    // 3. Delete order_items first
    if (foundId !== null) {
      const { error: itemsErr } = await supabase.from('order_items').delete().eq('order_id', foundId);
      if (itemsErr) {
        console.warn('[supabaseData.deleteOrder] Items delete warning:', itemsErr.message);
      }
    }

    // 4. Delete the order
    let deleteQuery = supabase.from('orders').delete();
    if (foundId !== null) {
      deleteQuery = deleteQuery.or(`id.eq.${foundId},order_number.eq.${foundOrderNumber}`);
    } else {
      deleteQuery = deleteQuery.eq('order_number', cleanInput);
    }

    const { error: orderErr } = await deleteQuery;
    if (orderErr) {
      throw new Error(`Erro ao eliminar pedido na base de dados Supabase: ${orderErr.message}`);
    }

    return {
      success: true,
      message: `Pedido ${foundOrderNumber} eliminado com sucesso na base de dados Supabase!`,
    };
  },

  // ==================== CONFIGURAÇÕES DA LOJA ====================
  async getSettings(): Promise<{ settings: StoreSettings }> {
    if (cachedSettings && Date.now() - lastSettingsFetchTime < SETTINGS_CACHE_TTL) {
      return { settings: cachedSettings };
    }
    try {
      const { data, error } = await supabase
        .from('store_settings')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (error || !data) {
        cachedSettings = fallbackSettings;
        lastSettingsFetchTime = Date.now();
        return { settings: fallbackSettings };
      }

      const resolved: StoreSettings = {
        ...fallbackSettings,
        storeName: data.store_name || fallbackSettings.storeName,
        whatsappNumber: data.whatsapp_number || fallbackSettings.whatsappNumber,
        supportPhone: data.support_phone || fallbackSettings.supportPhone,
        email: data.email || fallbackSettings.email,
        city: data.city || fallbackSettings.city,
        country: data.country || fallbackSettings.country,
        address: data.address || fallbackSettings.address,
        defaultShippingFee: Number(data.default_shipping_fee || fallbackSettings.defaultShippingFee),
        freeShippingMinAmount: Number(data.free_shipping_min_amount || fallbackSettings.freeShippingMinAmount),
      };

      cachedSettings = resolved;
      lastSettingsFetchTime = Date.now();
      return { settings: resolved };
    } catch {
      return { settings: cachedSettings || fallbackSettings };
    }
  },

  async updateSettings(data: Partial<StoreSettings>) {
    cachedSettings = null;
    lastSettingsFetchTime = 0;
    const updatePayload: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };
    if (data.storeName) updatePayload.store_name = data.storeName;
    if (data.whatsappNumber) updatePayload.whatsapp_number = data.whatsappNumber;
    if (data.supportPhone) updatePayload.support_phone = data.supportPhone;
    if (data.email) updatePayload.email = data.email;
    if (data.address) updatePayload.address = data.address;
    if (data.city) updatePayload.city = data.city;
    if (data.country) updatePayload.country = data.country;
    if (data.defaultShippingFee !== undefined) updatePayload.default_shipping_fee = Number(data.defaultShippingFee);
    if (data.freeShippingMinAmount !== undefined) updatePayload.free_shipping_min_amount = Number(data.freeShippingMinAmount);

    const { error } = await supabase
      .from('store_settings')
      .update(updatePayload)
      .eq('id', 'default');

    if (error) {
      throw new Error(`Erro ao atualizar configurações no Supabase: ${error.message}`);
    }

    return {
      message: 'Configurações atualizadas com sucesso no Supabase!',
    };
  },

  // ==================== DESPESAS ====================
  async getExpenses(): Promise<{ expenses: Expense[] }> {
    let supabaseExpenses: Expense[] = [];
    try {
      const { data, error } = await supabase
        .from('expenses')
        .select('*')
        .order('date', { ascending: false });

      if (!error && Array.isArray(data)) {
        supabaseExpenses = data.map((row: any) => ({
          id: String(row.id),
          title: row.title,
          category: row.category,
          amount: Number(row.amount || 0),
          date: row.date || (row.created_at ? row.created_at.slice(0, 10) : new Date().toISOString().slice(0, 10)),
          note: row.note || '',
          createdById: 'admin',
          createdByName: row.created_by_name || 'Domingos Quissanga',
          createdAt: row.created_at || new Date().toISOString(),
        }));
      }
    } catch {
      // fallback
    }

    // Merge with local storage cache for instant offline and resilient execution
    let localExpenses: Expense[] = [];
    try {
      const raw = localStorage.getItem('carcuba_expenses_cache');
      if (raw) {
        localExpenses = JSON.parse(raw);
      }
    } catch {
      // ignore
    }

    const mergedMap = new Map<string, Expense>();
    for (const le of localExpenses) {
      mergedMap.set(String(le.id), le);
    }
    for (const se of supabaseExpenses) {
      mergedMap.set(String(se.id), se);
    }

    const allExpenses = Array.from(mergedMap.values()).sort(
      (a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime()
    );

    return { expenses: allExpenses };
  },

  async createExpense(data: { title: string; category: string; amount: number; date?: string; note?: string }) {
    const expenseDate = data.date || new Date().toISOString().slice(0, 10);
    const numAmount = Number(data.amount);
    let insertedExpense: any = null;

    try {
      const { data: inserted, error } = await supabase
        .from('expenses')
        .insert({
          title: data.title.trim(),
          category: data.category,
          amount: numAmount,
          date: expenseDate,
          note: data.note?.trim() || null,
          created_by_name: 'Domingos Quissanga',
        })
        .select('*')
        .maybeSingle();

      if (!error && inserted) {
        insertedExpense = {
          id: String(inserted.id),
          title: inserted.title,
          category: inserted.category,
          amount: Number(inserted.amount),
          date: inserted.date || expenseDate,
          note: inserted.note || '',
          createdById: 'admin',
          createdByName: inserted.created_by_name || 'Domingos Quissanga',
          createdAt: inserted.created_at || new Date().toISOString(),
        };
      }
    } catch (err) {
      console.warn('[supabaseData.createExpense] Supabase direct insert notice:', err);
    }

    if (!insertedExpense) {
      insertedExpense = {
        id: `exp-${Date.now()}`,
        title: data.title.trim(),
        category: data.category,
        amount: numAmount,
        date: expenseDate,
        note: data.note?.trim() || '',
        createdById: 'admin',
        createdByName: 'Domingos Quissanga',
        createdAt: new Date().toISOString(),
      };
    }

    // Persist in local storage cache
    try {
      const raw = localStorage.getItem('carcuba_expenses_cache');
      const list: Expense[] = raw ? JSON.parse(raw) : [];
      list.unshift(insertedExpense);
      localStorage.setItem('carcuba_expenses_cache', JSON.stringify(list));
    } catch {}

    return { message: 'Despesa registada com sucesso!', expense: insertedExpense };
  },

  async updateExpense(
    id: string,
    data: { title?: string; category?: string; amount?: number; date?: string; note?: string }
  ) {
    const numericId = parseInt(id.replace(/\D/g, ''), 10);
    const updatePayload: Record<string, any> = {};
    if (data.title) updatePayload.title = data.title.trim();
    if (data.category) updatePayload.category = data.category;
    if (data.amount !== undefined) updatePayload.amount = Number(data.amount);
    if (data.date) updatePayload.date = data.date;
    if (data.note !== undefined) updatePayload.note = data.note ? data.note.trim() : null;

    if (!isNaN(numericId) && numericId > 0) {
      try {
        await supabase.from('expenses').update(updatePayload).eq('id', numericId);
      } catch (err) {
        console.warn('[supabaseData.updateExpense] Supabase notice:', err);
      }
    }

    // Update in local cache
    try {
      const raw = localStorage.getItem('carcuba_expenses_cache');
      if (raw) {
        const list: Expense[] = JSON.parse(raw);
        const idx = list.findIndex(e => String(e.id) === String(id));
        if (idx !== -1) {
          list[idx] = {
            ...list[idx],
            ...data,
            category: (data.category || list[idx].category) as Expense['category'],
            ...(data.amount ? { amount: Number(data.amount) } : {}),
          };
          localStorage.setItem('carcuba_expenses_cache', JSON.stringify(list));
        }
      }
    } catch {}

    return { message: 'Despesa atualizada com sucesso!' };
  },

  async deleteExpense(id: string) {
    const numericId = parseInt(id.replace(/\D/g, ''), 10);
    if (!isNaN(numericId) && numericId > 0) {
      try {
        await supabase.from('expenses').delete().eq('id', numericId);
      } catch (err) {
        console.warn('[supabaseData.deleteExpense] Supabase notice:', err);
      }
    }

    // Remove from local cache
    try {
      const raw = localStorage.getItem('carcuba_expenses_cache');
      if (raw) {
        const list: Expense[] = JSON.parse(raw);
        const filtered = list.filter(e => String(e.id) !== String(id));
        localStorage.setItem('carcuba_expenses_cache', JSON.stringify(filtered));
      }
    } catch {}

    return { message: 'Despesa eliminada com sucesso!' };
  },

  // ==================== RESUMO FINANCEIRO ====================
  async getFinancialSummary(params?: { period?: string; date?: string }): Promise<FinancialSummary> {
    const { orders } = await this.getOrders();
    const { expenses } = await this.getExpenses();
    const { products } = await this.getProducts({ activeOnly: false });

    let totalRevenue = 0;
    let confirmedPaidRevenue = 0;
    let deliveredRevenue = 0;
    let cogsTotal = 0;

    for (const order of orders) {
      if (order.status !== 'Cancelado') {
        totalRevenue += order.total;
        if (order.paymentStatus === 'Confirmado') {
          confirmedPaidRevenue += order.total;
        }
        if (order.status === 'Entregue') {
          deliveredRevenue += order.total;
        }
        for (const it of order.items) {
          cogsTotal += (it.costPrice || Math.round(it.price * 0.6)) * it.quantity;
        }
      }
    }

    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const estimatedNetProfit = totalRevenue - cogsTotal - totalExpenses;
    const confirmedNetProfit = confirmedPaidRevenue - cogsTotal - totalExpenses;
    const activeOrders = orders.filter(o => o.status !== 'Cancelado');
    const averageOrderValue = activeOrders.length > 0 ? Math.round(totalRevenue / activeOrders.length) : 0;

    // Build dynamic last 7 days metrics for sales chart
    const dayNames = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    const last7Days: { date: string; label: string; sales: number; count: number }[] = [];
    const today = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const dayOfWeek = dayNames[d.getDay()];
      const dayLabel = `${dayOfWeek} ${d.getDate()}`;

      const dayOrders = orders.filter(o => {
        if (o.status === 'Cancelado') return false;
        const ordDate = (o.createdAt || '').slice(0, 10);
        return ordDate === dateStr;
      });

      const daySales = dayOrders.reduce((sum, o) => sum + (o.total || 0), 0);

      last7Days.push({
        date: dateStr,
        label: dayLabel,
        sales: daySales,
        count: dayOrders.length,
      });
    }

    // Category sales distribution
    const catMap = new Map<string, { totalSales: number; unitsSold: number }>();
    for (const order of orders) {
      if (order.status === 'Cancelado') continue;
      for (const item of order.items) {
        const prod = products.find(p => p.id === item.productId || p.name === item.productName);
        const catName = prod?.categoryName || 'Geral';
        const current = catMap.get(catName) || { totalSales: 0, unitsSold: 0 };
        current.totalSales += (item.price || 0) * (item.quantity || 1);
        current.unitsSold += item.quantity || 1;
        catMap.set(catName, current);
      }
    }

    const categorySales = Array.from(catMap.entries()).map(([name, val]) => ({
      name,
      totalSales: val.totalSales,
      unitsSold: val.unitsSold,
    }));

    return {
      period: params?.period || '30d',
      selectedDate: params?.date || null,
      currency: 'Kz',
      totalRevenue,
      confirmedPaidRevenue,
      deliveredRevenue,
      cogsTotal,
      totalExpenses,
      estimatedNetProfit,
      confirmedNetProfit,
      averageOrderValue,
      statusCounts: {
        total: orders.length,
        pendentes: orders.filter(o => o.status === 'Pendente').length,
        aguardandoPagamento: orders.filter(o => o.status === 'A aguardar pagamento').length,
        emPreparacao: orders.filter(o => o.status === 'Em preparação').length,
        emTransporte: orders.filter(o => o.status === 'Em transporte').length,
        entregues: orders.filter(o => o.status === 'Entregue').length,
        cancelados: orders.filter(o => o.status === 'Cancelado').length,
      },
      productStats: {
        total: products.length,
        available: products.filter(p => p.isActive && p.stock > 0).length,
        lowStockCount: products.filter(p => p.stock > 0 && p.stock <= 3).length,
        outOfStockCount: products.filter(p => p.stock <= 0).length,
        lowStockList: products.filter(p => p.stock <= 3),
        allProductsList: products,
      },
      last7Days,
      categorySales,
      formulaDescription: 'Receita Total = Soma das vendas; Lucro = Receita - CPV - Despesas Operacionais.',
    };
  },

  // ==================== CLIENTES ====================
  async getCustomers(): Promise<{ customers: CustomerData[] }> {
    const { orders } = await this.getOrders();
    const map = new Map<string, CustomerData>();

    for (const ord of orders) {
      const key = ord.customerPhone || ord.customerName;
      const existing = map.get(key);
      if (existing) {
        existing.ordersCount += 1;
        existing.totalSpent += ord.total;
        if (new Date(ord.createdAt) > new Date(existing.lastOrderDate || '2000-01-01')) {
          existing.lastOrderDate = ord.createdAt;
        }
      } else {
        map.set(key, {
          id: `cust-${key.replace(/\D/g, '') || Date.now()}`,
          name: ord.customerName,
          email: ord.customerEmail || '',
          phone: ord.customerPhone,
          createdAt: ord.createdAt,
          ordersCount: 1,
          totalSpent: ord.total,
          lastOrderDate: ord.createdAt,
        });
      }
    }

    return { customers: Array.from(map.values()) };
  },
};
