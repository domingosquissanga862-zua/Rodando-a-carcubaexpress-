import { supabase } from './supabase';
import { supabaseRecovery } from './supabaseClient';
import { api, setAuthToken, removeAuthToken, getAuthToken } from './api';
import type { User } from '../types';

export const ADMIN_EMAILS = [
  'domingosquissanga862@gmail.com',
];

/**
 * Normalizes email by trimming whitespace and converting to lowercase
 */
export function normalizeEmail(email: string): string {
  return (email || '').toLowerCase().trim();
}

/**
 * Maps Supabase Auth errors to user-friendly messages in Portuguese
 */
function mapAuthError(err: any): string {
  if (!err) return 'Ocorreu um erro inesperado. Tente novamente.';
  const msg = (err.message || '').toLowerCase();

  if (msg.includes('unable to exchange external code')) {
    return 'A validação do código de acesso da Google expirou ou falhou. Por favor, tente novamente clicando em «Continuar com o Google».';
  }
  if (
    msg.includes('both auth code and code_verifier') ||
    msg.includes('code_verifier') ||
    msg.includes('code verifier')
  ) {
    return 'Esta ligação foi aberta num navegador ou dispositivo diferente daquele onde o pedido foi feito, ou já expirou. Volte a pedir o acesso (login com Google ou recuperação de palavra-passe) e abra a ligação no mesmo navegador.';
  }
  if (msg.includes('auth session missing') || msg.includes('session missing')) {
    return 'A sessão de recuperação não foi validada ou expirou. Peça uma nova ligação de recuperação de palavra-passe e abra-a diretamente a partir do email.';
  }
  if (msg.includes('invalid login credentials') || msg.includes('invalid_grant')) {
    return 'Credenciais de acesso inválidas. Se usou a Google, tente clicar novamente no botão de login.';
  }
  if (msg.includes('email not confirmed')) {
    return 'A sua conta ainda não foi confirmada por email. Por favor, verifique a sua caixa de correio.';
  }
  if (msg.includes('user already registered') || msg.includes('already exists')) {
    return 'Já existe uma conta associada a este endereço de email. Inicie sessão com a sua palavra-passe.';
  }
  if (msg.includes('password should be at least')) {
    return 'A palavra-passe deve ter pelo menos 6 caracteres.';
  }
  if (msg.includes('rate limit') || msg.includes('too many requests')) {
    return 'Demasiadas tentativas de início de sessão. Por favor, aguarde alguns minutos e tente novamente.';
  }
  if (msg.includes('network') || msg.includes('fetch') || msg.includes('failed to fetch')) {
    return 'Falha de comunicação com o servidor Supabase. Verifique a sua ligação à Internet.';
  }

  return err.message || 'Erro de autenticação. Verifique os dados introduzidos.';
}

/**
 * Result of Supabase sign up operation
 */
export interface SignUpResult {
  user: User | null;
  requiresEmailConfirmation: boolean;
  message: string;
}

/**
 * Directly signs up a customer in Supabase Auth and inserts their profile into public.profiles & public.users
 * Strictly follows Supabase Auth requirements without simulated credentials or fake fallbacks.
 */
export async function supabaseSignUp(data: {
  name: string;
  email: string;
  phone: string;
  password: string;
}): Promise<SignUpResult> {
  const cleanEmail = normalizeEmail(data.email);
  const cleanName = data.name.trim();
  const cleanPhone = data.phone.trim();

  if (!cleanEmail || !cleanName || !data.password) {
    throw new Error('Todos os campos são obrigatórios (Nome, Email, Telefone, Palavra-passe).');
  }

  if (data.password.length < 8) {
    throw new Error('A palavra-passe deve ter pelo menos 8 caracteres.');
  }

  const hasUpper = /[A-Z]/.test(data.password);
  const hasLower = /[a-z]/.test(data.password);
  const hasNumber = /[0-9]/.test(data.password);
  const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~` ]/.test(data.password);

  if (!hasUpper || !hasLower || !hasNumber || !hasSpecial) {
    throw new Error('A palavra-passe deve ser forte: inclua pelo menos uma letra maiúscula, uma minúscula, um número e um carácter especial (ex: @, #, $, !).');
  }

  // 1. Exclusively create account in Supabase Auth via supabase.auth.signUp()
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email: cleanEmail,
    password: data.password,
    options: {
      data: {
        name: cleanName,
        phone: cleanPhone,
        role: 'customer',
      },
    },
  });

  if (authError) {
    throw new Error(mapAuthError(authError));
  }

  const authUser = authData?.user;
  if (!authUser) {
    throw new Error('Não foi possível registar o utilizador no Supabase Authentication. Tente novamente.');
  }

  // Check if the user is already registered in Supabase
  // When an email is already registered, Supabase returns a user object with empty identities array
  if (authUser.identities && authUser.identities.length === 0) {
    throw new Error('Já existe uma conta associada a este endereço de email no Supabase. Por favor, inicie sessão com a sua palavra-passe.');
  }

  // 2. Persist profile in public.profiles AND public.users in Supabase (never store passwords in public tables)
  try {
    await supabase.from('profiles').upsert({
      id: authUser.id,
      name: cleanName,
      email: cleanEmail,
      phone: cleanPhone,
      role: 'customer',
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  } catch (err: any) {
    console.warn('[Supabase profiles upsert]:', err?.message || err);
  }

  try {
    await supabase.from('users').upsert({
      id: authUser.id,
      name: cleanName,
      email: cleanEmail,
      phone: cleanPhone,
      role: 'customer',
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  } catch (err: any) {
    console.warn('[Supabase users upsert]:', err?.message || err);
  }

  // 3. Check if email confirmation is required by Supabase project settings
  // If session is null, email confirmation is active and must be completed before access
  const requiresEmailConfirmation = !authData.session;

  if (requiresEmailConfirmation) {
    return {
      user: null,
      requiresEmailConfirmation: true,
      message: 'Conta criada com sucesso no Supabase! Foi enviado um email de confirmação para o seu endereço. Por favor, confirme o seu email antes de iniciar sessão.',
    };
  }

  // 4. If session is immediately available (email confirmation disabled in Supabase)
  if (authData.session?.access_token) {
    setAuthToken(authData.session.access_token);
  }

  const createdUser: User = {
    id: authUser.id,
    name: cleanName,
    email: cleanEmail,
    phone: cleanPhone,
    role: 'customer',
    createdAt: authUser.created_at || new Date().toISOString(),
  };

  return {
    user: createdUser,
    requiresEmailConfirmation: false,
    message: 'Conta criada e autenticada com sucesso no Supabase!',
  };
}

/**
 * Signs in a user using exclusively Supabase Auth (supabase.auth.signInWithPassword)
 * Strictly enforces that no mock or simulated session can grant access.
 */
export async function supabaseSignIn(
  email: string,
  pass: string,
  isAdminTab: boolean = false
): Promise<User> {
  const cleanEmail = normalizeEmail(email);

  if (!cleanEmail || !pass) {
    throw new Error('Por favor, introduza o seu email e palavra-passe.');
  }

  // Strictly block any email other than domingosquissanga862@gmail.com from logging into the Admin tab
  if (isAdminTab && cleanEmail !== 'domingosquissanga862@gmail.com') {
    throw new Error('Acesso restrito. Apenas o administrador oficial domingosquissanga862@gmail.com tem autorização para aceder ao Painel de Administração.');
  }

  // 1. Attempt Supabase Auth signInWithPassword
  const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
    email: cleanEmail,
    password: pass,
  });

  if (authError) {
    const errorMsg = (authError.message || '').toLowerCase();

    // Specific check: Email not confirmed
    if (errorMsg.includes('email not confirmed')) {
      throw new Error('A sua conta requer confirmação de email antes de iniciar sessão. Por favor, verifique a sua caixa de entrada e clique no link enviado.');
    }

    // Specific check: Invalid credentials -> distinguish between unregistered email and wrong password
    if (errorMsg.includes('invalid login credentials') || errorMsg.includes('invalid_grant')) {
      let isRegistered = false;

      try {
        const { data: profileCheck } = await supabase
          .from('profiles')
          .select('id, email')
          .eq('email', cleanEmail)
          .maybeSingle();

        if (profileCheck?.id) {
          isRegistered = true;
        } else {
          const { data: userCheck } = await supabase
            .from('users')
            .select('id, email')
            .eq('email', cleanEmail)
            .maybeSingle();

          if (userCheck?.id) {
            isRegistered = true;
          }
        }
      } catch {
        // Continue with standard error message if query is blocked
      }

      if (!isRegistered) {
        throw new Error('Este endereço de email não está registado. Por favor, crie uma conta primeiro para poder aceder.');
      } else {
        throw new Error('Palavra-passe incorrecta. Por favor, verifique a sua palavra-passe ou utilize a opção de recuperação.');
      }
    }

    throw new Error(mapAuthError(authError));
  }

  // 2. Validate that Supabase session and user were actually established
  if (!authData?.session || !authData?.user) {
    throw new Error('A autenticação não retornou uma sessão válida do Supabase. Verifique os seus dados de acesso.');
  }

  const userObj = authData.user;
  const isStoreAdmin = cleanEmail === 'domingosquissanga862@gmail.com';
  let name = isStoreAdmin ? 'Domingos Quissanga' : (userObj.user_metadata?.name || cleanEmail.split('@')[0]);
  let phone = userObj.user_metadata?.phone || '';
  let role: 'admin' | 'customer' = isStoreAdmin ? 'admin' : 'customer';

  // 3. Fetch user profile from public.profiles or public.users
  try {
    const { data: profileRow } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userObj.id)
      .maybeSingle();

    if (profileRow) {
      name = isStoreAdmin ? 'Domingos Quissanga' : (profileRow.name || name);
      phone = profileRow.phone || phone;
    } else {
      const { data: userRow } = await supabase
        .from('users')
        .select('*')
        .eq('email', cleanEmail)
        .maybeSingle();

      if (userRow) {
        name = isStoreAdmin ? 'Domingos Quissanga' : (userRow.name || name);
        phone = userRow.phone || phone;
      }
    }
  } catch {
    // Continue with metadata
  }

  if (authData.session?.access_token) {
    setAuthToken(authData.session.access_token);
  }

  const authenticatedUser: User = {
    id: userObj.id,
    name,
    email: cleanEmail,
    phone,
    role,
    createdAt: userObj.created_at || new Date().toISOString(),
  };

  return authenticatedUser;
}

/**
 * Fetches the currently authenticated user exclusively from active Supabase session (supabase.auth.getSession)
 * Never accepts simulated tokens or arbitrary offline profiles.
 */
export async function supabaseGetCurrentUser(): Promise<User | null> {
  try {
    const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
    if (sessionErr || !sessionData?.session?.user) {
      removeAuthToken();
      return null;
    }

    const supaAuthUser = sessionData.session.user;
    if (!supaAuthUser.email) return null;

    const cleanEmail = normalizeEmail(supaAuthUser.email);
    const isStoreAdmin = cleanEmail === 'domingosquissanga862@gmail.com';
    let name = isStoreAdmin ? 'Domingos Quissanga' : (supaAuthUser.user_metadata?.name || cleanEmail.split('@')[0]);
    let phone = supaAuthUser.user_metadata?.phone || '';
    let role: 'admin' | 'customer' = isStoreAdmin ? 'admin' : 'customer';

    try {
      const { data: profileRow } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', supaAuthUser.id)
        .maybeSingle();

      if (profileRow) {
        name = isStoreAdmin ? 'Domingos Quissanga' : (profileRow.name || name);
        phone = profileRow.phone || phone;
      } else {
        const { data: userRow } = await supabase
          .from('users')
          .select('*')
          .eq('email', cleanEmail)
          .maybeSingle();

        if (userRow) {
          name = isStoreAdmin ? 'Domingos Quissanga' : (userRow.name || name);
          phone = userRow.phone || phone;
        }
      }
    } catch {
      // Continue
    }

    return {
      id: supaAuthUser.id,
      name,
      email: cleanEmail,
      phone,
      role,
      createdAt: supaAuthUser.created_at || new Date().toISOString(),
    };
  } catch {
    return null;
  }
}

/**
 * Signs out from Supabase and clears all local storage
 */
export async function supabaseSignOut(): Promise<void> {
  try {
    await supabase.auth.signOut();
  } catch {
    // Continue
  }

  try {
    await api.logout();
  } catch {
    // Continue
  } finally {
    removeAuthToken();
  }
}

/**
 * Checks whether an OAuth provider (Google or Apple) is enabled in Supabase
 */
export async function checkOAuthProviderEnabled(provider: 'google' | 'apple'): Promise<{
  enabled: boolean;
  message?: string;
  hint?: string;
}> {
  try {
    const res = await fetch(`/api/auth/provider-status?provider=${provider}`);
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // If check fails, default to enabled and let Supabase respond
  }
  return { enabled: true };
}

/**
 * Synchronizes the user from Supabase Auth into public.users table.
 * Resolves conflicts safely: updates existing record or inserts a new one.
 */
export async function syncUserProfile(authUser: any): Promise<User> {
  const cleanEmail = normalizeEmail(authUser.email || '');
  const isStoreAdmin = cleanEmail === 'domingosquissanga862@gmail.com';

  const metadata = authUser.user_metadata || {};
  let name = isStoreAdmin
    ? 'Domingos Quissanga'
    : (metadata.full_name || metadata.name || metadata.user_name || cleanEmail.split('@')[0] || 'Cliente CarcubaExpress');
  if (name === 'Administrador CarcubaExpress' && !isStoreAdmin) {
    name = 'Cliente CarcubaExpress';
  }
  let phone = metadata.phone || '';
  const role: 'admin' | 'customer' = isStoreAdmin ? 'admin' : 'customer';

  // 1. Sync profile to public.profiles
  try {
    await supabase.from('profiles').upsert({
      id: authUser.id,
      name,
      email: cleanEmail,
      phone,
      role: isStoreAdmin ? 'admin' : 'customer',
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  } catch (err: any) {
    console.warn('[syncUserProfile] Warning syncing to public.profiles:', err?.message || err);
  }

  // 2. Sync profile to public.users
  try {
    const { data: existingUser } = await supabase
      .from('users')
      .select('*')
      .or(`email.eq.${cleanEmail},id.eq.${authUser.id}`)
      .maybeSingle();

    if (existingUser) {
      name = isStoreAdmin ? 'Domingos Quissanga' : (existingUser.name || name);
      phone = existingUser.phone || phone;

      await supabase
        .from('users')
        .update({
          name,
          phone,
          role: isStoreAdmin ? 'admin' : 'customer',
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingUser.id);
    } else {
      await supabase.from('users').insert({
        id: authUser.id,
        name,
        email: cleanEmail,
        phone,
        role,
        created_at: authUser.created_at || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    }
  } catch (err: any) {
    console.warn('[syncUserProfile] Warning syncing profile to public.users:', err?.message || err);
  }

  return {
    id: authUser.id,
    name,
    email: cleanEmail,
    phone,
    role,
    createdAt: authUser.created_at || new Date().toISOString(),
  };
}

// Atomic in-flight lock to guarantee that code exchange is never executed concurrently
let oauthExchangeInProgress: Promise<{ user: User | null; error: string | null }> | null = null;

/**
 * Handles incoming OAuth callback from URL (PKCE code exchange, hash token handling, error parsing, session persistence)
 */
export async function handleOAuthCallback(): Promise<{ user: User | null; error: string | null }> {
  if (typeof window === 'undefined') return { user: null, error: null };

  // If another execution is already active, wait for and return its result
  if (oauthExchangeInProgress) {
    return oauthExchangeInProgress;
  }

  oauthExchangeInProgress = (async () => {
    try {
      const currentUrl = new URL(window.location.href);
      const code = currentUrl.searchParams.get('code');
      const hashStr = window.location.hash.replace(/^#/, '');
      const hashParams = new URLSearchParams(hashStr);

      const errorParam =
        currentUrl.searchParams.get('error_description') ||
        currentUrl.searchParams.get('error') ||
        hashParams.get('error_description') ||
        hashParams.get('error');

      // 1. Diagnostic log on callback entry (safe: no tokens, secrets or raw codes logged)
      console.info('[OAuth Diagnóstico 1/4 - Callback Recebido]', {
        origem: window.location.origin,
        caminho: window.location.pathname,
        temParametroCode: Boolean(code),
        tamanhoAproxCode: code ? code.length : 0,
        tipoPrefixoCode: code ? (code.startsWith('4/') ? 'Código Externo Google (Inesperado no cliente)' : 'Código Supabase PKCE (Esperado)') : 'Nenhum',
        temParametroErro: Boolean(errorParam),
        tipoErro: currentUrl.searchParams.get('error') || hashParams.get('error') || null,
        temTokensNoHash: Boolean(hashParams.get('access_token')),
        armazenamentoLocalDisponivel: typeof window.localStorage !== 'undefined',
        timestamp: new Date().toISOString(),
      });

      // If OAuth error returned in URL from Google or Supabase
      if (errorParam) {
        console.warn('[OAuth Diagnóstico - Erro do Fornecedor]', {
          erroParam: errorParam.substring(0, 80),
          origemErro: 'Servidor Supabase GoTrue / Google OAuth',
          causaProvavel: 'Supabase falhou ao trocar o código de autorização com a Google em https://oauth2.googleapis.com/token',
        });

        currentUrl.searchParams.delete('error');
        currentUrl.searchParams.delete('error_description');
        currentUrl.searchParams.delete('error_code');
        currentUrl.searchParams.delete('code');
        currentUrl.searchParams.delete('state');
        window.history.replaceState({}, document.title, currentUrl.pathname);

        const decoded = decodeURIComponent(errorParam.replace(/\+/g, ' '));
        if (decoded.includes('Unable to exchange external code') || decoded.includes('4/0A')) {
          return {
            user: null,
            error: 'A validação do login com a Google falhou na comunicação entre o Supabase e o Google (Unable to exchange external code). Verifique se o Client Secret no painel do Supabase coincide rigorosamente com o Google Cloud.',
          };
        }
        if (decoded.includes('access_denied')) {
          return {
            user: null,
            error: 'Início de sessão com o Google cancelado pelo utilizador.',
          };
        }
        return {
          user: null,
          error: `Erro ao autenticar com o Google: ${decoded}`,
        };
      }

      // 2. Check if session was already established automatically
      try {
        const { data: initialSession } = await supabase.auth.getSession();
        // Tokens no hash (ligação de recuperação) têm prioridade sobre uma sessão antiga,
        // para que a nova palavra-passe seja sempre aplicada à conta do email recebido.
        if (initialSession?.session?.user && !hashParams.get('access_token')) {
          console.info('[OAuth Diagnóstico 2/4 - Sessão Pré-existente Encontrada]');
          if (code) {
            currentUrl.searchParams.delete('code');
            currentUrl.searchParams.delete('state');
            window.history.replaceState({}, document.title, currentUrl.pathname + currentUrl.search);
          }
          if (initialSession.session.access_token) {
            setAuthToken(initialSession.session.access_token);
          }
          const syncedUser = await syncUserProfile(initialSession.session.user);
          return { user: syncedUser, error: null };
        }
      } catch {
        // Continue with manual code exchange
      }

      // 3. If authorization code is present in URL (PKCE Flow), exchange it for session
      if (code) {
        // Immediately clean 'code' & 'state' from browser URL BEFORE initiating network exchange
        currentUrl.searchParams.delete('code');
        currentUrl.searchParams.delete('state');
        window.history.replaceState({}, document.title, currentUrl.pathname + currentUrl.search);

        console.info('[OAuth Diagnóstico 3/4 - A Executar exchangeCodeForSession]', {
          flow: 'pkce',
          pkceVerifierPresente: Boolean(window.localStorage.getItem('sb-jglvxsvhumrbypmgooic-auth-token-code-verifier')),
          timestamp: new Date().toISOString(),
        });

        try {
          const { data, error } = await supabase.auth.exchangeCodeForSession(code);

          if (!error && data?.session?.user) {
            console.info('[OAuth Diagnóstico 4/4 - Código Trocado com Sucesso]', {
              sessaoCriada: true,
              roleAtribuido: data.session.user.email?.toLowerCase().trim() === 'domingosquissanga862@gmail.com' ? 'admin' : 'customer',
            });

            if (data.session.access_token) {
              setAuthToken(data.session.access_token);
            }
            const syncedUser = await syncUserProfile(data.session.user);
            return { user: syncedUser, error: null };
          }

          // If exchange returned an error, check if background listener finished it in parallel
          const { data: retrySession } = await supabase.auth.getSession();
          if (retrySession?.session?.user) {
            console.info('[OAuth Diagnóstico - Sessão Confirmada em Retry]');
            if (retrySession.session.access_token) {
              setAuthToken(retrySession.session.access_token);
            }
            const syncedUser = await syncUserProfile(retrySession.session.user);
            return { user: syncedUser, error: null };
          }

          if (error) {
            console.error('[OAuth Diagnóstico - Falha na Troca de Código]:', error.message);
            return { user: null, error: mapAuthError(error) };
          }
        } catch (err: any) {
          console.error('[OAuth Diagnóstico - Excepção na Troca de Código]:', err);

          try {
            const { data: fallbackSession } = await supabase.auth.getSession();
            if (fallbackSession?.session?.user) {
              const syncedUser = await syncUserProfile(fallbackSession.session.user);
              return { user: syncedUser, error: null };
            }
          } catch {}

          return { user: null, error: mapAuthError(err) };
        }
      }

      // 4. If access_token is present in URL hash (Implicit Grant Flow)
      const accessToken = hashParams.get('access_token');
      const refreshToken = hashParams.get('refresh_token');
      if (accessToken) {
        window.history.replaceState({}, document.title, currentUrl.pathname);

        console.info('[OAuth Diagnóstico - Tokens Hash Detectados (Implicit Flow)]');
        try {
          const { data, error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken || '',
          });

          if (!error && data?.session?.user) {
            setAuthToken(data.session.access_token);
            const syncedUser = await syncUserProfile(data.session.user);
            return { user: syncedUser, error: null };
          }

          const { data: retrySession } = await supabase.auth.getSession();
          if (retrySession?.session?.user) {
            const syncedUser = await syncUserProfile(retrySession.session.user);
            return { user: syncedUser, error: null };
          }

          if (error) {
            return { user: null, error: mapAuthError(error) };
          }
        } catch (err: any) {
          return { user: null, error: mapAuthError(err) };
        }
      }

      // 5. Final Fallback: check if active session already exists in client
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        if (sessionData?.session?.user) {
          const syncedUser = await syncUserProfile(sessionData.session.user);
          return { user: syncedUser, error: null };
        }
      } catch {
        // Continue
      }

      return { user: null, error: null };
    } finally {
      oauthExchangeInProgress = null;
    }
  })();

  return oauthExchangeInProgress;
}

/**
 * Initiates OAuth login with Google or Apple via Supabase Auth
 * Note: Uses clean standard options without forcing offline access_type or custom query params,
 * which caused Google token exchange rejection ("Unable to exchange external code: 4/0A...").
 */
export async function supabaseSignInWithOAuth(provider: 'google' | 'apple'): Promise<{ provider: string; url?: string }> {
  try {
    const redirectTo = window.location.origin;

    console.info('[OAuth Início - Redirecionamento]', {
      provider,
      redirectTo,
      protocol: window.location.protocol,
      host: window.location.host,
      timestamp: new Date().toISOString(),
    });

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo,
        skipBrowserRedirect: false,
      },
    });

    if (error) {
      console.error('[OAuth Início - Erro Supabase Client]:', error.message);
      throw new Error(mapAuthError(error));
    }

    if (data?.url) {
      const isInIframe = window.self !== window.top;
      if (isInIframe) {
        try {
          window.top!.location.href = data.url;
        } catch {
          window.open(data.url, '_blank');
        }
      } else {
        window.location.href = data.url;
      }
      return { provider, url: data.url };
    }

    return { provider };
  } catch (err: any) {
    throw new Error(mapAuthError(err));
  }
}

/**
 * Sends a password reset email using Supabase Auth.
 * Adheres strictly to security best practices: never reveals if the email is registered.
 */
export async function supabaseResetPasswordForEmail(email: string): Promise<void> {
  const cleanEmail = normalizeEmail(email);
  if (!cleanEmail) {
    throw new Error('Por favor, introduza o seu endereço de email.');
  }

  // Redirect destination after clicking the email link
  const redirectUrl = `${window.location.origin}/?type=recovery`;

  try {
    // Fluxo "implicit" dedicado: a ligação do email funciona em qualquer navegador/dispositivo
    const { error } = await supabaseRecovery.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: redirectUrl,
    });

    if (error) {
      console.warn('[Supabase Reset Password Notice]:', error.message);
      if (
        error.message.toLowerCase().includes('rate limit') ||
        error.message.toLowerCase().includes('too many requests')
      ) {
        throw new Error('Demasiados pedidos de recuperação. Por favor, aguarde alguns minutos antes de tentar novamente.');
      }
    }
  } catch (err: any) {
    if (err.message && err.message.includes('Demasiados pedidos')) {
      throw err;
    }
    console.warn('[Supabase Auth recovery notice]:', err);
  }
}

/**
 * Updates the user's password once in a PASSWORD_RECOVERY session in Supabase Auth.
 */
export async function supabaseUpdatePassword(newPassword: string): Promise<void> {
  if (!newPassword || newPassword.length < 6) {
    throw new Error('A nova palavra-passe deve ter pelo menos 6 caracteres.');
  }

  const { data, error } = await supabase.auth.updateUser({
    password: newPassword,
  });

  if (error) {
    throw new Error(mapAuthError(error));
  }

  if (!data?.user) {
    throw new Error('Não foi possível atualizar a palavra-passe. A sua sessão de recuperação pode ter expirado.');
  }
}



