import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from './supabaseClient';

export { supabase, SUPABASE_URL, SUPABASE_ANON_KEY };

export interface SupabaseProductRecord {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  price_kz: number;
  image_url: string | null;
  stock: number;
  active: boolean;
  created_at: string;
}

export interface SupabaseOrderRecord {
  id: number;
  customer_name: string;
  phone: string;
  address: string;
  total_kz: number;
  status: string;
  notes: string | null;
  created_at: string;
}

/**
 * Direct client fetch from Supabase products table
 */
export async function fetchSupabaseProducts(): Promise<SupabaseProductRecord[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('id', { ascending: true });

  if (error) {
    console.warn('[Supabase Client] Falha ao consultar produtos:', error.message);
    throw error;
  }

  return (data as SupabaseProductRecord[]) || [];
}

/**
 * Direct client check to test Supabase connectivity
 */
export async function checkSupabaseConnection(): Promise<{ ok: boolean; count: number; error?: string }> {
  try {
    const { count, error } = await supabase
      .from('products')
      .select('*', { count: 'exact', head: true });

    if (error) {
      return { ok: false, count: 0, error: error.message };
    }
    return { ok: true, count: count ?? 0 };
  } catch (err: any) {
    return { ok: false, count: 0, error: err.message || 'Falha de rede com Supabase' };
  }
}
