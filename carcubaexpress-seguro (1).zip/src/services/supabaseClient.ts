import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const rawUrl =
  (import.meta as any).env?.VITE_SUPABASE_URL ||
  'https://jglvxsvhumrbypmgooic.supabase.co';

export const SUPABASE_URL = rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');

export const SUPABASE_ANON_KEY =
  (import.meta as any).env?.VITE_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpnbHZ4c3ZodW1yYnlwbWdvb2ljIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI0MTQ0MjYsImV4cCI6MjEwNzk5MDQyNn0.OsRyWri7JPz9d01IVnWQ-wq07JtgDAF4k0rGHq-o-wU';

/**
 * Unified singleton Supabase client for authentication, realtime events,
 * and database queries across both local development, Vercel, and Cloudflare Pages.
 */
export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false, // Prevents automatic background race conditions; handleOAuthCallback() manages the PKCE exchange atomically
    flowType: 'pkce',
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
});

/**
 * Cliente dedicado APENAS ao envio do email de recuperação de palavra-passe.
 * Usa o fluxo "implicit": a ligação enviada por email não depende de um
 * "code verifier" guardado no navegador, por isso funciona mesmo que o email
 * seja aberto noutro navegador/aplicação (ex.: Gmail no telemóvel).
 * Não persiste sessão nem partilha armazenamento com o cliente principal
 * (login normal e Google continuam em PKCE, sem alterações).
 */
export const supabaseRecovery: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
    detectSessionInUrl: false,
    flowType: 'implicit',
    storageKey: 'sb-carcuba-recovery-request',
  },
});
