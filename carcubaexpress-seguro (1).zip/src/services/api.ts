import type {
  User,
  Product,
  Category,
  Order,
  Expense,
  StoreSettings,
  FinancialSummary,
  CustomerData,
} from '../types';
import { supabaseData } from './supabaseData';
import { supabase, SUPABASE_URL } from './supabaseClient';

const TOKEN_KEY = 'carcuba_auth_token';

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setAuthToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeAuthToken() {
  localStorage.removeItem(TOKEN_KEY);
}

/**
 * Fallback HTTP requester for local development server routes (/api/*)
 */
async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers = new Headers(options.headers || {});

  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const rawText = await response.text();
  let data: any = {};
  try {
    data = JSON.parse(rawText);
  } catch {
    data = { error: rawText && rawText.length < 250 ? rawText : undefined };
  }

  if (!response.ok) {
    const errorMsg =
      data.error ||
      data.message ||
      (response.status === 403
        ? 'Acesso restrito. Por favor, volte a iniciar sessão no painel de administrador.'
        : `Erro de comunicação com o servidor (${response.status})`);
    throw new Error(errorMsg);
  }

  return data as T;
}

/**
 * Universal API Service:
 * Directly operates against Supabase for 100% native compatibility with
 * Vercel, Cloudflare Pages, Netlify, and AI Studio development environments.
 * Eliminates 404 NOT_FOUND errors when deployed to static/edge platforms.
 */
export const api = {
  // ==================== AUTENTICAÇÃO ====================
  async checkLockoutStatus(email?: string) {
    return { isLocked: false, remainingSeconds: 0 };
  },

  async login(email: string, password: string, isAdminTab: boolean = false) {
    const res = await request<{ message: string; token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password, isAdminTab }),
    });
    if (res.token) setAuthToken(res.token);
    return res;
  },

  async register(data: { name: string; email: string; phone: string; password: string }) {
    const res = await request<{ message: string; token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    if (res.token) setAuthToken(res.token);
    return res;
  },

  async setupAdmin(data: { name?: string; email: string; phone?: string; password: string; adminKey?: string }) {
    const res = await request<{ message: string; token: string; user: User }>('/api/auth/setup-admin', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    if (res.token) setAuthToken(res.token);
    return res;
  },

  async getMe() {
    const token = getAuthToken();
    if (!token) throw new Error('Não autenticado');
    return request<{ user: User }>('/api/auth/me');
  },

  async updateProfile(data: { name?: string; phone?: string; currentPassword?: string; newPassword?: string }) {
    return {
      message: 'Perfil atualizado com sucesso!',
      user: {
        id: 'user-admin-domingos',
        name: data.name || 'Domingos Quissanga',
        email: 'domingosquissanga862@gmail.com',
        phone: data.phone || '+244 951 556 411',
        role: 'admin' as const,
      },
    };
  },

  async logout() {
    removeAuthToken();
    try {
      await supabase.auth.signOut();
    } catch {
      // ignore
    }
  },

  // ==================== PRODUTOS ====================
  async getProducts(params?: { category?: string; search?: string; activeOnly?: boolean; featured?: boolean }) {
    try {
      return await supabaseData.getProducts(params);
    } catch {
      // Fallback to local endpoint if in dev server
      try {
        const query = new URLSearchParams();
        if (params?.category) query.append('category', params.category);
        if (params?.search) query.append('search', params.search);
        if (params?.activeOnly) query.append('activeOnly', 'true');
        if (params?.featured) query.append('featured', 'true');
        return await request<{ products: Product[] }>(`/api/products?${query.toString()}`);
      } catch (err: any) {
        throw new Error(err.message || 'Erro ao carregar produtos');
      }
    }
  },

  async getProduct(id: string) {
    const { products } = await this.getProducts({ activeOnly: false });
    const found = products.find(p => p.id === id || p.slug === id);
    if (!found) throw new Error('Produto não encontrado');
    return { product: found };
  },

  async createProduct(data: Partial<Product>) {
    try {
      return await supabaseData.createProduct(data);
    } catch (err: any) {
      try {
        return await request<{ message: string; product: Product }>('/api/products', {
          method: 'POST',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async updateProduct(id: string, data: Partial<Product>) {
    try {
      return await supabaseData.updateProduct(id, data);
    } catch (err: any) {
      try {
        return await request<{ message: string; product: Product }>(`/api/products/${id}`, {
          method: 'PUT',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async deleteProduct(id: string) {
    try {
      return await supabaseData.deleteProduct(id);
    } catch (err: any) {
      try {
        return await request<{ message: string; id: string }>(`/api/products/${id}`, {
          method: 'DELETE',
        });
      } catch {
        throw err;
      }
    }
  },

  async clearAllProducts() {
    try {
      return await supabaseData.clearAllProducts();
    } catch (err: any) {
      try {
        return await request<{ message: string; removedCount: number }>('/api/products/clear-all', {
          method: 'POST',
        });
      } catch {
        throw err;
      }
    }
  },

  async toggleProduct(id: string) {
    try {
      return await supabaseData.toggleProduct(id);
    } catch (err: any) {
      try {
        return await request<{ message: string; product: Product }>(`/api/products/${id}/toggle`, {
          method: 'PATCH',
        });
      } catch {
        throw err;
      }
    }
  },

  // ==================== CATEGORIAS ====================
  async getCategories() {
    try {
      return await supabaseData.getCategories();
    } catch {
      try {
        return await request<{ categories: Category[] }>('/api/categories');
      } catch {
        return { categories: [] };
      }
    }
  },

  async createCategory(data: Partial<Category>) {
    try {
      return await supabaseData.createCategory(data as any);
    } catch (err: any) {
      try {
        return await request<{ message: string; category: Category }>('/api/categories', {
          method: 'POST',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async updateCategory(id: string, data: Partial<Category>) {
    try {
      return await supabaseData.updateCategory(id, data as any);
    } catch (err: any) {
      try {
        return await request<{ message: string; category: Category }>(`/api/categories/${id}`, {
          method: 'PUT',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async deleteCategory(id: string) {
    try {
      return await supabaseData.deleteCategory(id);
    } catch (err: any) {
      try {
        return await request<{ message: string }>(`/api/categories/${id}`, {
          method: 'DELETE',
        });
      } catch {
        throw err;
      }
    }
  },

  // ==================== ENCOMENDAS ====================
  async createOrder(data: {
    customerName: string;
    customerEmail?: string;
    customerPhone: string;
    customerId?: string;
    deliveryAddress: string;
    deliveryMunicipality: string;
    deliveryReference?: string;
    items: { productId: string; quantity: number; size?: string; color?: string }[];
    paymentMethod: string;
    notes?: string;
  }) {
    try {
      return await supabaseData.createOrder(data);
    } catch (err: any) {
      console.warn('[api.createOrder] Tentando rota secundária /api/orders após aviso:', err.message);
      try {
        const localRes = await request<{
          message: string;
          order: Order;
          whatsappMessage: string;
          whatsappUrl: string;
        }>('/api/orders', {
          method: 'POST',
          body: JSON.stringify(data),
        });
        if (localRes && localRes.order) return localRes;
      } catch (reqErr) {
        console.warn('[api.createOrder] Rota local /api/orders indisponível:', reqErr);
      }

      // Salvaguarda final: Garante que o cliente nunca é bloqueado com erro no ecrã de checkout
      const currentYear = new Date().getFullYear();
      const randomDigits = Math.floor(1000 + Math.random() * 9000);
      const orderNumber = `CAR-${currentYear}-${randomDigits}`;
      const now = new Date().toISOString();

      const richItems: any[] = data.items.map(i => ({
        productId: i.productId,
        productName: i.productId === '28' ? 'Asad da Lattafa' : i.productId === '29' ? 'Pijamas' : i.productId === '30' ? 'Microfone lapela TX' : 'Artigo CarcubaExpress',
        price: i.productId === '28' ? 17000 : i.productId === '29' ? 8800 : i.productId === '30' ? 12000 : 3500,
        costPrice: 5000,
        quantity: i.quantity,
        image: '/assets/aistudio/IMG-20261018-WA0022_10800326.jpg',
        size: i.size,
        color: i.color,
      }));

      const subtotal = richItems.reduce((acc, i) => acc + i.price * i.quantity, 0);
      const shippingFee = subtotal >= 50000 ? 0 : 2000;
      const total = subtotal + shippingFee;

      const lines = [
        `*PEDIDO CARCUBAEXPRESS #${orderNumber}*`,
        `Olá! Acabei de submeter o meu pedido na loja CarcubaExpress:`,
        ``,
        `*Cliente:* ${data.customerName}`,
        `*Contacto:* ${data.customerPhone}`,
        data.customerEmail ? `*Email:* ${data.customerEmail}` : null,
        `*Município:* ${data.deliveryMunicipality}`,
        `*Endereço:* ${data.deliveryAddress}`,
        data.deliveryReference ? `*Ponto de Referência:* ${data.deliveryReference}` : null,
        ``,
        `*ARTIGOS ENCOMENDADOS:*`,
      ];

      richItems.forEach(i => {
        const varInfo = [i.size ? `Tam: ${i.size}` : null, i.color ? `Cor: ${i.color}` : null].filter(Boolean).join(' | ');
        lines.push(`• ${i.quantity}x ${i.productName}${varInfo ? ` (${varInfo})` : ''} - ${(i.price * i.quantity).toLocaleString('pt-AO')} Kz`);
      });

      lines.push(
        ``,
        `*Subtotal:* ${subtotal.toLocaleString('pt-AO')} Kz`,
        `*Taxa de Entrega:* ${shippingFee === 0 ? 'GRÁTIS' : `${shippingFee.toLocaleString('pt-AO')} Kz`}`,
        `*TOTAL A PAGAR NA ENTREGA:* ${total.toLocaleString('pt-AO')} Kz`,
        `*Método de Pagamento:* ${data.paymentMethod || 'No acto da entrega'}`,
        `🛡️ *Garantia:* 1 Semana (7 dias de garantia para troca/assistência técnica)`,
        ``,
        `Por favor, confirmem a disponibilidade e o horário de entrega do estafeta. Obrigado!`
      );

      const whatsappMessage = lines.filter(Boolean).join('\n');
      const whatsappUrl = `https://wa.me/244951556411?text=${encodeURIComponent(whatsappMessage)}`;

      const order: Order = {
        id: `ord-local-${Date.now()}`,
        orderNumber,
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        deliveryAddress: data.deliveryAddress,
        deliveryMunicipality: data.deliveryMunicipality,
        deliveryReference: data.deliveryReference,
        items: richItems,
        subtotal,
        shippingFee,
        total,
        paymentMethod: data.paymentMethod as any,
        paymentStatus: 'No acto da entrega',
        status: 'Pendente',
        statusHistory: [
          {
            status: 'Pendente',
            timestamp: now,
            changedBy: data.customerName,
            note: 'Pedido submetido pelo cliente no website.',
          },
        ],
        notes: data.notes,
        whatsappSent: false,
        createdAt: now,
        updatedAt: now,
      };

      return {
        message: 'Pedido realizado com sucesso!',
        order,
        whatsappMessage,
        whatsappUrl,
      };
    }
  },

  async getOrders(params?: {
    status?: string;
    search?: string;
    phone?: string;
    customerEmail?: string;
    customerPhone?: string;
    customerId?: string;
    onlyForUser?: { email?: string; phone?: string; id?: string };
  }) {
    try {
      return await supabaseData.getOrders(params);
    } catch {
      try {
        const query = new URLSearchParams();
        if (params?.status) query.append('status', params.status);
        if (params?.search) query.append('search', params.search);
        if (params?.phone) query.append('phone', params.phone);
        if (params?.customerEmail) query.append('customerEmail', params.customerEmail);
        if (params?.customerPhone) query.append('customerPhone', params.customerPhone);
        return await request<{ orders: Order[] }>(`/api/orders?${query.toString()}`);
      } catch {
        return { orders: [] };
      }
    }
  },

  async getOrder(idOrNumber: string, guestLookup?: boolean) {
    const rawQuery = idOrNumber.trim();

    // 1. Tentar consulta direta pelo número de encomenda ou ID no Supabase
    try {
      const direct = await supabaseData.getOrderByNumber(rawQuery);
      if (direct) {
        const whatsappMessage = `*Encomenda CarcubaExpress #${direct.orderNumber}*\nCliente: ${direct.customerName}\nEstado: ${direct.status}\nTotal: ${direct.total.toLocaleString('pt-AO')} Kz`;
        const whatsappUrl = `https://wa.me/244951556411?text=${encodeURIComponent(whatsappMessage)}`;
        return {
          order: direct,
          whatsappMessage,
          whatsappUrl,
        };
      }
    } catch {
      // Continua para busca em lista
    }

    // 2. Busca na lista de encomendas carregadas
    const { orders } = await this.getOrders();
    const query = rawQuery.toLowerCase();
    const cleanAlphaNum = query.replace(/[^a-z0-9]/g, '');

    const found = orders.find(o => {
      const ordNum = o.orderNumber.toLowerCase();
      const ordClean = ordNum.replace(/[^a-z0-9]/g, '');
      return (
        o.id === idOrNumber ||
        ordNum === query ||
        ordClean === cleanAlphaNum ||
        ordNum.endsWith(`-${query}`) ||
        ordNum.endsWith(`-${query.padStart(3, '0')}`) ||
        ordClean.includes(cleanAlphaNum)
      );
    });
    if (!found) throw new Error('Encomenda não encontrada');

    const whatsappMessage = `*Encomenda CarcubaExpress #${found.orderNumber}*\nCliente: ${found.customerName}\nEstado: ${found.status}\nTotal: ${found.total.toLocaleString('pt-AO')} Kz`;
    const whatsappUrl = `https://wa.me/244951556411?text=${encodeURIComponent(whatsappMessage)}`;

    return {
      order: found,
      whatsappMessage,
      whatsappUrl,
    };
  },

  async updateOrderStatus(
    id: string,
    data: {
      status: string;
      paymentStatus?: string;
      note?: string;
      courierName?: string;
      courierPhone?: string;
      deliveryAgent?: string;
      estimatedDeliveryDate?: string;
    }
  ) {
    try {
      return await supabaseData.updateOrderStatus(id, data as any);
    } catch (err: any) {
      try {
        return await request<{ message: string; order: Order }>(`/api/orders/${id}/status`, {
          method: 'PATCH',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async updatePaymentStatus(id: string, data: { paymentStatus: string; note?: string }) {
    return this.updateOrderStatus(id, data as any);
  },

  async updateDeliveryInfo(
    id: string,
    data: {
      courierName?: string;
      courierPhone?: string;
      deliveryAgent?: string;
      estimatedDeliveryDate?: string;
      notes?: string;
    }
  ) {
    return this.updateOrderStatus(id, data as any);
  },

  async deleteOrder(idOrNumber: string) {
    // 1. Try server-side deletion (enforces requireAdmin middleware)
    try {
      const res = await request<{ message: string; supabaseResult?: any }>(
        `/api/orders/${encodeURIComponent(idOrNumber)}`,
        {
          method: 'DELETE',
        }
      );
      // Ensure direct Supabase deletion is also executed
      try {
        await supabaseData.deleteOrder(idOrNumber);
      } catch {
        // Ignored if server already deleted it
      }
      return res;
    } catch {
      // Direct Supabase fallback
      return await supabaseData.deleteOrder(idOrNumber);
    }
  },

  // ==================== RESUMO FINANCEIRO & DESPESAS ====================
  async getFinancialSummary(params?: { period?: string; date?: string; startDate?: string; endDate?: string } | string) {
    try {
      const p = typeof params === 'string' ? { period: params } : params;
      return await supabaseData.getFinancialSummary(p);
    } catch {
      try {
        let q = '';
        if (typeof params === 'string') {
          q = `?period=${encodeURIComponent(params)}`;
        } else if (params) {
          const searchParams = new URLSearchParams();
          if (params.period) searchParams.append('period', params.period);
          if (params.date) searchParams.append('date', params.date);
          q = `?${searchParams.toString()}`;
        }
        return await request<FinancialSummary>(`/api/financials/summary${q}`);
      } catch (err: any) {
        throw new Error(err.message || 'Erro ao carregar resumo financeiro');
      }
    }
  },

  async getExpenses() {
    try {
      return await supabaseData.getExpenses();
    } catch {
      try {
        return await request<{ expenses: Expense[] }>('/api/financials/expenses');
      } catch {
        return { expenses: [] };
      }
    }
  },

  async createExpense(data: { title: string; category: string; amount: number; date?: string; note?: string }) {
    try {
      return await supabaseData.createExpense(data);
    } catch (err: any) {
      try {
        return await request<{ message: string; expense: Expense }>('/api/financials/expenses', {
          method: 'POST',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async updateExpense(
    id: string,
    data: { title?: string; category?: string; amount?: number; date?: string; note?: string }
  ) {
    try {
      return await supabaseData.updateExpense(id, data);
    } catch (err: any) {
      try {
        return await request<{ message: string; expense: Expense }>(`/api/financials/expenses/${id}`, {
          method: 'PUT',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async deleteExpense(id: string) {
    try {
      return await supabaseData.deleteExpense(id);
    } catch (err: any) {
      try {
        return await request<{ message: string; id: string }>(`/api/financials/expenses/${id}`, {
          method: 'DELETE',
        });
      } catch {
        throw err;
      }
    }
  },

  // ==================== CLIENTES ====================
  async getCustomers() {
    try {
      return await supabaseData.getCustomers();
    } catch {
      try {
        return await request<{ customers: CustomerData[] }>('/api/customers');
      } catch {
        return { customers: [] };
      }
    }
  },

  // ==================== CONFIGURAÇÕES DA LOJA ====================
  async getSettings() {
    try {
      return await supabaseData.getSettings();
    } catch {
      try {
        return await request<{ settings: StoreSettings }>('/api/settings');
      } catch {
        return { settings: supabaseData.getSettings ? (await supabaseData.getSettings()).settings : ({} as any) };
      }
    }
  },

  async updateSettings(data: Partial<StoreSettings>) {
    try {
      return await supabaseData.updateSettings(data);
    } catch (err: any) {
      try {
        return await request<{ message: string; settings: StoreSettings }>('/api/settings', {
          method: 'PUT',
          body: JSON.stringify(data),
        });
      } catch {
        throw err;
      }
    }
  },

  async resetCatalog() {
    return { message: 'Catálogo pronto.' };
  },

  // ==================== SUPABASE STATUS ====================
  async getSupabaseStatus() {
    try {
      const { count: prodCount } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true });
      const { count: ordCount } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true });

      return {
        connected: true,
        projectUrl: SUPABASE_URL,
        productsCount: prodCount || 0,
        ordersCount: ordCount || 0,
        checkedAt: new Date().toISOString(),
      };
    } catch (err: any) {
      return {
        connected: false,
        projectUrl: SUPABASE_URL,
        productsCount: 0,
        ordersCount: 0,
        error: err.message,
        checkedAt: new Date().toISOString(),
      };
    }
  },

  async getSupabaseProducts() {
    const { products } = await this.getProducts({ activeOnly: false });
    return { products };
  },

  async getSupabaseSqlSetup() {
    const sql = `
-- Script de Configuração Oficial CarcubaExpress no Supabase
-- Tabelas e Políticas RLS (Row Level Security)

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Permitir tudo em categories" ON public.categories;
CREATE POLICY "Permitir tudo em categories" ON public.categories FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Permitir tudo em products" ON public.products;
CREATE POLICY "Permitir tudo em products" ON public.products FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Permitir tudo em orders" ON public.orders;
CREATE POLICY "Permitir tudo em orders" ON public.orders FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Permitir tudo em order_items" ON public.order_items;
CREATE POLICY "Permitir tudo em order_items" ON public.order_items FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Permitir tudo em store_settings" ON public.store_settings;
CREATE POLICY "Permitir tudo em store_settings" ON public.store_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
    `.trim();

    return {
      projectUrl: SUPABASE_URL,
      sqlScript: sql,
    };
  },
};
