// Páginas legais PÚBLICAS (sem autenticação) exigidas pela verificação Google OAuth.
// Fonte única de conteúdo: usada pela página React (src/pages/PublicLegalPage.tsx)
// e pelo pré-render estático gerado no build (vite.config.ts) para que robôs
// (ex.: verificação Google) vejam o conteúdo mesmo sem executar JavaScript.

export const SITE_URL = 'https://carcubaexpress.com';
export const CONTACT_EMAIL = 'carcubaexpresscomercio@gmail.com';
export const LAST_UPDATED = '03 de novembro de 2026';
export const LOGO_SRC = '/assets/brand/logo-192.png';
export const LOGO_ALT = 'Logótipo CarcubaExpress Comércio';

export type PublicLegalSlug = 'privacy-policy' | 'terms';

interface Block {
  heading?: string;
  paragraphs?: string[];
  bullets?: string[];
}

export interface PublicLegalPage {
  slug: PublicLegalSlug;
  path: string;
  title: string; // título visível da página
  docTitle: string; // <title>
  description: string;
  heading: string; // H1 completo
  intro: string[];
  blocks: Block[];
}

export const PUBLIC_LEGAL_PAGES: Record<PublicLegalSlug, PublicLegalPage> = {
  'privacy-policy': {
    slug: 'privacy-policy',
    path: '/privacy-policy',
    title: 'Política de Privacidade',
    docTitle: 'Política de Privacidade — CarcubaExpress Comércio',
    description:
      'Política de Privacidade da CarcubaExpress Comércio: que dados recolhemos, como utilizamos a autenticação com Google, partilha, segurança e direitos dos utilizadores.',
    heading: 'Política de Privacidade — CarcubaExpress Comércio',
    intro: [
      'A CarcubaExpress Comércio respeita a privacidade e a proteção dos dados pessoais dos seus clientes e visitantes.',
    ],
    blocks: [
      {
        heading: 'Informações que recolhemos',
        paragraphs: [
          'Podemos recolher informações necessárias para o funcionamento da loja e processamento dos pedidos, incluindo:',
        ],
        bullets: [
          'Nome completo.',
          'Endereço de e-mail.',
          'Número de telefone.',
          'Endereço de entrega.',
          'Informações relacionadas com os pedidos realizados.',
        ],
      },
      {
        heading: 'Autenticação com Google',
        paragraphs: [
          'A nossa plataforma permite que os utilizadores iniciem sessão ou criem uma conta através da Google. Quando esta opção é utilizada, podemos receber informações autorizadas pela Google, como nome, endereço de e-mail e fotografia de perfil.',
          'Utilizamos essas informações exclusivamente para autenticação, identificação da conta e funcionamento dos serviços da loja.',
        ],
      },
      {
        heading: 'Utilização dos dados',
        paragraphs: ['Os dados recolhidos são utilizados para:'],
        bullets: [
          'Processar e acompanhar pedidos.',
          'Contactar clientes sobre entregas.',
          'Gerir contas de utilizadores.',
          'Melhorar os serviços da plataforma.',
          'Garantir a segurança das contas.',
        ],
      },
      {
        heading: 'Partilha de informações',
        paragraphs: [
          'Não comercializamos os dados pessoais dos nossos clientes. As informações poderão ser processadas por fornecedores técnicos necessários ao funcionamento da plataforma, sempre para as finalidades descritas nesta política.',
        ],
      },
      {
        heading: 'Segurança',
        paragraphs: [
          'Adotamos medidas técnicas e administrativas para proteger as informações dos utilizadores contra acessos não autorizados, alterações ou divulgação indevida.',
        ],
      },
      {
        heading: 'Direitos dos utilizadores',
        paragraphs: [
          'Os utilizadores podem solicitar informações sobre os seus dados pessoais, correção ou eliminação dos seus dados, através dos nossos canais de contacto, respeitando as obrigações legais aplicáveis.',
        ],
      },
    ],
  },
  terms: {
    slug: 'terms',
    path: '/terms',
    title: 'Termos de Serviço',
    docTitle: 'Termos de Serviço — CarcubaExpress Comércio',
    description:
      'Termos de Serviço da CarcubaExpress Comércio: utilização da plataforma, contas de utilizadores, pedidos e entregas, pagamento na entrega, produtos, cancelamentos e devoluções.',
    heading: 'Termos de Serviço — CarcubaExpress Comércio',
    intro: [
      'Bem-vindo à CarcubaExpress Comércio. Ao utilizar o nosso website, o utilizador concorda com os presentes Termos de Serviço.',
    ],
    blocks: [
      {
        heading: '1. Utilização da plataforma',
        paragraphs: [
          'A CarcubaExpress Comércio é uma loja online que disponibiliza produtos de diferentes categorias, incluindo eletrónicos, vestuário, cosméticos e outros produtos.',
        ],
      },
      {
        heading: '2. Contas de utilizadores',
        paragraphs: [
          'Os clientes podem criar contas através do e-mail e palavra-passe ou através da autenticação com Google, quando disponível.',
          'Cada utilizador é responsável pela segurança das suas credenciais de acesso.',
        ],
      },
      {
        heading: '3. Pedidos e entregas',
        paragraphs: [
          'Os clientes podem selecionar produtos, indicar o endereço de entrega e informar a data pretendida para receber os pedidos.',
          'A confirmação da entrega será realizada posteriormente pela equipa da CarcubaExpress Comércio.',
        ],
      },
      {
        heading: '4. Pagamentos',
        paragraphs: [
          'A modalidade de pagamento disponibilizada pela loja é o pagamento na entrega, conforme as condições apresentadas durante a realização do pedido.',
        ],
      },
      {
        heading: '5. Produtos e preços',
        paragraphs: [
          'As informações, características e preços dos produtos são apresentados na plataforma e podem ser atualizados sempre que necessário.',
        ],
      },
      {
        heading: '6. Cancelamentos e devoluções',
        paragraphs: [
          'Para questões relacionadas com cancelamentos, devoluções ou problemas com pedidos, os clientes devem contactar a equipa de suporte.',
        ],
      },
    ],
  },
};

export const PUBLIC_LEGAL_LIST = Object.values(PUBLIC_LEGAL_PAGES);

/** Devolve a página legal correspondente ao caminho (aceita barra final), ou null. */
export function matchPublicLegalPath(pathname: string): PublicLegalPage | null {
  const clean = pathname.replace(/\/+$/, '').toLowerCase() || '/';
  return PUBLIC_LEGAL_LIST.find(p => p.path === clean) ?? null;
}

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/**
 * HTML da página (mesmas classes Tailwind e cores da loja: azul #0B1E36 + âmbar).
 * Usado tanto no React (dangerouslySetInnerHTML — conteúdo estático e de confiança)
 * como no pré-render estático.
 */
export function renderPublicLegalHtml(page: PublicLegalPage): string {
  const nav = PUBLIC_LEGAL_LIST.map(
    p =>
      `<a href="${p.path}" class="hover:text-amber-400 transition-colors ${
        p.slug === page.slug ? 'text-amber-400 font-bold' : 'text-slate-300'
      }">${esc(p.title)}</a>`
  ).join('<span class="text-white/20" aria-hidden="true">·</span>');

  const blocks = page.blocks
    .map(b => {
      const paras = (b.paragraphs ?? []).map(p => `<p class="leading-relaxed">${esc(p)}</p>`).join('');
      const bullets = b.bullets?.length
        ? `<ul class="space-y-2 pl-1 pt-1">${b.bullets
            .map(
              li =>
                `<li class="flex items-start gap-2"><span class="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-2"></span><span>${esc(li)}</span></li>`
            )
            .join('')}</ul>`
        : '';
      return `<section class="py-6 space-y-3">${
        b.heading
          ? `<h2 class="text-base sm:text-lg font-bold text-[#0B1E36] flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span><span>${esc(b.heading)}</span></h2>`
          : ''
      }<div class="space-y-2 text-slate-700">${paras}${bullets}</div></section>`;
    })
    .join('');

  const contact = `<section class="py-6 space-y-3"><h2 class="text-base sm:text-lg font-bold text-[#0B1E36] flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span><span>${
    page.slug === 'terms' ? '7. Contacto' : 'Contacto'
  }</span></h2><div class="space-y-2 text-slate-700"><p>E-mail: <a class="font-semibold text-[#0B1E36] underline decoration-amber-500 hover:text-amber-600" href="mailto:${CONTACT_EMAIL}">${CONTACT_EMAIL}</a></p><p>Website: <a class="font-semibold text-[#0B1E36] underline decoration-amber-500 hover:text-amber-600" href="${SITE_URL}">${SITE_URL}</a></p></div></section>`;

  return `<div class="min-h-screen bg-[#F8FAFC] flex flex-col font-sans text-slate-800">
<header class="bg-[#0B1E36] text-white border-b border-[#173359]">
<div class="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-3">
<a href="/" class="flex items-center gap-3 min-w-0" aria-label="CarcubaExpress Comércio — página inicial">
<img src="${LOGO_SRC}" alt="${LOGO_ALT}" width="48" height="48" class="w-12 h-12 object-contain rounded-full shadow-md border border-amber-400/50 bg-white p-0.5 shrink-0" />
<span class="min-w-0"><span class="text-lg sm:text-xl font-extrabold tracking-tight text-white block leading-none">Carcuba<span class="text-amber-400">Express</span></span><span class="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Comércio · Luanda</span></span>
</a>
<a href="/" class="shrink-0 px-3 py-2 text-xs font-semibold bg-white/10 hover:bg-amber-500 hover:text-slate-900 text-white rounded-lg transition-colors border border-white/10">← Voltar à loja</a>
</div>
</header>
<main class="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
<article class="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-10 text-sm sm:text-base">
<span class="text-[10px] font-extrabold uppercase tracking-wider text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded-full inline-block mb-2">${esc(page.title)}</span>
<h1 class="text-2xl sm:text-3xl font-extrabold text-[#0B1E36] tracking-tight">${esc(page.heading)}</h1>
<p class="text-xs text-slate-500 mt-2 font-mono">Última atualização: ${LAST_UPDATED}.</p>
<div class="mt-5 space-y-3 text-slate-700">${page.intro.map(p => `<p class="leading-relaxed">${esc(p)}</p>`).join('')}</div>
<div class="divide-y divide-slate-100">${blocks}${contact}</div>
</article>
</main>
<footer class="bg-[#0B1E36] text-white border-t border-[#173359]">
<div class="max-w-4xl mx-auto px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
<p>© 2026 CarcubaExpress Comércio. Todos os direitos reservados. Luanda, Angola.</p>
<nav aria-label="Páginas legais" class="flex items-center gap-3 text-xs">${nav}</nav>
</div>
</footer>
</div>`;
}
