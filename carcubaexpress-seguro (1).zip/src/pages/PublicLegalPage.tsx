import React, { useEffect } from 'react';
import { type PublicLegalPage as PageData, renderPublicLegalHtml } from './publicLegalPages';

/**
 * Página pública (sem login, sem providers de autenticação/carrinho) para
 * /privacy-policy e /terms. O HTML é gerado a partir de conteúdo estático local.
 */
export const PublicLegalPage: React.FC<{ page: PageData }> = ({ page }) => {
  useEffect(() => {
    document.title = page.docTitle;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', page.description);
    window.scrollTo({ top: 0 });
  }, [page]);

  return <div dangerouslySetInnerHTML={{ __html: renderPublicLegalHtml(page) }} />;
};
