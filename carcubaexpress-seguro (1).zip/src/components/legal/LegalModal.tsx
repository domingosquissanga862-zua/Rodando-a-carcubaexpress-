import React, { useState } from 'react';
import { X, ShieldCheck, FileText, Truck, Lock, MessageCircle, CheckCircle2, ChevronRight, Phone, Printer } from 'lucide-react';
import { LEGAL_POLICIES, type LegalSection } from './legalContent';
import { useCart } from '../../context/CartContext';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'terms' | 'privacy' | 'shipping' | 'warranty';
}

export const LegalModal: React.FC<LegalModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'terms',
}) => {
  const { settings } = useCart();
  const [activeTab, setActiveTab] = useState<'terms' | 'privacy' | 'shipping' | 'warranty'>(initialTab);

  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isOpen]);

  if (!isOpen) return null;

  const currentPolicy = LEGAL_POLICIES[activeTab] || LEGAL_POLICIES.terms;
  const whatsappNumber = (settings?.whatsappNumber || '244951556411').replace(/\D/g, '');
  const supportPhone = settings?.supportPhone || '+244 951 556 411';

  const tabIcons = {
    terms: <FileText className="w-4 h-4 shrink-0" />,
    privacy: <Lock className="w-4 h-4 shrink-0" />,
    shipping: <Truck className="w-4 h-4 shrink-0" />,
    warranty: <ShieldCheck className="w-4 h-4 shrink-0" />,
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-6 flex flex-col max-h-[90vh] animate-scale-up"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-[#0B1E36] text-white flex items-center justify-between shrink-0 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold text-white">CarcubaExpress Comércio</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-900">
                  Políticas Oficiais
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Termos Legais, Privacidade (Lei 22/11 de Angola), Entregas em Luanda & Garantia
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              title="Imprimir documento legal"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimir</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Fechar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 px-4 sm:px-6 overflow-x-auto no-scrollbar shrink-0 gap-2 py-2.5">
          {(Object.keys(LEGAL_POLICIES) as Array<keyof typeof LEGAL_POLICIES>).map(key => {
            const item = LEGAL_POLICIES[key];
            const isActive = activeTab === key;
            return (
              <button
                key={key}
                onClick={() => setActiveTab(key as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-[#0B1E36] text-white shadow-sm'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-100'
                }`}
              >
                <span className={isActive ? 'text-amber-400' : 'text-slate-500'}>
                  {tabIcons[key as keyof typeof tabIcons]}
                </span>
                <span>{item.shortTitle}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1 text-slate-800 text-xs sm:text-sm leading-relaxed">
          {/* Section Banner */}
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded-full inline-block mb-1">
                {currentPolicy.badge}
              </span>
              <h2 className="text-base sm:text-lg font-extrabold text-[#0B1E36]">
                {currentPolicy.title}
              </h2>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                {currentPolicy.summary}
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[10px] text-slate-400 block font-mono">Última atualização</span>
              <span className="text-xs font-bold text-slate-700 font-mono">
                {currentPolicy.lastUpdated}
              </span>
            </div>
          </div>

          {/* Legal Articles */}
          <div className="space-y-6 divide-y divide-slate-100">
            {currentPolicy.content.map((sec, idx) => (
              <div key={idx} className={`${idx > 0 ? 'pt-6' : ''} space-y-3`}>
                <h3 className="text-sm sm:text-base font-bold text-[#0B1E36] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                  <span>{sec.heading}</span>
                </h3>

                <div className="space-y-2 text-slate-700 pl-4">
                  {sec.paragraphs.map((p, pIdx) => (
                    <p key={pIdx} className="leading-relaxed">
                      {p}
                    </p>
                  ))}
                </div>

                {sec.bullets && sec.bullets.length > 0 && (
                  <ul className="space-y-2 pl-6 pt-1">
                    {sec.bullets.map((b, bIdx) => (
                      <li key={bIdx} className="flex items-start gap-2 text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer Support Bar */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Dúvidas sobre os nossos termos?</span>
            <a
              href={`tel:${supportPhone.replace(/\s+/g, '')}`}
              className="font-bold text-slate-800 hover:text-amber-600 flex items-center gap-1 font-mono"
            >
              <Phone className="w-3.5 h-3.5 text-amber-500" />
              <span>{supportPhone}</span>
            </a>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <a
              href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
                `Olá CarcubaExpress! Gostaria de esclarecer uma dúvida sobre os vossos ${currentPolicy.shortTitle}.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Apoio via WhatsApp</span>
            </a>

            <button
              onClick={onClose}
              className="px-5 py-2 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-bold rounded-xl text-xs cursor-pointer transition-colors"
            >
              Compreendido
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
