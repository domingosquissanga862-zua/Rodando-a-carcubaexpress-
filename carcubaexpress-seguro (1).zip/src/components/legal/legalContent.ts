export interface LegalSection {
  id: 'terms' | 'privacy' | 'shipping' | 'warranty';
  title: string;
  shortTitle: string;
  badge: string;
  summary: string;
  lastUpdated: string;
  content: {
    heading: string;
    paragraphs: string[];
    bullets?: string[];
  }[];
}

export const LEGAL_POLICIES: Record<string, LegalSection> = {
  terms: {
    id: 'terms',
    title: 'Termos e Condições Gerais de Uso e Venda',
    shortTitle: 'Termos e Condições',
    badge: 'Contrato de Utilização & Venda',
    lastUpdated: '1 de Novembro de 2026',
    summary:
      'Estes termos regem o acesso, navegação, criação de conta e compra de produtos na plataforma CarcubaExpress Comércio em Luanda, Angola.',
    content: [
      {
        heading: '1. Identificação da Empresa e Âmbito do Serviço',
        paragraphs: [
          'A CarcubaExpress Comércio é uma entidade comercial registada em Luanda, República de Angola, dedicada ao comércio a retalho de eletrónicos, equipamentos de áudio e gravação, fragrâncias e perfumaria premium, moda feminina, acessórios e artigos utilitários.',
          'Os presentes Termos e Condições aplicam-se a todos os utilizadores, visitantes e clientes da loja online e estabelecem as regras contratuais vinculativas de encomenda, entrega e assistência pós-venda na província de Luanda e território nacional angolano.',
        ],
      },
      {
        heading: '2. Registo de Conta e Autenticação Obrigatória',
        paragraphs: [
          'Para garantir a segurança, integridade das transações e o isolamento dos dados de cada cliente, a criação e finalização de encomendas exige a titularidade de uma conta de utilizador válida e autenticada.',
          'O utilizador compromete-se a fornecer informações verdadeiras, atualizadas e completas no ato de registo (nome completo, número de telefone angolano válido, endereço de correio eletrónico e morada de entrega).',
        ],
        bullets: [
          'A palavra-passe deve ser pessoal e intransmissível, contendo critérios rigorosos de segurança.',
          'Cada conta é estritamente individual; o utilizador tem acesso exclusivo aos seus respetivos pedidos e histórico de faturas.',
          'É expressamente proibida a criação de contas com identidades falsas ou o uso não autorizado de dados de terceiros.',
        ],
      },
      {
        heading: '3. Preços, Moeda Oficial e Disponibilidade de Stock',
        paragraphs: [
          'Todos os preços apresentados na loja CarcubaExpress estão expressos na moeda oficial de Angola: Kwanza Angolano (Kz).',
          'Os preços indicados no momento da submissão da encomenda são finais e vinculativos para essa transação. Caso ocorra erro tipográfico manifesto de preço, a CarcubaExpress contactará o cliente antes da expedição para retificação ou cancelamento consensual.',
        ],
      },
      {
        heading: '4. Modalidade Exclusiva de Pagamento no Acto da Entrega',
        paragraphs: [
          'Em consonância com as melhores práticas de transparência no comércio eletrónico em Angola e para total tranquilidade do consumidor, a CarcubaExpress opera sob o modelo de Pagamento no Acto da Entrega (Cash-on-Delivery / Express no Local).',
          'Nenhum cliente é obrigado a pagar adiantado por transferência antes de ter o produto fisicamente perante si.',
        ],
        bullets: [
          'Dinheiro em mão (notas físicas de Kwanza entregues diretamente ao estafeta credenciado).',
          'Multicaixa Express (transferência instantânea via aplicação Multicaixa Express efetuada na presença do estafeta após conferência física dos artigos).',
        ],
      },
      {
        heading: '5. Verificação Obrigatória no Momento da Entrega',
        paragraphs: [
          'O cliente tem o direito e o dever de abrir a embalagem e verificar o estado físico, integridade e conformidade do produto juntamente com o estafeta antes de efetuar o pagamento correspondente.',
          'Após o pagamento, o estafeta e o sistema oficial da CarcubaExpress emitem a respetiva Fatura/Recibo com garantia legal de 1 semana (7 dias).',
        ],
      },
    ],
  },
  privacy: {
    id: 'privacy',
    title: 'Política de Privacidade e Proteção de Dados Pessoais',
    shortTitle: 'Privacidade & Dados',
    badge: 'Lei n.º 22/11 de Angola',
    lastUpdated: '1 de Novembro de 2026',
    summary:
      'Compromisso formal com a privacidade, sigilo e proteção dos dados pessoais dos nossos clientes em estrita conformidade com a legislação de Angola.',
    content: [
      {
        heading: '1. Enquadramento Legal e Responsável pelo Tratamento',
        paragraphs: [
          'A CarcubaExpress Comércio assume o compromisso de salvaguardar a privacidade e a segurança dos dados pessoais de todos os utilizadores, em rigoroso cumprimento da Lei n.º 22/11 de 17 de Junho (Lei da Protecção de Dados Pessoais de Angola) e da legislação aplicável às comunicações eletrónicas e serviços da sociedade da informação.',
          'O responsável pelo tratamento dos dados recolhidos é a CarcubaExpress Comércio, com sede de operações em Luanda, Angola.',
        ],
      },
      {
        heading: '2. Dados Pessoais Recolhidos e Finalidade Estrita',
        paragraphs: [
          'Recolhemos apenas os dados indispensáveis para o processamento, entrega e suporte das encomendas efetuadas pelo utilizador:',
        ],
        bullets: [
          'Nome completo: para identificação do destinatário da encomenda e emissão de fatura/recibo.',
          'Número de telefone / WhatsApp (Angola): para coordenação da rota de entrega com o estafeta e envio de atualizações em tempo real.',
          'Endereço de correio eletrónico (Email): para autenticação segura no Supabase Auth, recuperação de senha e registo fiscal.',
          'Endereço e Município de Luanda com ponto de referência: para localização física do local de entrega pelo estafeta.',
        ],
      },
      {
        heading: '3. Isolamento Tecnológico e Confidencialidade Absoluta',
        paragraphs: [
          'A plataforma implementa políticas rigorosas de Row Level Security (RLS) e isolamento criptográfico na base de dados Supabase.',
          'Isto garante que nenhum cliente tem acesso, visibilidade ou possibilidade de consultar pedidos, moradas ou números de telefone pertencentes a outro utilizador. Cada painel de cliente exibe exclusivamente os registos associados à respetiva conta autenticada.',
        ],
        bullets: [
          'As palavras-passe são encriptadas irreversivelmente (hash seguro); a nossa equipa nunca tem acesso à sua palavra-passe em texto limpo.',
          'Não comercializamos, alugamos, cedemos nem partilhamos a sua informação pessoal com quaisquer empresas terceiras para fins de publicidade.',
          'O acesso aos dados de entrega é estritamente facultado ao estafeta em serviço para o cumprimento da entrega contratada.',
        ],
      },
      {
        heading: '4. Direitos do Titular dos Dados (Acesso, Retificação e Eliminação)',
        paragraphs: [
          'Em conformidade com os artigos da Lei n.º 22/11, assiste ao utilizador o direito irrevogável de:',
        ],
        bullets: [
          'Aceder a qualquer momento aos seus dados e histórico de encomendas no Painel do Cliente.',
          'Retificar informações incorretas ou desatualizadas (telefone, endereço, nome).',
          'Solicitar a eliminação definitiva da sua conta e anonimização de dados junto do nosso apoio ao cliente via WhatsApp (+244 951 556 411) ou email oficial.',
        ],
      },
    ],
  },
  shipping: {
    id: 'shipping',
    title: 'Política de Envios, Entregas ao Domicílio e Taxas por Município',
    shortTitle: 'Entregas & Prazos',
    badge: 'Logística Rápida em Luanda',
    lastUpdated: '1 de Novembro de 2026',
    summary:
      'Prazos, taxas de envio e procedimentos logísticos da frota de estafetas da CarcubaExpress na província de Luanda.',
    content: [
      {
        heading: '1. Área de Cobertura e Municípios Abrangidos',
        paragraphs: [
          'A CarcubaExpress dispõe de rede de distribuição própria e estafetas motorizados cobrindo todos os municípios da província de Luanda:',
        ],
        bullets: [
          'Luanda Urbana (Ingombota, Maianga, Rangel, Sambizanga): Entrega no próprio dia ou até 24h úteis (Taxa: 2.000 Kz).',
          'Talatona (Benfica, Morro Bento, Camama, Cidade Universitária): No próprio dia ou até 24h úteis (Taxa: 2.500 Kz).',
          'Belas (Kilamba, Centralidade do Kilamba, KK5000): 24h a 48h úteis (Taxa: 3.000 Kz).',
          'Kilamba Kiaxi (Golf 1 e 2, Palanca, Neves Bendinha): 24h úteis (Taxa: 2.500 Kz).',
          'Viana (Zango 1 a 4, Estalagem, Vila de Viana, Grafanil): 24h a 48h úteis (Taxa: 3.000 Kz).',
          'Cazenga (Hoji-ya-Henda, Tala Hady, Cazenga Popular): 24h úteis (Taxa: 2.500 Kz).',
          'Cacuaco (Vila, Centralidade do Sequele, Kifangondo): 24h a 48h úteis (Taxa: 3.500 Kz).',
          'Icolo e Bengo (Catete) e Quiçama: 48h a 72h úteis sob agendamento prévio.',
        ],
      },
      {
        heading: '2. Envio Grátis para Compras Elegíveis',
        paragraphs: [
          'Para todas as encomendas de valor igual ou superior a 50.000 Kz, a taxa de entrega ao domicílio é 100% GRATUITA em qualquer município de Luanda.',
          'Adicionalmente, produtos com a etiqueta oficial "Entrega Grátis em Luanda" beneficiam de taxa zero independente do valor da compra.',
        ],
      },
      {
        heading: '3. Procedimento do Estafeta e Contacto Prévio Obrigatório',
        paragraphs: [
          'Para sua total comodidade e segurança, o nosso estafeta entra SEMPRE em contacto por chamada telefónica ou mensagem WhatsApp antes de se deslocar para a sua morada.',
          'O cliente pode fornecer instruções complementares (ponto de referência, cor do portão, número de porta ou guarita do condomínio) diretamente ao estafeta designado.',
        ],
      },
      {
        heading: '4. Reagendamento e Ausência do Destinatário',
        paragraphs: [
          'Caso o cliente não se encontre no local no horário acordado, o estafeta aguardará até 15 minutos e fará contacto telefónico. Não sendo possível a receção, a encomenda será reagendada sem custos adicionais abusivos para o próximo dia útil.',
        ],
      },
    ],
  },
  warranty: {
    id: 'warranty',
    title: 'Política de Garantia Oficial (7 Dias), Trocas e Devoluções',
    shortTitle: 'Garantia & Trocas',
    badge: '1 Semana de Garantia Oficial',
    lastUpdated: '1 de Novembro de 2026',
    summary:
      'Garantia oficial CarcubaExpress de 1 semana (7 dias) em todos os artigos comercializados, assegurando assistência técnica, substituição imediata ou reembolso.',
    content: [
      {
        heading: '1. Garantia Oficial CarcubaExpress: 1 Semana (7 Dias)',
        paragraphs: [
          'Todos os artigos tecnológicos, eletrónicos, microfones de lapela sem fios, fragrâncias e acessórios adquiridos na CarcubaExpress possuem garantia oficial de conformidade durante 7 dias corridos a contar da data de entrega física comprovada na Fatura/Recibo.',
          'Esta garantia cobre qualquer defeito de fabrico, vício oculto ou anomalia operacional não provocada por mau uso.',
        ],
      },
      {
        heading: '2. Condições para Acionar a Troca ou Reembolso',
        paragraphs: [
          'Para usufruir da garantia oficial de 7 dias, devem ser cumpridos os seguintes requisitos simples:',
        ],
        bullets: [
          'Apresentação do número de encomenda (ex: CAR-2026-XXXX) ou fatura/recibo em formato digital (PDF).',
          'O artigo deve ser devolvido na sua caixa original acompanhado de todos os acessórios, cabos, manuais e adaptadores fornecidos.',
          'O equipamento não deve apresentar sinais evidentes de danos acidentais por queda, contacto com líquidos ou abertura não autorizada.',
        ],
      },
      {
        heading: '3. Procedimento de Troca Imediata em Luanda',
        paragraphs: [
          'O procedimento para acionar a garantia é simples e direto:',
        ],
        bullets: [
          '1. Contacte o nosso apoio ao cliente via WhatsApp oficial (+244 951 556 411) informando o número do pedido e um breve vídeo/foto do comportamento do artigo.',
          '2. A nossa equipa valida a solicitação no prazo de 2 a 4 horas.',
          '3. Um estafeta desloca-se até ao seu endereço em Luanda para recolher o artigo e entregar uma unidade nova selada sem custos de deslocação para o cliente.',
          '4. Caso o produto esteja esgotado em stock, o cliente pode optar pela troca por outro artigo equivalente ou pelo reembolso integral do valor pago.',
        ],
      },
    ],
  },
};
