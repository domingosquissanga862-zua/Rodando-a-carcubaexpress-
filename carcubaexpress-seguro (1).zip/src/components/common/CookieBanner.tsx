import React, { useEffect, useState } from 'react';
import { Cookie } from 'lucide-react';

const STORAGE_KEY = 'carcuba_cookie_notice_v1';

/**
 * Aviso de cookies / armazenamento local.
 * A loja usa apenas armazenamento essencial (sessão de login, carrinho e
 * preferências) — não existem cookies de publicidade nem de rastreamento.
 * A escolha é guardada no navegador; se o armazenamento estiver bloqueado,
 * o aviso simplesmente volta a aparecer.
 */
export const CookieBanner: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (!window.localStorage.getItem(STORAGE_KEY)) setVisible(true);
    } catch {
      setVisible(true);
    }
  }, []);

  if (!visible) return null;

  const accept = () => {
    try {
      window.localStorage.setItem(STORAGE_KEY, new Date().toISOString());
    } catch {
      // ignore
    }
    setVisible(false);
  };

  return (
    <div
      role="dialog"
      aria-label="Aviso de cookies"
      className="fixed bottom-3 left-3 right-3 sm:right-auto sm:bottom-5 sm:left-5 sm:max-w-md z-[45] bg-[#0B1E36] text-white rounded-2xl border border-white/10 shadow-2xl p-4 animate-fade-in"
    >
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-xl bg-white/5 border border-white/10 text-amber-400 shrink-0">
          <Cookie className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <p className="text-xs font-bold text-white">Cookies e armazenamento local</p>
          <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
            Usamos apenas cookies e armazenamento essenciais para manter a sua sessão, o carrinho e o
            funcionamento seguro da loja. Não usamos cookies de publicidade. Saiba mais na nossa{' '}
            <a href="/privacy-policy" className="text-amber-400 underline hover:text-amber-300">
              Política de Privacidade
            </a>
            .
          </p>
          <button
            type="button"
            onClick={accept}
            className="mt-3 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs cursor-pointer shadow-sm transition-colors"
          >
            Compreendido
          </button>
        </div>
      </div>
    </div>
  );
};
