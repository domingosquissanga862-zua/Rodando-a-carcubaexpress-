import React, { useState } from 'react';
import { ShoppingBag, Search, User as UserIcon, Shield, Menu, X, Truck, ChevronRight } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import type { Category } from '../../types';

interface HeaderProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (catId: string) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  onOpenAuth: (initialTab?: 'login' | 'register') => void;
  onOpenAdmin: () => void;
  onNavigateHome: () => void;
  onNavigateTracking: () => void;
  onOpenLegal?: (tab?: 'terms' | 'privacy' | 'shipping' | 'warranty') => void;
}

export const Header: React.FC<HeaderProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  searchTerm,
  onSearchChange,
  onOpenAuth,
  onOpenAdmin,
  onNavigateHome,
  onNavigateTracking,
  onOpenLegal,
}) => {
  const { itemCount, setIsCartOpen } = useCart();
  const { user, isAdmin } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 w-full overflow-x-clip">
      {/* Main Top Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between gap-2 sm:gap-4 md:gap-8 w-full">
        {/* Zone 1: Brand Wordmark with Official Logo */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0 min-w-0">
          <button
            onClick={() => {
              onNavigateHome();
              onSelectCategory('all');
            }}
            className="flex items-center gap-2 sm:gap-3 text-left group cursor-pointer"
          >
            <img
              src="/assets/aistudio/logo_a1884a32.jpg"
              alt="Logótipo CarcubaExpress Comércio"
              className="w-10 h-10 sm:w-12 sm:h-12 object-contain rounded-full shadow-md border-2 border-amber-400/60 bg-white p-0.5 shrink-0 group-hover:scale-105 transition-transform"
            />
            <div className="min-w-0">
              <div className="text-base sm:text-xl font-extrabold tracking-tight text-[#0B1E36] flex items-center gap-1 leading-none whitespace-nowrap">
                <span>Carcuba</span>
                <span className="text-amber-500">Express</span>
              </div>
              <p className="text-[9px] sm:text-[10px] uppercase tracking-wider text-slate-500 font-bold mt-0.5 sm:mt-1 whitespace-nowrap">
                Comércio · Luanda
              </p>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-700">
          <button
            onClick={() => {
              onNavigateHome();
              onSelectCategory('all');
            }}
            className={`transition-colors whitespace-nowrap hover:text-amber-600 ${
              selectedCategory === 'all' ? 'text-amber-600 font-semibold' : ''
            }`}
          >
            Todos os Produtos
          </button>
          {categories.slice(0, 4).map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                onNavigateHome();
                onSelectCategory(cat.id);
              }}
              className={`transition-colors whitespace-nowrap hover:text-amber-600 ${
                selectedCategory === cat.id ? 'text-amber-600 font-semibold' : ''
              }`}
            >
              {cat.name}
            </button>
          ))}
          <button
            onClick={onNavigateTracking}
            className="transition-colors whitespace-nowrap hover:text-amber-600 text-slate-600 cursor-pointer"
          >
            Acompanhar Pedido
          </button>
          {onOpenLegal && (
            <button
              onClick={() => onOpenLegal('terms')}
              className="transition-colors whitespace-nowrap hover:text-amber-600 text-slate-500 text-xs font-semibold cursor-pointer"
            >
              Políticas & Termos
            </button>
          )}
        </nav>

        {/* Zone 3: Primary Action & Controls */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* Live Search input */}
          <div className="relative hidden xl:block w-48">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Pesquisar produto..."
              value={searchTerm}
              onChange={e => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                ×
              </button>
            )}
          </div>

          {/* Admin Panel Direct Button */}
          {isAdmin && (
            <button
              onClick={onOpenAdmin}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-xl text-xs font-bold transition-all shadow-sm shrink-0 cursor-pointer active:scale-95"
              title="Aceder ao Painel Administrativo"
            >
              <Shield className="w-3.5 h-3.5 text-slate-900" />
              <span>Painel Admin</span>
            </button>
          )}

          {/* Auth State & Buttons - Prominent & Responsive */}
          {user ? (
            <button
              onClick={() => onOpenAuth('login')}
              className="flex items-center gap-1.5 sm:gap-2 px-2.5 py-1.5 sm:px-3 sm:py-2 bg-slate-100 hover:bg-slate-200 text-[#0B1E36] rounded-xl text-xs font-bold transition-all border border-slate-200 shrink-0 cursor-pointer active:scale-95"
              title="Aceder ao seu perfil e histórico de pedidos"
            >
              <div className="w-6 h-6 rounded-full bg-amber-500 text-slate-900 flex items-center justify-center text-[11px] font-black shrink-0">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <span className="hidden sm:inline">
                {isAdmin ? 'Admin' : user.name.split(' ')[0]}
              </span>
              <span className="text-[10px] text-amber-800 font-semibold bg-amber-100/80 px-1.5 py-0.5 rounded-md hidden md:inline">
                Meus Pedidos
              </span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              <button
                onClick={() => onOpenAuth('login')}
                className="flex items-center gap-1 px-2.5 py-1.5 sm:px-3 sm:py-2 text-[11px] sm:text-xs font-bold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg sm:rounded-xl transition-all shadow-xs cursor-pointer active:scale-95 whitespace-nowrap shrink-0"
                title="Iniciar Sessão na sua conta CarcubaExpress"
              >
                <UserIcon className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>Entrar</span>
              </button>

              <button
                onClick={() => onOpenAuth('register')}
                className="hidden md:inline-flex items-center gap-1 px-3.5 py-2 text-xs font-extrabold text-slate-900 bg-amber-500 hover:bg-amber-400 rounded-xl transition-all shadow-xs cursor-pointer active:scale-95 whitespace-nowrap shrink-0"
                title="Criar nova conta na CarcubaExpress"
              >
                <span>Criar Conta</span>
              </button>
            </div>
          )}

          {/* Cart Trigger Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center justify-center p-2 sm:p-2.5 bg-[#0B1E36] text-white rounded-lg sm:rounded-xl hover:bg-[#132c4d] transition-all btn-bounce shrink-0 shadow-sm cursor-pointer"
            aria-label="Ver Carrinho de Compras"
          >
            <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            {itemCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-900 text-[10px] sm:text-[11px] font-extrabold w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center shadow-sm animate-scale-in">
                {itemCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle (3-Bars Hamburger) - Always Visible on Phone */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="w-9 h-9 sm:w-10 sm:h-10 p-1.5 text-slate-700 hover:bg-slate-100 rounded-lg sm:rounded-xl lg:hidden shrink-0 flex items-center justify-center cursor-pointer active:scale-95 bg-slate-50 border border-slate-200/80 shadow-xs"
            aria-label="Abrir menu de navegação"
            title="Menu de navegação"
          >
            {isMobileMenuOpen ? (
              <X className="w-5 h-5 sm:w-6 sm:h-6 text-[#0B1E36]" />
            ) : (
              <Menu className="w-5 h-5 sm:w-6 sm:h-6 text-[#0B1E36]" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer / Dropdown */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-4">
          {/* Prominent Auth Callout in Mobile */}
          {!user ? (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-2.5">
              <div>
                <p className="text-xs font-extrabold text-slate-900">Conta de Cliente CarcubaExpress</p>
                <p className="text-[11px] text-slate-600">
                  Crie a sua conta ou inicie sessão para adicionar artigos ao carrinho e encomendar com pagamento no acto da entrega em Luanda.
                </p>
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => {
                    onOpenAuth('login');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2 px-3 bg-[#0B1E36] text-white rounded-xl text-xs font-bold text-center cursor-pointer"
                >
                  Iniciar Sessão
                </button>
                <button
                  onClick={() => {
                    onOpenAuth('register');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-xl text-xs font-extrabold text-center cursor-pointer shadow-xs"
                >
                  Criar Conta
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-amber-500 text-slate-900 flex items-center justify-center font-black text-sm">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">{user.name}</p>
                  <p className="text-[10px] text-slate-500 font-mono">{user.email}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  onOpenAuth('login');
                  setIsMobileMenuOpen(false);
                }}
                className="px-3 py-1.5 bg-[#0B1E36] text-white rounded-xl text-xs font-bold"
              >
                Os Meus Pedidos
              </button>
            </div>
          )}

          {/* 1. TOP PRIORITY: RASTREAMENTO DE ENCOMENDA NO TOPO */}
          <div className="pb-1">
            <button
              onClick={() => {
                onNavigateTracking();
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-[#0B1E36] to-[#142f54] text-white rounded-2xl shadow-md border border-amber-500/30 group hover:border-amber-400 transition-all active:scale-[0.98] text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs group-hover:scale-105 transition-transform shrink-0">
                  <Truck className="w-5 h-5 text-slate-950" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black tracking-wide uppercase text-white group-hover:text-amber-300 transition-colors">
                      Rastreamento de Encomenda
                    </span>
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/40">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                      TEMPO REAL
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Localize o estafeta e o estado do seu pedido
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-amber-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Pesquisar produto em Luanda..."
              value={searchTerm}
              onChange={e => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
            />
          </div>

          <div className="space-y-1">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-2 py-1">Categorias</p>
            <button
              onClick={() => {
                onNavigateHome();
                onSelectCategory('all');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 text-sm rounded-lg ${
                selectedCategory === 'all' ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              Todos os Produtos
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  onNavigateHome();
                  onSelectCategory(cat.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-sm rounded-lg ${
                  selectedCategory === cat.id ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            {onOpenLegal && (
              <button
                onClick={() => {
                  onOpenLegal('terms');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-lg font-medium cursor-pointer"
              >
                Políticas, Termos & Garantia Oficial
              </button>
            )}
            <button
              onClick={() => {
                onOpenAdmin();
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2 text-sm text-amber-800 bg-amber-50 rounded-lg font-medium"
            >
              <span>Painel do Administrador</span>
              <Shield className="w-4 h-4 text-amber-600" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
