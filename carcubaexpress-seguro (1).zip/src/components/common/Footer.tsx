import React, { useState } from 'react';
import { MapPin, Phone, MessageCircle, Mail, ShieldCheck, Truck, Lock, FileText } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { LegalModal } from '../legal/LegalModal';

export const Footer: React.FC<{
  onOpenAdmin: () => void;
  onNavigateTracking: () => void;
  onOpenLegal?: (tab?: 'terms' | 'privacy' | 'shipping' | 'warranty') => void;
}> = ({
  onOpenAdmin,
  onNavigateTracking,
  onOpenLegal,
}) => {
  const currentYear = 2026;
  const { settings } = useCart();

  const phoneDisplay = settings?.supportPhone || '+244 951 556 411';
  const emailDisplay = settings?.email || 'carcubaexpresscomercio@gmail.com';
  const addressDisplay = settings?.address || 'Luanda, Angola (Entregas ao domicílio)';
  const whatsappNumber = (settings?.whatsappNumber || '244951556411').replace(/\D/g, '');

  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent('Olá CarcubaExpress! Gostaria de falar com o apoio ao cliente.')}`;

  const [legalModalTab, setLegalModalTab] = useState<'terms' | 'privacy' | 'shipping' | 'warranty' | null>(null);

  const handleOpenLegal = (tab: 'terms' | 'privacy' | 'shipping' | 'warranty') => {
    if (onOpenLegal) {
      onOpenLegal(tab);
    } else {
      setLegalModalTab(tab);
    }
  };

  const paymentTitle = settings?.paymentPolicyTitle || 'Formas de Pagamento (Apenas Dinheiro e Express)';
  const paymentText =
    settings?.paymentPolicyText ||
    'Garantimos total segurança na sua compra. O pagamento é realizado apenas no acto da entrega: aceitamos Dinheiro em mão ou transferência por Multicaixa Express na presença do estafeta após verificar e aprovar a sua encomenda.';

  const termsTitle = settings?.termsPolicyTitle || 'Termos e Condições de Compra';
  const termsText =
    settings?.termsPolicyText ||
    'Todos os produtos comercializados pela CarcubaExpress dispõem de garantia de conformidade. O cliente tem o direito e o dever de inspecionar o produto no momento da entrega antes de efetuar o pagamento. Caso o artigo apresente alguma anomalia, procedemos à troca imediata.';

  const departmentsList = settings?.footerDepartments || [
    'Eletrónicos & Som',
    'Perfumaria & Fragrâncias',
    'Moda Feminina & Vestuário',
    'Bolsas & Acessórios',
    'Beleza, Saúde & Cuidados',
    'Casa & Utilidades',
  ];

  return (
    <footer className="bg-[#0B1E36] text-white pt-16 pb-12 border-t border-[#173359]">
      {/* 3 Pillars of Trust */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-amber-400 shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-semibold text-white text-sm">Entregas Rápidas em Luanda</h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Entregamos em todos os municípios: Talatona, Kilamba, Maianga, Viana, Cazenga e arredores.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-amber-400 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-semibold text-white text-sm">Pagamento na Entrega</h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Total segurança: receba e verifique a sua encomenda e pague no acto da entrega (Apenas Dinheiro ou Multicaixa Express).
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-amber-400 shrink-0">
              <MessageCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-semibold text-white text-sm">Apoio via WhatsApp</h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Atendimento direto e reencaminhamento automático de todos os pedidos para o nosso WhatsApp comercial.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src="/assets/aistudio/logo_a1884a32.jpg"
                alt="Logótipo CarcubaExpress Comércio"
                className="w-12 h-12 object-contain rounded-full shadow-md border border-amber-400/50 bg-white p-0.5 shrink-0"
              />
              <div>
                <span className="text-xl font-extrabold tracking-tight text-white block leading-none">
                  Carcuba<span className="text-amber-400">Express</span>
                </span>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                  Comércio · Luanda
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
              {settings?.storeDescription ||
                'A sua loja online de referência em Luanda, Angola. Tecnologia, eletrónicos, microfones profissionais, perfumes árabes originais, moda feminina e artigos para o lar com entrega rápida.'}
            </p>
            <div className="pt-2 flex flex-col gap-2.5 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{addressDisplay}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a href={`tel:${phoneDisplay.replace(/\s+/g, '')}`} className="hover:text-amber-400 transition-colors">
                  {phoneDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <a href={`mailto:${emailDisplay}`} className="hover:text-amber-400 transition-colors">
                  {emailDisplay}
                </a>
              </div>
            </div>
          </div>

          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">Departamentos da Loja</h5>
            <ul className="space-y-2 text-xs text-slate-300">
              {departmentsList.map((dep, idx) => (
                <li key={idx} className="hover:text-amber-400 transition-colors cursor-default">
                  {dep}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">Políticas & Apoio Legal</h5>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>
                <button onClick={onNavigateTracking} className="hover:text-amber-400 transition-colors cursor-pointer text-left">
                  Acompanhar Meu Pedido
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenLegal('terms')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <span>Termos e Condições Gerais</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenLegal('privacy')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <span>Política de Privacidade (Lei 22/11)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenLegal('shipping')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <span>Entregas & Taxas em Luanda</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenLegal('warranty')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <span>Garantia de 7 Dias & Trocas</span>
                </button>
              </li>
              <li>
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors block pt-1">
                  Apoio via WhatsApp Oficial
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">Gestão do Sistema</h5>
            <p className="text-xs text-slate-400 mb-3">
              Acesso restrito ao painel de administração da CarcubaExpress.
            </p>
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold bg-white/10 hover:bg-amber-500 hover:text-slate-900 text-white rounded-lg transition-colors border border-white/10 cursor-pointer"
            >
              <span>Entrar no Painel Admin</span>
            </button>
          </div>
        </div>
      </div>

      {/* Official Legal Policies Modal */}
      <LegalModal
        isOpen={Boolean(legalModalTab)}
        onClose={() => setLegalModalTab(null)}
        initialTab={legalModalTab || 'terms'}
      />

      {/* Copyright */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
        <p>© {currentYear} CarcubaExpress Comércio. Todos os direitos reservados. Luanda, Angola.</p>
        <nav aria-label="Páginas legais públicas" className="flex items-center gap-3">
          <a href="/privacy-policy" className="hover:text-amber-400 transition-colors">
            Política de Privacidade
          </a>
          <span className="text-white/20" aria-hidden="true">·</span>
          <a href="/terms" className="hover:text-amber-400 transition-colors">
            Termos de Serviço
          </a>
        </nav>
        <p className="flex items-center gap-2">
          <span>Moeda Oficial:</span>
          <span className="font-semibold text-white">Kwanza Angolano (Kz)</span>
        </p>
      </div>
    </footer>
  );
};
