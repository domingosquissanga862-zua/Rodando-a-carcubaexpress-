import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { useCart } from '../../context/CartContext';

export const FloatingWhatsApp: React.FC = () => {
  const { settings } = useCart();
  const [showTooltip, setShowTooltip] = useState(true);

  const phone = settings?.whatsappNumber || '244951556411';
  const cleanPhone = phone.replace(/\D/g, '');
  const message = encodeURIComponent('Olá CarcubaExpress! Gostaria de obter informações sobre os produtos da loja.');
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${message}`;

  return (
    <div className="fixed bottom-5 right-5 sm:bottom-7 sm:right-7 z-40 flex flex-col items-end pointer-events-none select-none">
      {/* Speech bubble / tooltip */}
      {showTooltip && (
        <div className="pointer-events-auto mb-2 flex items-center gap-2 bg-white text-slate-800 text-xs px-3.5 py-2 rounded-2xl shadow-xl border border-slate-200/80 animate-bounce duration-1000 max-w-[220px]">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="font-medium hover:text-emerald-600 transition-colors cursor-pointer leading-tight"
          >
            Fale connosco no <strong className="text-emerald-600">WhatsApp</strong>
          </a>
          <button
            onClick={e => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="text-slate-400 hover:text-slate-600 ml-1 p-0.5"
            aria-label="Fechar dica"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Conversar no WhatsApp CarcubaExpress"
        className="pointer-events-auto relative group flex items-center justify-center w-14 h-14 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-full shadow-2xl transition-all duration-300 transform hover:scale-110 active:scale-95 cursor-pointer ring-4 ring-emerald-400/20"
      >
        {/* Subtle Pulse ring */}
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-25 pointer-events-none" />

        {/* WhatsApp Icon */}
        <svg
          className="w-7 h-7 fill-current transition-transform duration-300 group-hover:rotate-6"
          viewBox="0 0 24 24"
        >
          <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.996.586 3.864 1.6 5.438L2 22l4.675-1.554c1.52.937 3.3 1.485 5.356 1.485 5.536 0 10.031-4.495 10.031-10.031S17.567 2 12.031 2zm0 18.257c-1.848 0-3.567-.547-5.01-1.483l-.358-.231-3.15.826.84-3.072-.234-.372c-1.047-1.492-1.614-3.267-1.614-5.132 0-4.664 3.793-8.457 8.457-8.457 4.664 0 8.457 3.793 8.457 8.457 0 4.664-3.793 8.457-8.457 8.457zm4.646-6.335c-.255-.128-1.51-.745-1.745-.83-.234-.085-.404-.128-.574.128-.17.255-.659.83-.808.999-.15.17-.298.191-.553.064-.255-.128-1.077-.397-2.052-1.266-.758-.676-1.27-1.512-1.42-1.767-.149-.255-.016-.393.112-.521.115-.115.255-.298.383-.447.128-.149.17-.255.255-.425.085-.17.043-.319-.021-.447-.064-.128-.574-1.382-.787-1.892-.208-.498-.42-.43-.574-.438-.149-.008-.319-.008-.489-.008-.17 0-.447.064-.68.319-.234.255-.893.872-.893 2.126 0 1.254.914 2.466 1.042 2.636.128.17 1.8 2.748 4.36 3.854.61.263 1.085.42 1.456.538.612.195 1.168.167 1.608.101.491-.073 1.51-.617 1.723-1.212.213-.595.213-1.106.149-1.212-.064-.106-.234-.17-.489-.298z" />
        </svg>

        {/* Online Badge */}
        <span className="absolute -top-1 -left-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-600 text-[9px] font-bold text-white items-center justify-center">
            1
          </span>
        </span>
      </a>
    </div>
  );
};
