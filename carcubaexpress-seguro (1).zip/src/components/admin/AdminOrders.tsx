import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Eye,
  MessageCircle,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  Calendar,
  UserCheck,
  MapPin,
  RefreshCw,
  X,
  Phone,
  Save,
  Send,
  Check,
  FileText,
  Download,
  Trash2,
} from 'lucide-react';
import { api } from '../../services/api';
import type { Order, OrderStatus, PaymentStatus } from '../../types';
import { generateOrderInvoicePDF, openInvoiceWhatsApp } from '../../utils/pdfExport';
import { useCart } from '../../context/CartContext';
import { resolveProductImage, cleanAndNormalizeProductName } from '../../utils/productImages';

export const AdminOrders: React.FC = () => {
  const { settings } = useCart();
  const [orders, setOrders] = useState<Order[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [statusUpdateNote, setStatusUpdateNote] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState('');

  // Delete order modal and action state
  const [orderToDelete, setOrderToDelete] = useState<Order | null>(null);
  const [isDeletingOrder, setIsDeletingOrder] = useState(false);
  const [deleteFeedback, setDeleteFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Courier state for the active modal
  const [courierNameInput, setCourierNameInput] = useState('');
  const [courierPhoneInput, setCourierPhoneInput] = useState('');
  const [estimatedDateInput, setEstimatedDateInput] = useState('');

  const handleConfirmDeleteOrder = async (order: Order) => {
    setIsDeletingOrder(true);
    setDeleteFeedback(null);
    try {
      await api.deleteOrder(order.id || order.orderNumber);
      // Remove deleted order immediately from the UI state
      setOrders(prev => prev.filter(o => o.id !== order.id && o.orderNumber !== order.orderNumber));
      if (selectedOrder && (selectedOrder.id === order.id || selectedOrder.orderNumber === order.orderNumber)) {
        setSelectedOrder(null);
      }
      setOrderToDelete(null);
      setDeleteFeedback({
        type: 'success',
        message: `Pedido #${order.orderNumber} eliminado com sucesso da base de dados Supabase!`,
      });
      setTimeout(() => setDeleteFeedback(null), 5000);
    } catch (err: any) {
      console.error('Erro ao eliminar pedido:', err);
      setDeleteFeedback({
        type: 'error',
        message: err.message || 'Erro ao eliminar pedido. Por favor, tente novamente.',
      });
    } finally {
      setIsDeletingOrder(false);
    }
  };

  const loadOrders = async () => {
    setIsLoading(true);
    try {
      const res = await api.getOrders({
        status: statusFilter !== 'all' ? statusFilter : undefined,
        search: searchTerm.trim() || undefined,
      });
      setOrders(res.orders);
    } catch (err) {
      console.error('Erro ao carregar pedidos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [statusFilter]);

  useEffect(() => {
    if (selectedOrder) {
      setCourierNameInput(selectedOrder.courierName || selectedOrder.deliveryAgent || '');
      setCourierPhoneInput(selectedOrder.courierPhone || '');
      setEstimatedDateInput(selectedOrder.estimatedDeliveryDate || '');
      setActionSuccessMessage('');
      setStatusUpdateNote('');
    }
  }, [selectedOrder]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadOrders();
  };

  const handleUpdateStatusAndPayment = async (
    orderId: string,
    newStatus: OrderStatus,
    newPaymentStatus?: PaymentStatus
  ) => {
    setIsUpdating(true);
    setActionSuccessMessage('');
    try {
      const res = await api.updateOrderStatus(orderId, {
        status: newStatus,
        paymentStatus: newPaymentStatus,
        note: statusUpdateNote || undefined,
        courierName: courierNameInput.trim() || undefined,
        courierPhone: courierPhoneInput.trim() || undefined,
        deliveryAgent: courierNameInput.trim() || undefined,
        estimatedDeliveryDate: estimatedDateInput || undefined,
      });
      setSelectedOrder(prev => {
        if (!res.order) return prev;
        return {
          ...(prev || {}),
          ...res.order,
          items: Array.isArray(res.order.items) && res.order.items.length > 0 ? res.order.items : (prev?.items || []),
        } as Order;
      });
      setStatusUpdateNote('');
      setActionSuccessMessage(`Estado logístico atualizado para "${newStatus}" com sucesso!`);
      setTimeout(() => setActionSuccessMessage(''), 4500);
      loadOrders();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar estado');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeliverAndConfirmPayment = async (orderId: string) => {
    setIsUpdating(true);
    setActionSuccessMessage('');
    try {
      const res = await api.updateOrderStatus(orderId, {
        status: 'Entregue',
        paymentStatus: 'Confirmado',
        note: 'Pedido entregue com sucesso e pagamento confirmado pelo administrador.',
        courierName: courierNameInput.trim() || undefined,
        courierPhone: courierPhoneInput.trim() || undefined,
      });
      setSelectedOrder(prev => {
        if (!res.order) return prev;
        return {
          ...(prev || {}),
          ...res.order,
          items: Array.isArray(res.order.items) && res.order.items.length > 0 ? res.order.items : (prev?.items || []),
        } as Order;
      });
      setActionSuccessMessage('✅ Pedido marcado como ENTREGUE e PAGAMENTO CONFIRMADO!');
      setTimeout(() => setActionSuccessMessage(''), 5000);
      loadOrders();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar pedido');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleUpdatePayment = async (orderId: string, newPaymentStatus: PaymentStatus) => {
    setIsUpdating(true);
    try {
      const res = await api.updatePaymentStatus(orderId, { paymentStatus: newPaymentStatus });
      setSelectedOrder(prev => {
        if (!res.order) return prev;
        return {
          ...(prev || {}),
          ...res.order,
          items: Array.isArray(res.order.items) && res.order.items.length > 0 ? res.order.items : (prev?.items || []),
        } as Order;
      });
      setActionSuccessMessage(`Estado do pagamento atualizado para "${newPaymentStatus}"!`);
      setTimeout(() => setActionSuccessMessage(''), 4000);
      loadOrders();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar pagamento');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSaveCourier = async () => {
    if (!selectedOrder) return;
    setIsUpdating(true);
    setActionSuccessMessage('');
    try {
      const res = await api.updateDeliveryInfo(selectedOrder.id, {
        courierName: courierNameInput.trim(),
        courierPhone: courierPhoneInput.trim(),
        deliveryAgent: courierNameInput.trim(),
        estimatedDeliveryDate: estimatedDateInput,
        notes: selectedOrder.notes,
      });
      setSelectedOrder(prev => {
        if (!res.order) return prev;
        return {
          ...(prev || {}),
          ...res.order,
          items: Array.isArray(res.order.items) && res.order.items.length > 0 ? res.order.items : (prev?.items || []),
          courierName: courierNameInput.trim(),
          courierPhone: courierPhoneInput.trim(),
          deliveryAgent: courierNameInput.trim(),
          estimatedDeliveryDate: estimatedDateInput,
        } as Order;
      });
      setActionSuccessMessage('Dados do estafeta guardados com sucesso!');
      setTimeout(() => setActionSuccessMessage(''), 4000);
      loadOrders();
    } catch (err: any) {
      alert(err.message || 'Erro ao guardar dados do estafeta');
    } finally {
      setIsUpdating(false);
    }
  };

  const statusList: { id: string; label: string }[] = [
    { id: 'all', label: 'Todos os Pedidos' },
    { id: 'Pendente', label: 'Pendentes' },
    { id: 'Em preparação', label: 'Em Preparação' },
    { id: 'Em transporte', label: 'Em Transporte' },
    { id: 'Entregue', label: 'Entregues' },
    { id: 'A aguardar pagamento', label: 'Aguardando Pagamento' },
    { id: 'Pagamento confirmado', label: 'Pagamento Confirmado' },
    { id: 'Cancelado', label: 'Cancelados' },
  ];

  // Helper to format WhatsApp instruction text for the courier
  const getDriverWhatsAppMessage = (order: Order) => {
    if (!order) return '';
    const safeItems = Array.isArray(order.items) ? order.items : [];
    const itemsList =
      safeItems.length > 0
        ? safeItems.map(i => `${i.quantity || 1}x ${i.productName || 'Artigo'}`).join(', ')
        : 'Artigos da Encomenda';
    const totalVal = Number(order.total || 0);

    const text =
      `*INSTRUÇÕES DE ENTREGA — CARCUBAEXPRESS* 📦\n\n` +
      `*Estafeta:* ${courierNameInput || 'Estafeta Designado'}\n` +
      `*Pedido:* ${order.orderNumber || ''}\n` +
      `*Cliente:* ${order.customerName || 'Cliente'}\n` +
      `*Telefone do Cliente:* ${order.customerPhone || ''}\n` +
      `*Município:* ${order.deliveryMunicipality || 'Luanda'}\n` +
      `*Endereço de Entrega:* ${order.deliveryAddress || ''}\n` +
      (order.deliveryReference ? `*Ponto de Referência:* ${order.deliveryReference}\n` : '') +
      `*Artigos:* ${itemsList}\n` +
      `*Total a Cobrar no Acto:* ${totalVal.toLocaleString('pt-AO')} Kz\n` +
      `*Forma de Pagamento:* ${order.paymentMethod || 'No acto da entrega'}\n` +
      (estimatedDateInput ? `*Data de Entrega:* ${estimatedDateInput}\n` : '');
    return encodeURIComponent(text);
  };

  // Helper to format WhatsApp notification text for the customer
  const getCustomerNotificationMessage = (order: Order) => {
    if (!order) return '';
    const totalVal = Number(order.total || 0);
    const text =
      `Olá ${order.customerName || 'Cliente'}! 🚚\n\n` +
      `Informamos que a sua encomenda *${order.orderNumber || ''}* da CarcubaExpress está no estado: *${order.status || 'Pendente'}*.\n` +
      (courierNameInput ? `\n*Estafeta Responsável:* ${courierNameInput}\n` : '') +
      (courierPhoneInput ? `*Contacto do Estafeta:* ${courierPhoneInput}\n` : '') +
      `\n*Local de Entrega:* ${order.deliveryMunicipality || 'Luanda'} - ${order.deliveryAddress || ''}\n` +
      `*Total a Pagar:* ${totalVal.toLocaleString('pt-AO')} Kz (${order.paymentMethod || 'No acto da entrega'})\n\n` +
      `Agradecemos a sua preferência pela CarcubaExpress Comércio!`;
    return encodeURIComponent(text);
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Gestão de Pedidos dos Clientes</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Atualize o estado (Pendente, Preparação, Transporte, Entregue), atribua estafetas e valide pagamentos em Luanda
          </p>
        </div>

        <div className="flex items-center gap-2">
          <form onSubmit={handleSearch} className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Pesquisar pedido, cliente, telefone..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl w-64 text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </form>

          <button
            onClick={loadOrders}
            className="p-2 bg-white text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl transition-colors cursor-pointer"
            title="Atualizar lista"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {deleteFeedback && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between gap-2.5 animate-fade-in shadow-xs ${
            deleteFeedback.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {deleteFeedback.type === 'success' ? (
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span className="font-semibold">{deleteFeedback.message}</span>
          </div>
          <button
            onClick={() => setDeleteFeedback(null)}
            className="p-1 hover:bg-black/5 rounded-lg text-slate-500 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Status Segmented Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-200">
        {statusList.map(item => (
          <button
            key={item.id}
            onClick={() => setStatusFilter(item.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === item.id
                ? 'bg-[#0B1E36] text-white shadow-sm'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Orders Table */}
      {isLoading ? (
        <div className="p-12 text-center text-xs text-slate-400">A carregar pedidos dos clientes...</div>
      ) : orders.length === 0 ? (
        <div className="p-12 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200">
          Nenhum pedido encontrado para o filtro selecionado.
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/50">
                  <th className="py-3.5 px-4">Nº Pedido</th>
                  <th className="py-3.5 px-4">Data</th>
                  <th className="py-3.5 px-4">Cliente & Contacto</th>
                  <th className="py-3.5 px-4">Município</th>
                  <th className="py-3.5 px-4">Estafeta Designado</th>
                  <th className="py-3.5 px-4 text-right">Total</th>
                  <th className="py-3.5 px-4">Pagamento</th>
                  <th className="py-3.5 px-4">Estado</th>
                  <th className="py-3.5 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      {order.orderNumber}
                    </td>

                    <td className="py-3.5 px-4 text-slate-500 whitespace-nowrap">
                      {new Date(order.createdAt).toLocaleDateString('pt-PT')}
                      <span className="block text-[10px] text-slate-400">
                        {new Date(order.createdAt).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-semibold text-slate-900">{order.customerName}</p>
                      <p className="text-[11px] text-slate-500 font-mono">{order.customerPhone}</p>
                    </td>

                    <td className="py-3.5 px-4 text-slate-700">
                      {order.deliveryMunicipality}
                    </td>

                    <td className="py-3.5 px-4">
                      {order.courierName || order.deliveryAgent ? (
                        <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                          <Truck className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <div>
                            <p className="font-semibold">{order.courierName || order.deliveryAgent}</p>
                            {order.courierPhone && (
                              <p className="text-[10px] text-slate-500 font-mono">{order.courierPhone}</p>
                            )}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic text-[11px]">Não atribuído</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-[#0B1E36] tabular-nums whitespace-nowrap">
                      {order.total.toLocaleString('pt-AO')} Kz
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-semibold ${
                          order.paymentStatus === 'Confirmado'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {order.paymentStatus}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold ${
                          order.status === 'Entregue'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.status === 'Cancelado'
                            ? 'bg-rose-100 text-rose-800'
                            : order.status === 'Em transporte'
                            ? 'bg-blue-100 text-blue-800'
                            : order.status === 'Em preparação'
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="px-2.5 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors flex items-center gap-1 font-semibold cursor-pointer"
                          title="Gerir Pedido e Estafeta"
                        >
                          <Eye className="w-3.5 h-3.5 text-slate-500" />
                          <span>Gerir</span>
                        </button>

                        <button
                          onClick={() => generateOrderInvoicePDF(order, settings)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 border border-blue-200 rounded-lg transition-colors cursor-pointer"
                          title="Descarregar Fatura / Recibo (PDF)"
                        >
                          <FileText className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => openInvoiceWhatsApp(order, settings)}
                          className="p-1.5 text-emerald-700 hover:bg-emerald-50 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
                          title="Enviar Fatura / Recibo no WhatsApp"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>

                        <a
                          href={`https://wa.me/${order.customerPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                            `Olá ${order.customerName}! Entramos em contacto da loja CarcubaExpress a respeito da sua encomenda *${order.orderNumber}*.`
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          title="Falar com o Cliente no WhatsApp"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </a>

                        <button
                          onClick={() => setOrderToDelete(order)}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors cursor-pointer"
                          title="Eliminar Pedido"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Order Management Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div
            className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8 animate-fade-in"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-6 bg-[#0B1E36] text-white flex items-center justify-between">
              <div>
                <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                  Gestão & Expedição de Pedido
                </span>
                <h3 className="text-lg font-bold font-mono mt-0.5">
                  {selectedOrder.orderNumber} · {selectedOrder.customerName}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                aria-label="Fechar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 text-xs max-h-[80vh] overflow-y-auto">
              {/* Feedback Success Message */}
              {actionSuccessMessage && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-center gap-2 animate-fade-in font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{actionSuccessMessage}</span>
                </div>
              )}

              {/* SECTION 1: Status & Payment Controls */}
              <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span>Atualização de Estados (Pedido & Pagamento)</span>
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 font-medium">Estado atual:</span>
                    <span className="font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300">
                      {selectedOrder.status}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Alterar Estado do Pedido:
                    </label>
                    <select
                      value={selectedOrder.status}
                      onChange={e => handleUpdateStatusAndPayment(selectedOrder.id, e.target.value as OrderStatus)}
                      disabled={isUpdating}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    >
                      <option value="Pendente">⏳ 1. Pendente (Recebido)</option>
                      <option value="Em preparação">📦 2. Em preparação (A embalar)</option>
                      <option value="Em transporte">🏍️ 3. Em transporte (Com o estafeta)</option>
                      <option value="Entregue">✅ 4. Entregue (Chegou ao cliente)</option>
                      <option value="Cancelado">❌ Cancelado</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Estado do Pagamento (Independente):
                    </label>
                    <select
                      value={selectedOrder.paymentStatus}
                      onChange={e => handleUpdatePayment(selectedOrder.id, e.target.value as PaymentStatus)}
                      disabled={isUpdating}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    >
                      <option value="No acto da entrega">No acto da entrega (Pendente)</option>
                      <option value="Pendente">Pendente</option>
                      <option value="Confirmado">✅ Confirmado (Recebido)</option>
                      <option value="Cancelado">Cancelado</option>
                      <option value="Reembolsado">Reembolsado</option>
                    </select>
                  </div>
                </div>

                {/* Quick 1-Click Status Buttons */}
                <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-500 w-full sm:w-auto">
                    Ações Rápidas:
                  </span>

                  {selectedOrder.paymentStatus !== 'Confirmado' && (
                    <button
                      onClick={() => handleUpdatePayment(selectedOrder.id, 'Confirmado')}
                      disabled={isUpdating}
                      className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirmar Pagamento Recebido</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleUpdateStatusAndPayment(selectedOrder.id, 'Entregue')}
                    disabled={isUpdating}
                    className="py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold rounded-xl text-xs cursor-pointer active:scale-95 flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Marcar como Entregue</span>
                  </button>

                  <button
                    onClick={() => handleUpdateStatusAndPayment(selectedOrder.id, 'Em transporte')}
                    disabled={isUpdating}
                    className="py-2 px-3 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 font-semibold rounded-xl text-xs cursor-pointer active:scale-95 flex items-center gap-1"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Colocar Em Transporte</span>
                  </button>

                  <button
                    onClick={() => handleUpdateStatusAndPayment(selectedOrder.id, 'Em preparação')}
                    disabled={isUpdating}
                    className="py-2 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-300 font-semibold rounded-xl text-xs cursor-pointer active:scale-95"
                  >
                    Colocar Em Preparação
                  </button>
                </div>
              </div>

              {/* SECTION 2: Courier (Estafeta) Assignment & Dispatch */}
              <div className="p-5 bg-amber-50/70 rounded-2xl border border-amber-200 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-amber-600" />
                    <span>Atribuição de Estafeta & Contactos de Entrega</span>
                  </h4>
                  {(selectedOrder.courierName || selectedOrder.deliveryAgent) && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600" />
                      Estafeta Atribuído
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                      Nome do Estafeta:
                    </label>
                    <div className="relative">
                      <UserCheck className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        placeholder="ex: Paulo Kiala (Mota 1)"
                        value={courierNameInput}
                        onChange={e => setCourierNameInput(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                      Telefone do Estafeta (Angola):
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="tel"
                        placeholder="ex: +244 923 112 233"
                        value={courierPhoneInput}
                        onChange={e => setCourierPhoneInput(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                        Data Prevista de Entrega:
                      </label>
                      <input
                        type="date"
                        value={estimatedDateInput}
                        onChange={e => setEstimatedDateInput(e.target.value)}
                        className="p-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={handleSaveCourier}
                      disabled={isUpdating}
                      className="py-2.5 px-5 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer active:scale-95 self-end sm:self-auto"
                    >
                      <Save className="w-3.5 h-3.5 text-amber-400" />
                      <span>{isUpdating ? 'A guardar...' : 'Guardar Dados do Estafeta'}</span>
                    </button>
                  </div>
                </div>

                {/* Dispatch WhatsApp Actions */}
                <div className="pt-3 border-t border-amber-200/60 flex flex-wrap items-center gap-2">
                  <a
                    href={`https://wa.me/${(courierPhoneInput || '').replace(/\D/g, '')}?text=${getDriverWhatsAppMessage(selectedOrder)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs"
                    title="Abre o WhatsApp com a rota e morada completa para o estafeta"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Enviar Rota ao Estafeta (WhatsApp)</span>
                  </a>

                  <a
                    href={`https://wa.me/${(selectedOrder.customerPhone || '').replace(/\D/g, '')}?text=${getCustomerNotificationMessage(selectedOrder)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2 px-3.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs"
                    title="Avisa o cliente que o pedido está com o estafeta com o nome e contacto dele"
                  >
                    <Send className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Notificar Cliente no WhatsApp</span>
                  </a>

                  {courierPhoneInput && (
                    <a
                      href={`tel:${courierPhoneInput.replace(/\s+/g, '')}`}
                      className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs flex items-center gap-1 transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5 text-slate-500" />
                      <span>Ligar ao Estafeta</span>
                    </a>
                  )}
                </div>
              </div>

              {/* SECTION 3: Purchased Products */}
              <div>
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                  Produtos da Encomenda
                </h4>
                <div className="space-y-2">
                  {Array.isArray(selectedOrder.items) && selectedOrder.items.length > 0 ? (
                    selectedOrder.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={resolveProductImage({ ...item, productName: cleanAndNormalizeProductName(item.productName, item.productId) })}
                            alt={cleanAndNormalizeProductName(item.productName, item.productId)}
                            referrerPolicy="no-referrer"
                            className="w-12 h-12 object-cover rounded-xl bg-white shrink-0 border border-slate-200 shadow-xs"
                          />
                          <div>
                            <p className="font-bold text-slate-900">{cleanAndNormalizeProductName(item.productName, item.productId)}</p>
                            <p className="text-slate-500 font-mono text-[11px]">
                              {item.quantity}x @ {(Number(item.price) || 0).toLocaleString('pt-AO')} Kz
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-[#0B1E36] font-mono tabular-nums text-sm">
                          {((Number(item.price) || 0) * (Number(item.quantity) || 1)).toLocaleString('pt-AO')} Kz
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs italic">
                      Nenhum artigo discriminado nesta encomenda.
                    </div>
                  )}
                </div>
              </div>

              {/* SECTION 4: Customer Details & Financials */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                <div className="space-y-1.5">
                  <p className="font-bold text-slate-700">Morada de Entrega em Luanda:</p>
                  <p className="text-slate-900 font-semibold text-sm">{selectedOrder.deliveryMunicipality}</p>
                  <p className="text-slate-700">{selectedOrder.deliveryAddress}</p>
                  {selectedOrder.deliveryReference && (
                    <p className="text-slate-500 italic">Ponto de Ref: {selectedOrder.deliveryReference}</p>
                  )}
                  <div className="pt-1.5">
                    <span className="text-[11px] font-semibold text-slate-500 block">Forma de Pagamento:</span>
                    <span className="inline-block px-2.5 py-1 mt-0.5 rounded-lg text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
                      {selectedOrder.paymentMethod}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="font-bold text-slate-800">Resumo Financeiro:</p>
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span className="font-mono font-semibold">{selectedOrder.subtotal.toLocaleString('pt-AO')} Kz</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Taxa de Entrega:</span>
                    <span className="font-mono font-semibold">{selectedOrder.shippingFee.toLocaleString('pt-AO')} Kz</span>
                  </div>
                  <div className="flex justify-between font-bold text-sm text-[#0B1E36] pt-2 border-t border-slate-200">
                    <span>Total a Cobrar:</span>
                    <span className="text-amber-600 font-mono text-base">{selectedOrder.total.toLocaleString('pt-AO')} Kz</span>
                  </div>
                </div>
              </div>

              {/* SECTION: Fatura / Recibo de Venda Oficial */}
              <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-amber-500 text-white rounded-xl shadow-xs">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Fatura / Recibo de Venda (FR-{selectedOrder.orderNumber})</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Gere a fatura/recibo oficial para imprimir ou enviar directamente ao cliente via WhatsApp após entrega e pagamento.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => generateOrderInvoicePDF(selectedOrder, settings)}
                    className="px-3.5 py-2 bg-white hover:bg-slate-50 text-[#0B1E36] font-bold rounded-xl border border-slate-300 text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-600" />
                    <span>PDF</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => openInvoiceWhatsApp(selectedOrder, settings)}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Enviar no WhatsApp</span>
                  </button>
                </div>
              </div>

              {/* SECTION 5: Status History */}
              {selectedOrder.statusHistory && selectedOrder.statusHistory.length > 0 && (
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  <p className="font-bold text-slate-700">Histórico de Alterações:</p>
                  <div className="space-y-1.5 text-[11px] text-slate-500">
                    {selectedOrder.statusHistory.map((hist, i) => (
                      <div key={i} className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                        <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-bold text-slate-800">{hist.status}</span>
                        <span>·</span>
                        <span>
                          por{' '}
                          {hist.changedBy?.includes('@') ||
                          hist.changedBy?.toLowerCase().includes('domingos') ||
                          hist.changedBy?.toLowerCase().includes('quissanga')
                            ? 'Equipa CarcubaExpress'
                            : hist.changedBy}
                        </span>
                        {hist.note && <span className="italic text-slate-600 ml-auto font-medium">"{hist.note}"</span>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => generateOrderInvoicePDF(selectedOrder, settings)}
                  className="px-3.5 py-2 bg-white hover:bg-slate-100 text-[#0B1E36] font-bold rounded-xl border border-slate-300 text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                  title="Descarregar Fatura / Recibo PDF"
                >
                  <Download className="w-3.5 h-3.5 text-blue-600" />
                  <span>Descarregar Fatura / Recibo (PDF)</span>
                </button>

                <button
                  type="button"
                  onClick={() => openInvoiceWhatsApp(selectedOrder, settings)}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                  title="Enviar Fatura / Recibo ao Cliente no WhatsApp"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Enviar Recibo WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={() => setOrderToDelete(selectedOrder)}
                  className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold border border-rose-200 rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Eliminar este pedido permanentemente"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Eliminar Pedido</span>
                </button>
              </div>

              <button
                onClick={() => setSelectedOrder(null)}
                className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold text-xs transition-colors cursor-pointer"
              >
                Concluir & Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Order Confirmation Modal */}
      {orderToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-rose-100 text-rose-600 rounded-2xl shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900">
                  Eliminar Pedido #{orderToDelete.orderNumber}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Cliente: <span className="font-semibold text-slate-800">{orderToDelete.customerName}</span> ({orderToDelete.deliveryMunicipality})
                </p>
                <p className="text-xs font-mono font-bold text-[#0B1E36] mt-0.5">
                  Total: {orderToDelete.total.toLocaleString('pt-AO')} Kz
                </p>
              </div>
              <button
                onClick={() => { if (!isDeletingOrder) setOrderToDelete(null); }}
                disabled={isDeletingOrder}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer disabled:opacity-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 font-medium leading-relaxed">
              Tem a certeza de que deseja eliminar este pedido? Esta ação não poderá ser desfeita.
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isDeletingOrder}
                onClick={() => setOrderToDelete(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={isDeletingOrder}
                onClick={() => handleConfirmDeleteOrder(orderToDelete)}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-md shadow-rose-600/20 transition-all cursor-pointer flex items-center gap-2 active:scale-95 disabled:opacity-50"
              >
                {isDeletingOrder ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>A eliminar...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirmar eliminação</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
