import React, { useState, useEffect } from 'react';
import {
  Truck,
  MapPin,
  Calendar,
  UserCheck,
  Phone,
  MessageCircle,
  Clock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Search,
  Save,
  Send,
  FileText,
  Download,
} from 'lucide-react';
import { api } from '../../services/api';
import type { Order, OrderStatus } from '../../types';
import { generateOrderInvoicePDF, openInvoiceWhatsApp } from '../../utils/pdfExport';
import { useCart } from '../../context/CartContext';

export const AdminDeliveries: React.FC = () => {
  const { settings } = useCart();
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedMunicipality, setSelectedMunicipality] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isUpdatingId, setIsUpdatingId] = useState<string | null>(null);

  // Local state for each card's courier inputs
  const [courierInputs, setCourierInputs] = useState<Record<string, { name: string; phone: string; date: string }>>({});

  const loadDeliveries = async () => {
    setIsLoading(true);
    try {
      const res = await api.getOrders();
      setOrders(res.orders);

      // Populate input states
      const inputs: Record<string, { name: string; phone: string; date: string }> = {};
      res.orders.forEach(o => {
        inputs[o.id] = {
          name: o.courierName || o.deliveryAgent || '',
          phone: o.courierPhone || '',
          date: o.estimatedDeliveryDate || '',
        };
      });
      setCourierInputs(inputs);
    } catch (err) {
      console.error('Erro ao carregar entregas:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDeliveries();
  }, []);

  const handleUpdateCourier = async (orderId: string) => {
    const input = courierInputs[orderId];
    if (!input) return;

    setIsUpdatingId(orderId);
    try {
      await api.updateDeliveryInfo(orderId, {
        courierName: input.name.trim(),
        courierPhone: input.phone.trim(),
        deliveryAgent: input.name.trim(),
        estimatedDeliveryDate: input.date,
      });
      loadDeliveries();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar dados do estafeta');
    } finally {
      setIsUpdatingId(null);
    }
  };

  const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
    setIsUpdatingId(orderId);
    const input = courierInputs[orderId];
    try {
      await api.updateOrderStatus(orderId, {
        status,
        paymentStatus: status === 'Entregue' ? 'Confirmado' : undefined,
        courierName: input?.name ? input.name.trim() : undefined,
        courierPhone: input?.phone ? input.phone.trim() : undefined,
      });
      loadDeliveries();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar estado');
    } finally {
      setIsUpdatingId(null);
    }
  };

  // Filter deliveries
  const filtered = orders.filter(o => {
    const matchesMuni =
      selectedMunicipality === 'all' ||
      o.deliveryMunicipality.toLowerCase().includes(selectedMunicipality.toLowerCase());
    const matchesStatus = statusFilter === 'all' || o.status === statusFilter;
    const term = searchTerm.toLowerCase().trim();
    const matchesSearch =
      !term ||
      o.orderNumber.toLowerCase().includes(term) ||
      o.customerName.toLowerCase().includes(term) ||
      o.customerPhone.includes(term) ||
      (o.courierName && o.courierName.toLowerCase().includes(term)) ||
      o.deliveryAddress.toLowerCase().includes(term);
    return matchesMuni && matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Módulo de Gestão de Entregas em Luanda</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Coordenação de estafetas (Nome e Telefone), rotas por município e acompanhamento logístico
          </p>
        </div>

        <button
          onClick={loadDeliveries}
          className="p-2 bg-white text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl self-start transition-colors cursor-pointer"
          title="Atualizar entregas"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Filters Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div>
          <label className="block text-slate-600 font-semibold mb-1">Pesquisar:</label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Nº Pedido, cliente, estafeta ou morada..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-amber-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-slate-600 font-semibold mb-1">Município de Luanda:</label>
          <select
            value={selectedMunicipality}
            onChange={e => setSelectedMunicipality(e.target.value)}
            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
          >
            <option value="all">Todos os Municípios</option>
            <option value="Luanda">Luanda (Ingombota, Maianga, etc.)</option>
            <option value="Talatona">Talatona (Benfica, Morro Bento)</option>
            <option value="Belas">Belas (Kilamba)</option>
            <option value="Kilamba Kiaxi">Kilamba Kiaxi (Golf, Palanca)</option>
            <option value="Viana">Viana (Zango, Estalagem)</option>
            <option value="Cazenga">Cazenga</option>
            <option value="Cacuaco">Cacuaco</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-600 font-semibold mb-1">Estado do Envio:</label>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
          >
            <option value="all">Todos os Estados</option>
            <option value="Pendente">Pendentes</option>
            <option value="Em preparação">Em Preparação</option>
            <option value="Em transporte">Em Transporte (Na Rua)</option>
            <option value="Entregue">Entregues com Sucesso</option>
            <option value="Cancelado">Cancelados</option>
          </select>
        </div>
      </div>

      {/* Deliveries Cards Grid */}
      {filtered.length === 0 ? (
        <div className="p-12 text-center text-slate-400 text-xs bg-white rounded-2xl border border-slate-200">
          Nenhuma entrega corresponde aos filtros selecionados.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(order => {
            const currentInput = courierInputs[order.id] || {
              name: order.courierName || order.deliveryAgent || '',
              phone: order.courierPhone || '',
              date: order.estimatedDeliveryDate || '',
            };

            const driverMsg = encodeURIComponent(
              `*INSTRUÇÕES DE ENTREGA — CARCUBAEXPRESS* 📦\n\n` +
              `*Estafeta:* ${currentInput.name || 'Estafeta Designado'}\n` +
              `*Pedido:* ${order.orderNumber}\n` +
              `*Cliente:* ${order.customerName}\n` +
              `*Telefone:* ${order.customerPhone}\n` +
              `*Município:* ${order.deliveryMunicipality}\n` +
              `*Endereço:* ${order.deliveryAddress}\n` +
              (order.deliveryReference ? `*Ref:* ${order.deliveryReference}\n` : '') +
              `*Artigos:* ${(Array.isArray(order.items) ? order.items : []).map(i => `${i.quantity || 1}x ${i.productName || 'Artigo'}`).join(', ')}\n` +
              `*Total a cobrar:* ${Number(order.total || 0).toLocaleString('pt-AO')} Kz (${order.paymentMethod || 'No acto da entrega'})\n` +
              (currentInput.date ? `*Data de Entrega:* ${currentInput.date}\n` : '')
            );

            const isUpdating = isUpdatingId === order.id;

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4 text-xs flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Card Header */}
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                      {order.orderNumber}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        order.status === 'Entregue'
                          ? 'bg-emerald-100 text-emerald-800'
                          : order.status === 'Em transporte'
                          ? 'bg-blue-100 text-blue-800'
                          : order.status === 'Em preparação'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {order.status}
                    </span>
                  </div>

                  {/* Customer details */}
                  <div>
                    <p className="font-bold text-slate-900 text-sm">{order.customerName}</p>
                    <a
                      href={`tel:${order.customerPhone}`}
                      className="text-slate-500 hover:text-amber-600 flex items-center gap-1 font-mono mt-0.5"
                    >
                      <Phone className="w-3 h-3" />
                      <span>{order.customerPhone}</span>
                    </a>
                  </div>

                  {/* Address */}
                  <div className="p-2.5 bg-slate-50 rounded-xl space-y-1">
                    <div className="flex items-start gap-1.5 text-slate-800 font-semibold">
                      <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span>{order.deliveryMunicipality}</span>
                    </div>
                    <p className="text-slate-600 pl-5">{order.deliveryAddress}</p>
                    {order.deliveryReference && (
                      <p className="text-[11px] text-slate-400 pl-5 italic">
                        Ref: {order.deliveryReference}
                      </p>
                    )}
                  </div>

                  {/* Total to collect */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-slate-500">Cobrança no Acto:</span>
                    <span className="font-mono font-bold text-[#0B1E36] text-sm tabular-nums">
                      {order.total.toLocaleString('pt-AO')} Kz
                    </span>
                  </div>

                  {/* Estafeta Input: Nome e Telefone */}
                  <div className="space-y-2 pt-3 border-t border-slate-100 bg-amber-50/50 p-3 rounded-xl border border-amber-200/60">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                        <Truck className="w-3.5 h-3.5 text-amber-600" />
                        <span>Dados do Estafeta:</span>
                      </span>
                      <button
                        onClick={() => handleUpdateCourier(order.id)}
                        disabled={isUpdating}
                        className="text-[10px] bg-slate-900 hover:bg-slate-800 text-white font-bold px-2 py-0.5 rounded flex items-center gap-1 cursor-pointer"
                      >
                        <Save className="w-2.5 h-2.5 text-amber-400" />
                        <span>Guardar</span>
                      </button>
                    </div>

                    <div>
                      <input
                        type="text"
                        placeholder="Nome do estafeta (ex: Paulo)..."
                        value={currentInput.name}
                        onChange={e =>
                          setCourierInputs(prev => ({
                            ...prev,
                            [order.id]: { ...currentInput, name: e.target.value },
                          }))
                        }
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900"
                      />
                    </div>

                    <div>
                      <input
                        type="tel"
                        placeholder="Telefone do estafeta (+244)..."
                        value={currentInput.phone}
                        onChange={e =>
                          setCourierInputs(prev => ({
                            ...prev,
                            [order.id]: { ...currentInput, phone: e.target.value },
                          }))
                        }
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-900"
                      />
                    </div>
                  </div>
                </div>

                {/* Status Transitions & Fast WhatsApp Dispatch */}
                <div className="space-y-2 pt-3 border-t border-slate-100">
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'Em preparação')}
                      disabled={isUpdating}
                      className={`py-1.5 px-1.5 rounded-lg font-semibold text-[10px] border text-center transition-colors cursor-pointer ${
                        order.status === 'Em preparação'
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100'
                      }`}
                    >
                      Em Preparação
                    </button>

                    <button
                      onClick={() => handleUpdateStatus(order.id, 'Em transporte')}
                      disabled={isUpdating}
                      className={`py-1.5 px-1.5 rounded-lg font-semibold text-[10px] border text-center transition-colors cursor-pointer ${
                        order.status === 'Em transporte'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'
                      }`}
                    >
                      Em Transporte
                    </button>

                    <button
                      onClick={() => handleUpdateStatus(order.id, 'Entregue')}
                      disabled={isUpdating}
                      className={`py-1.5 px-1.5 rounded-lg font-bold text-[10px] border text-center transition-colors cursor-pointer ${
                        order.status === 'Entregue'
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      Entregue & Pago
                    </button>
                  </div>

                  <a
                    href={`https://wa.me/${(currentInput.phone || '').replace(/\D/g, '')}?text=${driverMsg}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-[11px] flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Enviar Rota ao Estafeta (WhatsApp)</span>
                  </a>

                  {/* Fatura / Recibo Actions */}
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => generateOrderInvoicePDF(order, settings)}
                      className="py-1.5 px-2 bg-white hover:bg-slate-100 text-[#0B1E36] font-bold rounded-lg text-[10px] border border-slate-200 flex items-center justify-center gap-1 shadow-xs cursor-pointer transition-colors"
                      title="Descarregar Fatura / Recibo PDF"
                    >
                      <Download className="w-3 h-3 text-blue-600" />
                      <span>Fatura / Recibo</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => openInvoiceWhatsApp(order, settings)}
                      className="py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold rounded-lg text-[10px] border border-emerald-200 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Enviar Recibo ao Cliente no WhatsApp"
                    >
                      <Send className="w-3 h-3 text-emerald-600" />
                      <span>Recibo Cliente</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
