import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertCircle, RefreshCw, Copy, Check, ExternalLink, ShieldCheck, Code2 } from 'lucide-react';
import { api } from '../../services/api';

export const AdminSupabaseCard: React.FC = () => {
  const [status, setStatus] = useState<{
    connected: boolean;
    projectUrl: string;
    productsCount: number;
    ordersCount: number;
    error?: string;
    checkedAt: string;
  } | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showSql, setShowSql] = useState(false);
  const [sqlScript, setSqlScript] = useState('');

  const checkStatus = async () => {
    setIsLoading(true);
    try {
      const res = await api.getSupabaseStatus();
      setStatus(res);
      const sqlRes = await api.getSupabaseSqlSetup();
      setSqlScript(sqlRes.sqlScript);
    } catch (err: any) {
      console.error('Erro ao verificar Supabase:', err);
      setStatus({
        connected: false,
        projectUrl: 'https://jglvxsvhumrbypmgooic.supabase.co',
        productsCount: 0,
        ordersCount: 0,
        error: err.message || 'Falha de ligação',
        checkedAt: new Date().toISOString(),
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkStatus();
  }, []);

  const handleCopySql = () => {
    if (!sqlScript) return;
    navigator.clipboard.writeText(sqlScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-500/20">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 text-sm">Integração Supabase Cloud</h3>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Ativo & Conectado
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Base de dados PostgreSQL na nuvem sincronizada em tempo real com a CarcubaExpress
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={checkStatus}
          disabled={isLoading}
          className="self-start sm:self-auto py-2 px-3.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>{isLoading ? 'A verificar...' : 'Testar Ligação'}</span>
        </button>
      </div>

      {/* Grid of details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
          <span className="text-[11px] font-medium text-slate-500">Project Endpoint URL:</span>
          <p className="text-xs font-mono font-bold text-slate-800 truncate" title={status?.projectUrl}>
            {status?.projectUrl || 'https://jglvxsvhumrbypmgooic.supabase.co'}
          </p>
          <span className="text-[10px] text-slate-400 block">Autenticação: Anon Key configurada</span>
        </div>

        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
          <span className="text-[11px] font-medium text-slate-500">Tabela de Produtos (public.products):</span>
          <div className="flex items-center gap-1.5">
            <span className="text-base font-black font-mono text-emerald-700">
              {status?.productsCount ?? 3}
            </span>
            <span className="text-xs text-slate-600 font-semibold">artigos sincronizados</span>
          </div>
          <span className="text-[10px] text-emerald-600 block font-medium">Asad Lattafa e Microfones disponíveis</span>
        </div>

        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
          <span className="text-[11px] font-medium text-slate-500">Tabela de Pedidos (public.orders):</span>
          <div className="flex items-center gap-1.5">
            <span className="text-base font-black font-mono text-amber-700">
              {status?.ordersCount ?? 0}
            </span>
            <span className="text-xs text-slate-600 font-semibold">pedidos registados</span>
          </div>
          <span className="text-[10px] text-slate-400 block">Sincronização automática em cada checkout</span>
        </div>
      </div>

      {/* Info Notice */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3 text-xs text-slate-700">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-slate-900">
            Sincronização Híbrida Inteligente Ativada
          </p>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            Sempre que um cliente faz uma encomenda no website da CarcubaExpress, o pedido é salvo com segurança na base da loja e uma cópia é automaticamente enviada para a tabela <code className="bg-white px-1 py-0.5 rounded border text-slate-800 font-mono">orders</code> e <code className="bg-white px-1 py-0.5 rounded border text-slate-800 font-mono">order_items</code> do seu Supabase.
          </p>
        </div>
      </div>

      {/* Collapsible SQL Script Button */}
      <div className="pt-1">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setShowSql(!showSql)}
            className="text-xs text-amber-700 hover:text-amber-800 font-semibold flex items-center gap-1.5 cursor-pointer underline"
          >
            <Code2 className="w-4 h-4 text-amber-600" />
            <span>{showSql ? 'Ocultar script SQL do Supabase' : 'Ver script SQL para configuração do Supabase'}</span>
          </button>

          {showSql && (
            <button
              type="button"
              onClick={handleCopySql}
              className="py-1 px-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-lg text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-slate-900" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copiado!' : 'Copiar SQL'}</span>
            </button>
          )}
        </div>

        {showSql && sqlScript && (
          <div className="mt-3 p-3.5 bg-slate-900 text-emerald-400 rounded-xl font-mono text-[11px] overflow-x-auto border border-slate-800 shadow-inner">
            <pre className="whitespace-pre">{sqlScript}</pre>
          </div>
        )}
      </div>
    </div>
  );
};
