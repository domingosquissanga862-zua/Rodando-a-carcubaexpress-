import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  ShoppingBag,
  Clock,
  Truck,
  CheckCircle2,
  XCircle,
  Package,
  AlertTriangle,
  TrendingUp,
  FileText,
  Plus,
  RefreshCw,
  ArrowUpRight,
  Eye,
  ExternalLink,
  BarChart3,
  PieChart,
  Layers,
  Calendar,
} from 'lucide-react';
import { api } from '../../services/api';
import type { FinancialSummary, Order, OrderStatus } from '../../types';
import { AdminSupabaseCard } from './AdminSupabaseCard';

interface AdminDashboardProps {
  onNavigateTab: (tab: any) => void;
  onOpenProductModal: () => void;
  onViewOrder: (order: Order) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigateTab,
  onOpenProductModal,
  onViewOrder,
}) => {
  const [summary, setSummary] = useState<FinancialSummary | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [period, setPeriod] = useState<'all' | '7d' | '30d'>('all');
  const [chartMetric, setChartMetric] = useState<'revenue' | 'orders'>('revenue');
  const [chartView, setChartView] = useState<'daily' | 'categories' | 'status'>('daily');
  const [hoveredDayIndex, setHoveredDayIndex] = useState<number | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [sumRes, ordersRes] = await Promise.all([
        api.getFinancialSummary(period),
        api.getOrders(),
      ]);
      setSummary(sumRes);
      setRecentOrders(ordersRes.orders.slice(0, 8));
    } catch (err) {
      console.error('Erro ao carregar dados do dashboard:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [period]);

  const handleUpdateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      await api.updateOrderStatus(orderId, { status: newStatus });
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar pedido');
    }
  };

  if (isLoading && !summary) {
    return (
      <div className="p-12 text-center text-slate-400 space-y-3">
        <RefreshCw className="w-8 h-8 animate-spin mx-auto text-amber-500" />
        <p className="text-sm">A carregar métricas reais da CarcubaExpress...</p>
      </div>
    );
  }

  const counts = summary?.statusCounts || {
    total: 0,
    pendentes: 0,
    aguardandoPagamento: 0,
    emPreparacao: 0,
    emTransporte: 0,
    entregues: 0,
    cancelados: 0,
  };

  const productStats = summary?.productStats || {
    total: 0,
    available: 0,
    lowStockCount: 0,
    outOfStockCount: 0,
    lowStockList: [],
    allProductsList: [],
  };
  const allProducts = productStats.allProductsList || [];

  // Max value for 7-day chart scale
  const maxDaySale = summary?.last7Days ? Math.max(...summary.last7Days.map(d => d.sales), 10000) : 10000;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Top Bar with Period Filter & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Visão Geral dos Negócios</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Indicadores reais de vendas, logística e finanças em Luanda
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Period filter buttons */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setPeriod('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                period === 'all' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Todo o Histórico
            </button>
            <button
              onClick={() => setPeriod('30d')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                period === '30d' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Últimos 30 dias
            </button>
            <button
              onClick={() => setPeriod('7d')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                period === '7d' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Últimos 7 dias
            </button>
          </div>

          <button
            onClick={loadData}
            className="p-2 bg-white text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl transition-colors"
            title="Atualizar dados"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Quick Settings Shortcut Banner */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 shrink-0">
            <ExternalLink className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">Personalizar Dados Principais da Loja</h4>
            <p className="text-[11px] text-slate-500">
              Edite o email oficial, morada de Luanda, telefone de apoio e preçário de entregas salvos em tempo real na base de dados.
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigateTab('settings')}
          className="px-4 py-2 bg-[#0B1E36] hover:bg-[#132c4d] text-amber-400 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors shrink-0 shadow-xs cursor-pointer active:scale-95"
        >
          <span>Editar Contactos & Morada</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Primary Financial KPI Cards (Receita, CPV, Despesas, Lucro Líquido) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Receita Total */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Receita Total de Vendas</span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-[#0B1E36] font-mono tabular-nums">
            {(summary?.totalRevenue || 0).toLocaleString('pt-AO')} Kz
          </div>
          <div className="text-[11px] text-slate-500 flex items-center justify-between">
            <span>Confirmada/Paga:</span>
            <span className="font-semibold text-emerald-600 font-mono tabular-nums">
              {(summary?.confirmedPaidRevenue || 0).toLocaleString('pt-AO')} Kz
            </span>
          </div>
        </div>

        {/* Custo das Mercadorias (CPV) */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Custo dos Produtos (CPV)</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-800 font-mono tabular-nums">
            {(summary?.cogsTotal || 0).toLocaleString('pt-AO')} Kz
          </div>
          <div className="text-[11px] text-slate-500 flex items-center justify-between">
            <span>Custo de aquisição</span>
            <span className="text-slate-400">Produtos vendidos</span>
          </div>
        </div>

        {/* Despesas Operacionais */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Despesas Operacionais</span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-800 font-mono tabular-nums">
            {(summary?.totalExpenses || 0).toLocaleString('pt-AO')} Kz
          </div>
          <div className="text-[11px] text-slate-500 flex items-center justify-between">
            <span>Combustível, motas & sacos</span>
            <button
              onClick={() => onNavigateTab('financials')}
              className="text-purple-600 hover:underline font-semibold"
            >
              + Despesa
            </button>
          </div>
        </div>

        {/* Lucro Líquido Estimado */}
        <div className="p-5 bg-gradient-to-br from-[#0B1E36] to-[#132c4d] text-white rounded-2xl shadow-md space-y-2 border border-[#173359]">
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Lucro Líquido Real
            </span>
            <div className="p-2 rounded-xl bg-white/10 text-amber-400">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white font-mono tabular-nums">
            {(summary?.estimatedNetProfit || 0).toLocaleString('pt-AO')} Kz
          </div>
          <div className="text-[11px] text-slate-300">
            <span>Receita - Custo Produtos - Despesas</span>
          </div>
        </div>
      </div>

      {/* Secondary Logistics & Orders Indicators Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-white rounded-xl border border-slate-200">
          <p className="text-[11px] font-semibold text-slate-500 uppercase">Total Pedidos</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">
            {counts.total}
          </p>
          <span className="text-[10px] text-slate-400">
            Ticket médio: {(summary?.averageOrderValue || 0).toLocaleString('pt-AO')} Kz
          </span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200">
          <p className="text-[11px] font-semibold text-amber-600 uppercase">Pendentes</p>
          <p className="text-xl font-bold text-amber-600 font-mono tabular-nums mt-1">
            {counts.pendentes}
          </p>
          <span className="text-[10px] text-slate-400">Aguardam confirmação</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200">
          <p className="text-[11px] font-semibold text-blue-600 uppercase">Em Preparação</p>
          <p className="text-xl font-bold text-blue-600 font-mono tabular-nums mt-1">
            {counts.emPreparacao}
          </p>
          <span className="text-[10px] text-slate-400">Embalagem no armazém</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200">
          <p className="text-[11px] font-semibold text-indigo-600 uppercase">Em Transporte</p>
          <p className="text-xl font-bold text-indigo-600 font-mono tabular-nums mt-1">
            {counts.emTransporte}
          </p>
          <span className="text-[10px] text-slate-400">Nas ruas de Luanda</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200">
          <p className="text-[11px] font-semibold text-emerald-600 uppercase">Entregues</p>
          <p className="text-xl font-bold text-emerald-600 font-mono tabular-nums mt-1">
            {counts.entregues}
          </p>
          <span className="text-[10px] text-slate-400">Vendas concluídas</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200">
          <p className="text-[11px] font-semibold text-rose-600 uppercase">Cancelados</p>
          <p className="text-xl font-bold text-rose-600 font-mono tabular-nums mt-1">
            {counts.cancelados}
          </p>
          <span className="text-[10px] text-slate-400">Anulados ou recusados</span>
        </div>
      </div>

      {/* 2-Column Section: 7-Day Sales Chart & Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gráfico Interativo de Vendas & Faturação Real */}
        <div className="lg:col-span-2 p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-5">
          {/* Header with Title and Mode Switchers */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600">
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Gráfico de Vendas & Desempenho</h3>
                <p className="text-xs text-slate-400">Dados reais consolidados do Supabase</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* View Type Toggle */}
              <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setChartView('daily')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    chartView === 'daily'
                      ? 'bg-[#0B1E36] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  7 Dias
                </button>
                <button
                  type="button"
                  onClick={() => setChartView('categories')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    chartView === 'categories'
                      ? 'bg-[#0B1E36] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Categorias
                </button>
                <button
                  type="button"
                  onClick={() => setChartView('status')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    chartView === 'status'
                      ? 'bg-[#0B1E36] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Estados
                </button>
              </div>

              {/* Metric Toggle: Receita vs Qtd */}
              {chartView === 'daily' && (
                <div className="flex items-center bg-amber-50 border border-amber-200/80 p-0.5 rounded-xl text-[11px] font-bold text-amber-900">
                  <button
                    type="button"
                    onClick={() => setChartMetric('revenue')}
                    className={`px-2 py-1 rounded-lg transition-all ${
                      chartMetric === 'revenue' ? 'bg-amber-500 text-slate-900 shadow-xs' : 'text-amber-800 hover:text-slate-900'
                    }`}
                  >
                    Kz
                  </button>
                  <button
                    type="button"
                    onClick={() => setChartMetric('orders')}
                    className={`px-2 py-1 rounded-lg transition-all ${
                      chartMetric === 'orders' ? 'bg-amber-500 text-slate-900 shadow-xs' : 'text-amber-800 hover:text-slate-900'
                    }`}
                  >
                    Qtd
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Quick Metrics Strip */}
          {(() => {
            const days = summary?.last7Days || [];
            const total7DaysSales = days.reduce((s, d) => s + d.sales, 0);
            const total7DaysOrders = days.reduce((s, d) => s + d.count, 0);
            const bestDay = [...days].sort((a, b) => b.sales - a.sales)[0];

            return (
              <div className="grid grid-cols-3 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold block uppercase">Total 7 Dias</span>
                  <span className="text-sm font-extrabold text-slate-900 font-mono">
                    {total7DaysSales.toLocaleString('pt-AO')} Kz
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold block uppercase">Volume de Pedidos</span>
                  <span className="text-sm font-extrabold text-slate-900 font-mono">
                    {total7DaysOrders} {total7DaysOrders === 1 ? 'pedido' : 'pedidos'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold block uppercase">Melhor Dia</span>
                  <span className="text-sm font-bold text-amber-600 font-mono truncate block">
                    {bestDay && bestDay.sales > 0 ? `${bestDay.label} (${bestDay.sales.toLocaleString('pt-AO')} Kz)` : 'Sem vendas'}
                  </span>
                </div>
              </div>
            );
          })()}

          {/* Dynamic Chart View Body */}
          {chartView === 'daily' && (
            <div className="pt-2">
              {(() => {
                const days = summary?.last7Days || [];
                const maxVal =
                  chartMetric === 'revenue'
                    ? Math.max(...days.map(d => d.sales), 10000)
                    : Math.max(...days.map(d => d.count), 5);

                const activeDay = hoveredDayIndex !== null ? days[hoveredDayIndex] : null;

                return (
                  <div className="space-y-3">
                    {/* Active highlight label */}
                    <div className="h-5 flex items-center justify-between text-xs">
                      {activeDay ? (
                        <span className="font-semibold text-slate-700 flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                          <strong>{activeDay.label} ({activeDay.date}):</strong>{' '}
                          <span className="font-mono text-slate-900 font-bold">{activeDay.sales.toLocaleString('pt-AO')} Kz</span>{' '}
                          · {activeDay.count} {activeDay.count === 1 ? 'encomenda' : 'encomendas'}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">
                          Passe o cursor ou toque nas barras para inspecionar cada dia
                        </span>
                      )}
                      <span className="text-[10px] font-bold text-slate-400">
                        Escala máxima: {chartMetric === 'revenue' ? `${maxVal.toLocaleString('pt-AO')} Kz` : `${maxVal} pedidos`}
                      </span>
                    </div>

                    {/* Chart Bars with Gridlines */}
                    <div className="relative h-44 flex items-end gap-2 sm:gap-5 justify-between border-b border-slate-200 pb-2 pt-4">
                      {/* Horizontal background guideline */}
                      <div className="absolute top-1/2 left-0 right-0 border-b border-dashed border-slate-200 pointer-events-none" />

                      {days.map((day, idx) => {
                        const val = chartMetric === 'revenue' ? day.sales : day.count;
                        const heightPercent = Math.max(6, Math.round((val / maxVal) * 100));
                        const isHovered = hoveredDayIndex === idx;

                        return (
                          <div
                            key={day.date}
                            className="flex-1 flex flex-col items-center gap-2 relative cursor-pointer"
                            onMouseEnter={() => setHoveredDayIndex(idx)}
                            onMouseLeave={() => setHoveredDayIndex(null)}
                            onClick={() => setHoveredDayIndex(isHovered ? null : idx)}
                          >
                            {/* Floating Tooltip */}
                            <div
                              className={`transition-all duration-200 absolute -top-12 bg-slate-900 text-white text-[10px] py-1 px-2.5 rounded-lg font-mono pointer-events-none whitespace-nowrap z-20 shadow-xl ${
                                isHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
                              }`}
                            >
                              <p className="font-bold text-amber-400">{day.label}</p>
                              <p>{day.sales.toLocaleString('pt-AO')} Kz · {day.count} ped.</p>
                            </div>

                            {/* Bar container */}
                            <div className="w-full max-w-[46px] bg-slate-100 hover:bg-slate-200/80 rounded-t-xl h-36 flex items-end overflow-hidden transition-colors">
                              <div
                                className={`w-full rounded-t-xl transition-all duration-500 ${
                                  isHovered
                                    ? 'bg-gradient-to-t from-amber-600 via-amber-500 to-amber-300 shadow-md ring-2 ring-amber-400'
                                    : val > 0
                                    ? 'bg-gradient-to-t from-[#0B1E36] via-[#16375f] to-amber-500'
                                    : 'bg-slate-200'
                                }`}
                                style={{ height: `${heightPercent}%` }}
                              />
                            </div>

                            {/* Day label */}
                            <span
                              className={`text-[11px] font-semibold truncate max-w-[65px] transition-colors ${
                                isHovered ? 'text-amber-600 font-bold' : 'text-slate-500'
                              }`}
                            >
                              {day.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Categories View */}
          {chartView === 'categories' && (
            <div className="space-y-3 pt-1">
              <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
                <span>Categoria / Departamento</span>
                <span>Faturação & Volume</span>
              </div>
              {summary?.categorySales && summary.categorySales.length > 0 ? (
                <div className="space-y-3">
                  {summary.categorySales.map(cat => {
                    const totalRev = summary.totalRevenue || 1;
                    const percent = Math.min(100, Math.round((cat.totalSales / totalRev) * 100));

                    return (
                      <div key={cat.name} className="space-y-1.5 p-2 rounded-xl hover:bg-slate-50 transition-colors">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-slate-800">{cat.name}</span>
                          <span className="font-mono text-slate-900 font-bold">
                            {cat.totalSales.toLocaleString('pt-AO')} Kz{' '}
                            <span className="text-[11px] text-slate-400 font-normal">
                              ({cat.unitsSold} {cat.unitsSold === 1 ? 'unidade' : 'unidades'} · {percent}%)
                            </span>
                          </span>
                        </div>
                        <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#0B1E36] to-amber-500 rounded-full transition-all duration-500"
                            style={{ width: `${Math.max(4, percent)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">
                  Ainda sem vendas categorizadas no período selecionado.
                </div>
              )}
            </div>
          )}

          {/* Status Breakdown View */}
          {chartView === 'status' && (
            <div className="space-y-3 pt-1">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-amber-50/60 border border-amber-200">
                  <span className="text-[10px] font-bold text-amber-700 block uppercase">Pendentes</span>
                  <span className="text-lg font-black text-amber-700 font-mono">{counts.pendentes}</span>
                  <span className="text-[10px] text-amber-600 block mt-0.5">A aguardar confirmação</span>
                </div>
                <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-200">
                  <span className="text-[10px] font-bold text-blue-700 block uppercase">Em Preparação</span>
                  <span className="text-lg font-black text-blue-700 font-mono">{counts.emPreparacao}</span>
                  <span className="text-[10px] text-blue-600 block mt-0.5">Embalagem no armazém</span>
                </div>
                <div className="p-3 rounded-xl bg-indigo-50/60 border border-indigo-200">
                  <span className="text-[10px] font-bold text-indigo-700 block uppercase">Em Transporte</span>
                  <span className="text-lg font-black text-indigo-700 font-mono">{counts.emTransporte}</span>
                  <span className="text-[10px] text-indigo-600 block mt-0.5">Com o estafeta</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200">
                  <span className="text-[10px] font-bold text-emerald-700 block uppercase">Entregues</span>
                  <span className="text-lg font-black text-emerald-700 font-mono">{counts.entregues}</span>
                  <span className="text-[10px] text-emerald-600 block mt-0.5">Concluídos com sucesso</span>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="font-medium">Total de Encomendas Registadas:</span>
                  <strong className="font-mono text-slate-900 font-bold">{counts.total}</strong>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span className="font-medium">Taxa de Conclusão / Entrega:</span>
                  <strong className="font-mono text-emerald-600 font-bold">
                    {counts.total > 0 ? `${Math.round((counts.entregues / counts.total) * 100)}%` : '0%'}
                  </strong>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Product Stock & Warehouse Status */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Estado do Stock no Armazém</h3>
                <p className="text-xs text-slate-400">Controlo de inventário em tempo real</p>
              </div>
              <button
                onClick={() => onNavigateTab('products')}
                className="text-xs text-amber-600 hover:text-amber-700 font-bold hover:underline"
              >
                Gerir Catálogo →
              </button>
            </div>

            {/* Inventory KPI Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-center">
                <span className="text-[10px] text-slate-500 font-semibold block uppercase">Total Artigos</span>
                <span className="text-base font-extrabold text-slate-900 font-mono">
                  {productStats.total}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200/60 text-center">
                <span className="text-[10px] text-emerald-700 font-semibold block uppercase">Disponíveis</span>
                <span className="text-base font-extrabold text-emerald-600 font-mono">
                  {productStats.available}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200/60 text-center">
                <span className="text-[10px] text-amber-700 font-semibold block uppercase">Pouco Stock</span>
                <span className="text-base font-extrabold text-amber-600 font-mono">
                  {productStats.lowStockCount}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200/60 text-center">
                <span className="text-[10px] text-rose-700 font-semibold block uppercase">Esgotados</span>
                <span className="text-base font-extrabold text-rose-600 font-mono">
                  {productStats.outOfStockCount}
                </span>
              </div>
            </div>

            {/* Low stock alert banner if any */}
            {productStats.lowStockCount > 0 && (
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-2 text-xs text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                <span className="font-semibold">
                  Atenção: {productStats.lowStockCount} produto(s) com nível crítico (≤ 5 unidades).
                </span>
              </div>
            )}

            {/* Live Inventory List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <span>Artigos no Armazém ({allProducts.length})</span>
                {allProducts.length > 0 && (
                  <span className="text-[11px] text-slate-400 font-normal">Sincronizado com Supabase</span>
                )}
              </div>

              {allProducts.length === 0 ? (
                <div className="p-6 text-center rounded-xl bg-slate-50 border border-dashed border-slate-200 space-y-2">
                  <Package className="w-6 h-6 text-slate-400 mx-auto" />
                  <p className="text-xs text-slate-500">Nenhum produto registado no inventário do armazém.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1 divide-y divide-slate-100">
                  {allProducts.map(prod => (
                    <div
                      key={prod.id}
                      className="pt-2 first:pt-0 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={(prod.images && prod.images[0]) || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
                          alt={prod.name}
                          className="w-9 h-9 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-200"
                        />
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 truncate max-w-[180px] sm:max-w-[220px]">
                            {prod.name}
                          </p>
                          <div className="flex items-center gap-2 text-[10px] text-slate-500">
                            <span>{prod.categoryName || 'Eletrónicos'}</span>
                            <span>•</span>
                            <span className="font-mono font-semibold text-slate-700">
                              {(prod.price || 0).toLocaleString('pt-AO')} Kz
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span
                          className={`font-mono font-bold px-2.5 py-1 rounded-lg text-[11px] ${
                            prod.stock <= 0
                              ? 'bg-rose-100 text-rose-800 border border-rose-200'
                              : prod.stock <= 5
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}
                        >
                          {prod.stock} un.
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <button
            onClick={onOpenProductModal}
            className="w-full mt-3 py-2.5 px-3 bg-[#0B1E36] hover:bg-[#132c4d] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs active:scale-[0.99]"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Adicionar Novo Produto</span>
          </button>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Pedidos Recentes dos Clientes</h3>
            <p className="text-xs text-slate-400">
              Acompanhamento de encomendas e atualização direta de estados
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1"
          >
            <span>Ver Todos os Pedidos</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

        {recentOrders.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Ainda não foram registados pedidos no sistema.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/50">
                  <th className="py-3 px-4">Nº Pedido</th>
                  <th className="py-3 px-4">Cliente / Contacto</th>
                  <th className="py-3 px-4">Município</th>
                  <th className="py-3 px-4">Itens</th>
                  <th className="py-3 px-4 text-right">Total (Kz)</th>
                  <th className="py-3 px-4">Pagamento</th>
                  <th className="py-3 px-4">Estado</th>
                  <th className="py-3 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentOrders.map(order => (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {order.orderNumber}
                    </td>

                    <td className="py-3 px-4">
                      <p className="font-semibold text-slate-900">{order.customerName}</p>
                      <p className="text-[11px] text-slate-500 font-mono">{order.customerPhone}</p>
                    </td>

                    <td className="py-3 px-4 text-slate-700">
                      {order.deliveryMunicipality.split(' ')[0]}
                    </td>

                    <td className="py-3 px-4 text-slate-600">
                      <span title={(order.items || []).map(i => `${i.quantity}x ${i.productName}`).join(', ')}>
                        {(order.items || []).length} produto(s)
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-[#0B1E36] tabular-nums">
                      {order.total.toLocaleString('pt-AO')} Kz
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                          order.paymentStatus === 'Confirmado'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {order.paymentStatus}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <select
                        value={order.status}
                        onChange={e => handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                        className={`text-xs font-semibold py-1 px-2 rounded-lg border focus:outline-none ${
                          order.status === 'Entregue'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : order.status === 'Cancelado'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : order.status === 'Em transporte'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        <option value="Pendente">Pendente</option>
                        <option value="A aguardar pagamento">A aguardar pagamento</option>
                        <option value="Pagamento confirmado">Pagamento confirmado</option>
                        <option value="Em preparação">Em preparação</option>
                        <option value="Em transporte">Em transporte</option>
                        <option value="Entregue">Entregue</option>
                        <option value="Cancelado">Cancelado</option>
                      </select>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => onViewOrder(order)}
                        className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        title="Ver Detalhes do Pedido"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Supabase Cloud Database Integration Status & Tools */}
      <AdminSupabaseCard />
    </div>
  );
};
