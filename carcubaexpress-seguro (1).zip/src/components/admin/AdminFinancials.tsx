import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  TrendingUp,
  Package,
  Plus,
  Trash2,
  Calendar,
  AlertCircle,
  FileText,
  Calculator,
  RefreshCw,
  X,
  Download,
  Printer,
  Check,
  Pencil,
} from 'lucide-react';
import { api } from '../../services/api';
import type { FinancialSummary, Expense } from '../../types';
import { generateFinancialPDF } from '../../utils/pdfExport';

export const AdminFinancials: React.FC = () => {
  const [summary, setSummary] = useState<FinancialSummary | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [period, setPeriod] = useState<'all' | 'today' | '7d' | '30d'>('all');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // New Expense modal
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseTitle, setExpenseTitle] = useState('');
  const [expenseCategory, setExpenseCategory] = useState<Expense['category']>('Transporte & Logística');
  const [expenseAmount, setExpenseAmount] = useState<string>('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [expenseNote, setExpenseNote] = useState('');
  const [isSavingExpense, setIsSavingExpense] = useState(false);

  // Edit Expense modal
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editCategory, setEditCategory] = useState<Expense['category']>('Transporte & Logística');
  const [editAmount, setEditAmount] = useState<string>('');
  const [editDate, setEditDate] = useState('');
  const [editNote, setEditNote] = useState('');
  const [isUpdatingExpense, setIsUpdatingExpense] = useState(false);

  // Custom Delete Expense Modal (No browser confirm)
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
  const [isDeletingExpense, setIsDeletingExpense] = useState(false);

  const openNewExpenseModal = () => {
    setExpenseTitle('');
    setExpenseCategory('Transporte & Logística');
    setExpenseAmount('');
    setExpenseDate(new Date().toISOString().split('T')[0]);
    setExpenseNote('');
    setIsExpenseModalOpen(true);
  };

  const openEditExpenseModal = (exp: Expense) => {
    setEditingExpense(exp);
    setEditTitle(exp.title || '');
    setEditCategory(exp.category || 'Transporte & Logística');
    setEditAmount(String(exp.amount || ''));
    setEditDate(exp.date || new Date().toISOString().split('T')[0]);
    setEditNote(exp.note || '');
  };

  const loadData = async () => {
    setIsLoading(true);
    try {
      const summaryPromise = selectedDate
        ? api.getFinancialSummary({ date: selectedDate })
        : api.getFinancialSummary(period);

      const [sumRes, expRes] = await Promise.all([
        summaryPromise,
        api.getExpenses(),
      ]);
      setSummary(sumRes);

      // If a specific date is selected, also filter expenses for that day
      if (selectedDate) {
        setExpenses(expRes.expenses.filter(e => e.date === selectedDate || e.createdAt.startsWith(selectedDate)));
      } else {
        setExpenses(expRes.expenses);
      }
    } catch (err) {
      console.error('Erro ao carregar dados financeiros:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [period, selectedDate]);

  const handleDownloadPDF = () => {
    if (!summary) return;
    try {
      generateFinancialPDF(summary, expenses, selectedDate || undefined);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao gerar PDF:', err);
      window.print();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAmountStr = expenseAmount.trim().replace(',', '.');
    const parsedAmount = parseFloat(cleanAmountStr);

    if (!expenseTitle.trim()) {
      alert('Por favor, introduza a descrição da despesa.');
      return;
    }

    if (!cleanAmountStr || isNaN(parsedAmount) || parsedAmount <= 0) {
      alert('Por favor, introduza um valor numérico válido superior a zero.');
      return;
    }

    setIsSavingExpense(true);
    try {
      await api.createExpense({
        title: expenseTitle.trim(),
        category: expenseCategory,
        amount: parsedAmount,
        date: expenseDate,
        note: expenseNote.trim() || undefined,
      });
      setIsExpenseModalOpen(false);
      setExpenseTitle('');
      setExpenseAmount('');
      setExpenseNote('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao adicionar despesa');
    } finally {
      setIsSavingExpense(false);
    }
  };

  const handleUpdateExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExpense) return;

    const cleanAmountStr = editAmount.trim().replace(',', '.');
    const parsedAmount = parseFloat(cleanAmountStr);

    if (!editTitle.trim()) {
      alert('Por favor, introduza a descrição da despesa.');
      return;
    }

    if (!cleanAmountStr || isNaN(parsedAmount) || parsedAmount <= 0) {
      alert('Por favor, introduza um valor numérico válido superior a zero.');
      return;
    }

    setIsUpdatingExpense(true);
    try {
      await api.updateExpense(editingExpense.id, {
        title: editTitle.trim(),
        category: editCategory,
        amount: parsedAmount,
        date: editDate,
        note: editNote.trim() || undefined,
      });
      setEditingExpense(null);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar despesa');
    } finally {
      setIsUpdatingExpense(false);
    }
  };

  const confirmDeleteExpense = async () => {
    if (!expenseToDelete) return;
    setIsDeletingExpense(true);
    try {
      await api.deleteExpense(expenseToDelete.id);
      setExpenseToDelete(null);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao eliminar despesa');
    } finally {
      setIsDeletingExpense(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Report Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Relatórios & Gestão Financeira</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Cálculo exato de vendas, margens de lucro, custos de mercadorias (CPV) e despesas em Luanda
          </p>
        </div>

        {/* Date Filters & Download Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Day Date Picker */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="text-[11px] font-semibold text-slate-600 whitespace-nowrap">Dia:</span>
            <input
              type="date"
              value={selectedDate}
              onChange={e => {
                setSelectedDate(e.target.value);
                if (e.target.value) setPeriod('all');
              }}
              className="text-xs font-semibold text-slate-800 bg-transparent focus:outline-none cursor-pointer font-mono"
              title="Selecione o dia específico para o relatório financeiro"
            />
            {selectedDate && (
              <button
                onClick={() => setSelectedDate('')}
                className="text-[11px] font-bold text-rose-500 hover:text-rose-700 ml-1 px-1"
                title="Limpar seleção de dia e ver geral"
              >
                ✕
              </button>
            )}
          </div>

          {/* Period buttons (if not date-locked) */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => {
                setSelectedDate('');
                setPeriod('all');
              }}
              className={`px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                !selectedDate && period === 'all'
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Geral
            </button>
            <button
              onClick={() => {
                const today = new Date().toISOString().split('T')[0];
                setSelectedDate(today);
              }}
              className={`px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                selectedDate === new Date().toISOString().split('T')[0]
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hoje
            </button>
            <button
              onClick={() => {
                setSelectedDate('');
                setPeriod('7d');
              }}
              className={`px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                !selectedDate && period === '7d'
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              7 Dias
            </button>
            <button
              onClick={() => {
                setSelectedDate('');
                setPeriod('30d');
              }}
              className={`px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                !selectedDate && period === '30d'
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              30 Dias
            </button>
          </div>

          {/* Download PDF button */}
          <button
            onClick={handleDownloadPDF}
            className="py-2 px-3.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer active:scale-95"
            title="Baixar relatório em formato PDF para o seu dispositivo"
          >
            {downloadSuccess ? <Check className="w-4 h-4 text-emerald-950" /> : <Download className="w-4 h-4" />}
            <span>Baixar Relatório em PDF</span>
          </button>

          {/* Print button */}
          <button
            onClick={handlePrint}
            className="py-2 px-3 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            title="Imprimir relatório ou guardar como PDF pelo navegador"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Imprimir</span>
          </button>

          {/* New Expense */}
          <button
            onClick={() => setIsExpenseModalOpen(true)}
            className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Nova Despesa</span>
          </button>
        </div>
      </div>

      {/* Active Day Banner if selected */}
      {selectedDate && (
        <div className="flex items-center justify-between p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900">
          <div className="flex items-center gap-2 font-medium">
            <Calendar className="w-4 h-4 text-amber-600" />
            <span>
              A visualizar dados do dia específico:{' '}
              <strong className="font-mono text-slate-900 font-bold">
                {new Date(selectedDate + 'T00:00:00').toLocaleDateString('pt-PT')}
              </strong>
            </span>
          </div>
          <button
            onClick={() => setSelectedDate('')}
            className="px-2.5 py-1 bg-amber-200/60 hover:bg-amber-200 text-amber-900 font-bold rounded-lg transition-colors cursor-pointer"
          >
            Ver Histórico Geral
          </button>
        </div>
      )}

      {/* Financial Formula Explanation Card */}
      <div className="p-5 bg-gradient-to-r from-slate-900 to-[#0B1E36] text-white rounded-2xl shadow-md border border-slate-800 space-y-2">
        <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
          <Calculator className="w-4 h-4" />
          <span>Fórmula Oficial de Cálculo de Lucro Líquido</span>
        </div>
        <p className="text-sm font-semibold text-slate-200">
          Lucro Líquido Estimado = Receita Bruta de Vendas (Pedidos Activos) - Custo dos Produtos Vendidos (CPV) - Despesas Operacionais Registadas
        </p>
        <p className="text-xs text-slate-400">
          * Pedidos cancelados são expressamente excluídos da receita para garantir rigor contabilístico.
        </p>
      </div>

      {/* Financial Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 space-y-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Receita Bruta</span>
          <div className="text-2xl font-black text-[#0B1E36] font-mono tabular-nums">
            {(summary?.totalRevenue || 0).toLocaleString('pt-AO')} Kz
          </div>
          <p className="text-[11px] text-slate-400">Total de pedidos activos</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 space-y-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Custo Mercadorias (CPV)</span>
          <div className="text-2xl font-black text-amber-600 font-mono tabular-nums">
            -{(summary?.cogsTotal || 0).toLocaleString('pt-AO')} Kz
          </div>
          <p className="text-[11px] text-slate-400">Custo de compra dos produtos</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 space-y-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Despesas Operacionais</span>
          <div className="text-2xl font-black text-rose-600 font-mono tabular-nums">
            -{(summary?.totalExpenses || 0).toLocaleString('pt-AO')} Kz
          </div>
          <p className="text-[11px] text-slate-400">Combustível, estafetas, marketing</p>
        </div>

        <div className="p-5 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">Lucro Líquido Estimado</span>
          <div className="text-2xl font-black text-emerald-700 font-mono tabular-nums">
            {(summary?.estimatedNetProfit || 0).toLocaleString('pt-AO')} Kz
          </div>
          <p className="text-[11px] text-emerald-600">Resultado final do negócio</p>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Registo de Despesas Operacionais</h3>
            <p className="text-xs text-slate-400">Custos diários de motas, estafetas, sacos e internet</p>
          </div>

          <button
            onClick={openNewExpenseModal}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Nova Despesa</span>
          </button>
        </div>

        {expenses.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Nenhuma despesa registada até ao momento.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/50">
                  <th className="py-3 px-4">Data</th>
                  <th className="py-3 px-4">Descrição da Despesa</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4 text-right">Valor (Kz)</th>
                  <th className="py-3 px-4">Registado por</th>
                  <th className="py-3 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {expenses.map(exp => (
                  <tr key={exp.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {new Date(exp.date).toLocaleDateString('pt-PT')}
                    </td>

                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {exp.title}
                      {exp.note && <span className="block text-[10px] text-slate-400 font-normal">{exp.note}</span>}
                    </td>

                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium">
                        {exp.category}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-rose-600 tabular-nums">
                      {exp.amount.toLocaleString('pt-AO')} Kz
                    </td>

                    <td className="py-3 px-4 text-slate-500">
                      {exp.createdByName}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => openEditExpenseModal(exp)}
                          className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                          title="Editar despesa"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setExpenseToDelete(exp)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="Eliminar despesa"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Registar Nova Despesa</h3>
              <button
                onClick={() => setIsExpenseModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddExpense} className="space-y-3.5">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Descrição da Despesa <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Combustível para entregas em Talatona"
                  value={expenseTitle}
                  onChange={e => setExpenseTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Categoria:</label>
                  <select
                    value={expenseCategory}
                    onChange={e => setExpenseCategory(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Transporte & Logística">Transporte & Logística</option>
                    <option value="Embalagens">Embalagens</option>
                    <option value="Marketing & Publicidade">Marketing & Publicidade</option>
                    <option value="Comunicação & Net">Comunicação & Net</option>
                    <option value="Salários & Operacional">Salários & Operacional</option>
                    <option value="Outros">Outros</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Valor (Kz) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="ex: 5000"
                    required
                    value={expenseAmount}
                    onChange={e => {
                      const val = e.target.value.replace(/[^0-9.,]/g, '');
                      setExpenseAmount(val);
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Data:</label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={e => setExpenseDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Observações:</label>
                <input
                  type="text"
                  placeholder="ex: Fatura da bomba Sonangol"
                  value={expenseNote}
                  onChange={e => setExpenseNote(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSavingExpense}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl shadow-md cursor-pointer"
                >
                  {isSavingExpense ? 'A registar...' : 'Guardar Despesa'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Expense Modal */}
      {editingExpense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Editar Registo de Despesa</h3>
              <button
                onClick={() => setEditingExpense(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateExpenseSubmit} className="space-y-3.5">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Descrição da Despesa <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Combustível para entregas em Talatona"
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Categoria:</label>
                  <select
                    value={editCategory}
                    onChange={e => setEditCategory(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Transporte & Logística">Transporte & Logística</option>
                    <option value="Embalagens">Embalagens</option>
                    <option value="Marketing & Publicidade">Marketing & Publicidade</option>
                    <option value="Comunicação & Net">Comunicação & Net</option>
                    <option value="Salários & Operacional">Salários & Operacional</option>
                    <option value="Outros">Outros</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Valor (Kz) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="ex: 5000"
                    required
                    value={editAmount}
                    onChange={e => {
                      const val = e.target.value.replace(/[^0-9.,]/g, '');
                      setEditAmount(val);
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Data:</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={e => setEditDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Observações:</label>
                <input
                  type="text"
                  placeholder="ex: Fatura da bomba Sonangol"
                  value={editNote}
                  onChange={e => setEditNote(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingExpense(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isUpdatingExpense}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl shadow-md cursor-pointer"
                >
                  {isUpdatingExpense ? 'A atualizar...' : 'Atualizar Despesa'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Expense Custom Confirmation Modal (No Browser confirm()) */}
      {expenseToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-rose-100 text-rose-600 rounded-2xl shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900">
                  Eliminar Registo de Despesa
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Tem a certeza de que deseja eliminar este registo de despesa? Esta ação não poderá ser desfeita.
                </p>
                <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
                  <p className="font-bold text-slate-800">{expenseToDelete.title}</p>
                  <div className="flex justify-between text-slate-600">
                    <span>Categoria: {expenseToDelete.category}</span>
                    <span className="font-mono font-bold text-rose-600">
                      {expenseToDelete.amount.toLocaleString('pt-AO')} Kz
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono">
                    Data: {new Date(expenseToDelete.date).toLocaleDateString('pt-PT')}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2.5 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setExpenseToDelete(null)}
                disabled={isDeletingExpense}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteExpense}
                disabled={isDeletingExpense}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeletingExpense ? 'A eliminar...' : 'Confirmar Eliminação'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
