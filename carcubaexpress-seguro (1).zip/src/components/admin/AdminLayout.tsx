import React from 'react';
import {
  LayoutDashboard,
  ShoppingBag,
  Package,
  Layers,
  Users,
  Truck,
  DollarSign,
  FileText,
  Settings,
  LogOut,
  ExternalLink,
  Shield,
  Menu,
  X,
  Plus,
  ArrowLeft,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type AdminTab =
  | 'dashboard'
  | 'orders'
  | 'products'
  | 'categories'
  | 'customers'
  | 'deliveries'
  | 'financials'
  | 'reports'
  | 'settings';

interface AdminLayoutProps {
  currentTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  onExitAdmin: () => void;
  onNewProduct: () => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onSelectTab,
  onExitAdmin,
  onNewProduct,
  children,
}) => {
  const { user, logout } = useAuth();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = React.useState(false);

  const navItems: { id: AdminTab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Pedidos', icon: ShoppingBag },
    { id: 'products', label: 'Produtos', icon: Package },
    { id: 'categories', label: 'Categorias', icon: Layers },
    { id: 'customers', label: 'Clientes', icon: Users },
    { id: 'deliveries', label: 'Entregas em Luanda', icon: Truck },
    { id: 'financials', label: 'Financeiro', icon: DollarSign },
    { id: 'reports', label: 'Relatórios', icon: FileText },
    { id: 'settings', label: 'Configurações', icon: Settings },
  ];

  const handleLogout = async () => {
    await logout();
    onExitAdmin();
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row text-slate-800">
      {/* Mobile Top Header */}
      <div className="md:hidden bg-[#0B1E36] text-white p-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2.5">
          <img
            src="/assets/aistudio/logo_a1884a32.jpg"
            alt="CarcubaExpress"
            className="w-8 h-8 rounded-full object-contain bg-white p-0.5 border border-amber-400"
          />
          <span className="font-bold text-sm tracking-tight">CarcubaExpress Admin</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onExitAdmin}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-lg text-xs font-bold transition-all shadow-sm cursor-pointer"
            title="Sair do painel administrativo e voltar à loja"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Voltar ao Site</span>
          </button>
          <button
            onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
            className="p-2 rounded-lg bg-white/10 text-white cursor-pointer"
            aria-label="Abrir menu"
          >
            {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={`fixed md:sticky top-0 z-40 h-screen w-64 bg-[#0B1E36] text-white flex flex-col justify-between transition-transform duration-200 border-r border-[#173359] ${
          isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="p-5 space-y-6">
          {/* Logo brand */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src="/assets/aistudio/logo_a1884a32.jpg"
                alt="CarcubaExpress"
                className="w-10 h-10 rounded-full object-contain bg-white p-0.5 border border-amber-400 shadow-sm shrink-0"
              />
              <div>
                <h1 className="text-base font-extrabold tracking-tight text-white leading-none">
                  Carcuba<span className="text-amber-400">Express</span>
                </h1>
                <p className="text-[10px] uppercase tracking-wider text-slate-400 mt-1 font-semibold">
                  Painel de Gestão
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsMobileSidebarOpen(false)}
              className="md:hidden p-1 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Action Button */}
          <button
            onClick={() => {
              onSelectTab('products');
              onNewProduct();
              setIsMobileSidebarOpen(false);
            }}
            className="w-full py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Novo Produto</span>
          </button>

          {/* Menu items */}
          <nav className="space-y-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    setIsMobileSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                    isActive
                      ? 'bg-amber-500 text-slate-900 shadow-sm'
                      : 'text-slate-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-white/10 space-y-2">
          {/* Admin user info */}
          <div className="flex items-center gap-2.5 px-2 py-1.5 text-xs text-slate-300">
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-amber-400 font-bold shrink-0">
              <Shield className="w-3.5 h-3.5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-white truncate text-[11px]">
                {user?.name || 'Domingos Quissanga'}
              </p>
              <p className="text-[10px] text-amber-400 font-mono truncate">{user?.email || 'domingosquissanga862@gmail.com'}</p>
            </div>
          </div>

          <button
            onClick={onExitAdmin}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-slate-300 hover:bg-white/10 hover:text-white transition-colors"
          >
            <span className="flex items-center gap-2">
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
              <span>Ver Loja Pública</span>
            </span>
          </button>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-rose-300 hover:bg-rose-950/40 hover:text-rose-200 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Terminar Sessão</span>
          </button>
        </div>
      </aside>

      {/* Main Content Viewport */}
      <main className="flex-1 min-w-0 overflow-y-auto max-h-screen">
        {/* Top Header Bar for Desktop */}
        <header className="hidden md:flex items-center justify-between px-8 py-4 bg-white border-b border-slate-200 sticky top-0 z-30">
          <div>
            <h2 className="text-base font-extrabold text-[#0B1E36] capitalize">
              {navItems.find(i => i.id === currentTab)?.label || 'Dashboard'}
            </h2>
            <p className="text-xs text-slate-400">
              CarcubaExpress Comércio · Gestão Operacional e Financeira em Luanda
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onExitAdmin}
              className="px-4 py-2 bg-[#0B1E36] hover:bg-[#132c4d] text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
              <span>Voltar ao Site</span>
            </button>
          </div>
        </header>

        {/* Dynamic Screen Content */}
        <div className="p-4 sm:p-6 lg:p-8">{children}</div>
      </main>

      {/* Floating Action Button to Exit Admin Back to Store */}
      <div className="fixed bottom-5 left-5 sm:bottom-7 sm:left-7 z-40">
        <button
          onClick={onExitAdmin}
          className="flex items-center gap-2 px-4 py-3 bg-[#0B1E36] hover:bg-[#132c4d] text-white rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 active:scale-95 border-2 border-amber-400 cursor-pointer text-xs font-bold"
          title="Sair do painel administrativo e voltar à loja pública"
        >
          <ArrowLeft className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Voltar ao Site</span>
        </button>
      </div>
    </div>
  );
};
