import React, { useState, useEffect } from 'react';
import { Settings, Save, RefreshCw, MessageCircle, MapPin, Truck, AlertCircle, CheckCircle, Mail, Phone, FileText, Layers, Info, ShieldCheck, Plus, X } from 'lucide-react';
import { api } from '../../services/api';
import type { StoreSettings, MunicipalityConfig } from '../../types';
import { useCart } from '../../context/CartContext';
import { AdminSupabaseCard } from './AdminSupabaseCard';

import { supabase } from '../../services/supabase';

export const AdminSettings: React.FC = () => {
  const { refreshSettings } = useCart();
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [storeName, setStoreName] = useState('');
  const [storeDescription, setStoreDescription] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [supportPhone, setSupportPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [defaultShippingFee, setDefaultShippingFee] = useState<string>('');
  const [freeShippingMinAmount, setFreeShippingMinAmount] = useState<string>('');
  const [municipalities, setMunicipalities] = useState<Array<{ name: string; fee: string | number; estimatedHours?: string }>>([]);

  // Policy and descriptions state
  const [deliveryPolicyTitle, setDeliveryPolicyTitle] = useState('');
  const [deliveryPolicyText, setDeliveryPolicyText] = useState('');
  const [paymentPolicyTitle, setPaymentPolicyTitle] = useState('');
  const [paymentPolicyText, setPaymentPolicyText] = useState('');
  const [termsPolicyTitle, setTermsPolicyTitle] = useState('');
  const [termsPolicyText, setTermsPolicyText] = useState('');
  const [supportPolicyTitle, setSupportPolicyTitle] = useState('');
  const [supportPolicyText, setSupportPolicyText] = useState('');
  const [footerDepartments, setFooterDepartments] = useState<string[]>([]);

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const loadSettings = async () => {
    setIsLoading(true);
    setErrorMessage('');
    try {
      const res = await api.getSettings();
      setSettings(res.settings);
      setStoreName(res.settings.storeName || 'CarcubaExpress Comércio');
      setStoreDescription(
        res.settings.storeDescription ||
          'A sua loja online de referência em Luanda, Angola. Tecnologia, eletrónicos, microfones profissionais, perfumes árabes originais, moda feminina e artigos para o lar com entrega rápida.'
      );
      setWhatsappNumber(res.settings.whatsappNumber || '244951556411');
      setSupportPhone(res.settings.supportPhone || '+244 951 556 411');
      setEmail(res.settings.email || 'carcubaexpress@gmail.com');
      setAddress(res.settings.address || 'Luanda, Angola (Entregas ao domicílio)');
      setCity(res.settings.city || 'Luanda');
      setDefaultShippingFee(
        res.settings.defaultShippingFee !== undefined && res.settings.defaultShippingFee !== null
          ? String(res.settings.defaultShippingFee)
          : ''
      );
      setFreeShippingMinAmount(
        res.settings.freeShippingMinAmount !== undefined && res.settings.freeShippingMinAmount !== null
          ? String(res.settings.freeShippingMinAmount)
          : ''
      );
      setMunicipalities(
        (res.settings.deliveryMunicipalities || []).map((m: { name: string; fee: number; estimatedHours?: string }) => ({
          ...m,
          fee: m.fee !== undefined && m.fee !== null ? String(m.fee) : '',
        }))
      );

      setDeliveryPolicyTitle(res.settings.deliveryPolicyTitle || 'Entregas em Luanda & Municípios');
      setDeliveryPolicyText(
        res.settings.deliveryPolicyText ||
          'Realizamos entregas rápidas ao domicílio em todos os municípios de Luanda (Talatona, Kilamba, Maianga, Viana, Cazenga, Cacuaco e arredores). O estafeta entra em contacto por telefone ou WhatsApp antes da deslocação para confirmar a sua localização e ponto de referência.'
      );
      setPaymentPolicyTitle(res.settings.paymentPolicyTitle || 'Formas de Pagamento (Apenas Dinheiro e Express)');
      setPaymentPolicyText(
        res.settings.paymentPolicyText ||
          'Garantimos total segurança na sua compra. O pagamento é realizado apenas no acto da entrega: aceitamos Dinheiro em mão ou transferência por Multicaixa Express na presença do estafeta após verificar e aprovar a sua encomenda.'
      );
      setTermsPolicyTitle(res.settings.termsPolicyTitle || 'Termos e Condições de Compra');
      setTermsPolicyText(
        res.settings.termsPolicyText ||
          'Todos os produtos comercializados pela CarcubaExpress dispõem de garantia de conformidade. O cliente tem o direito e o dever de inspecionar o produto no momento da entrega antes de efetuar o pagamento. Caso o artigo apresente alguma anomalia, procedemos à troca imediata.'
      );
      setSupportPolicyTitle(res.settings.supportPolicyTitle || 'Apoio ao Cliente & Contactos');
      setSupportPolicyText(
        res.settings.supportPolicyText ||
          'A nossa equipa de apoio ao cliente funciona de Segunda a Sábado das 08h00 às 19h00 via WhatsApp comercial oficial (+244 951 556 411) ou por chamada telefónica direta.'
      );
      setFooterDepartments(
        res.settings.footerDepartments || [
          'Eletrónicos & Som',
          'Perfumaria & Fragrâncias',
          'Moda Feminina & Vestuário',
          'Bolsas & Acessórios',
          'Beleza, Saúde & Cuidados',
          'Casa & Utilidades',
        ]
      );
    } catch (err: any) {
      console.error('Erro ao carregar configurações:', err);
      setErrorMessage('Não foi possível carregar as configurações do servidor.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setMessage('');
    setErrorMessage('');

    const cleanShipping = String(defaultShippingFee).trim().replace(',', '.');
    const parsedShipping = cleanShipping === '' ? 0 : parseFloat(cleanShipping);
    if (isNaN(parsedShipping) || parsedShipping < 0) {
      setErrorMessage('Por favor, introduza uma taxa de entrega válida.');
      setIsSaving(false);
      return;
    }

    const cleanFreeMin = String(freeShippingMinAmount).trim().replace(',', '.');
    const parsedFreeMin = cleanFreeMin === '' ? 0 : parseFloat(cleanFreeMin);
    if (isNaN(parsedFreeMin) || parsedFreeMin < 0) {
      setErrorMessage('Por favor, introduza um valor mínimo de encomenda para frete grátis válido.');
      setIsSaving(false);
      return;
    }

    const sanitizedMunicipalities: MunicipalityConfig[] = municipalities.map(m => {
      const cleanFee = String(m.fee ?? '').trim().replace(',', '.');
      const feeNum = cleanFee === '' ? 0 : parseFloat(cleanFee);
      return {
        name: m.name,
        fee: isNaN(feeNum) ? 0 : Math.max(0, feeNum),
        estimatedHours: m.estimatedHours || '24h',
      };
    });

    const payload = {
      storeName: storeName.trim(),
      storeDescription: storeDescription.trim(),
      whatsappNumber: whatsappNumber.replace(/\D/g, ''),
      supportPhone: supportPhone.trim(),
      email: email.trim(),
      address: address.trim(),
      city: city.trim(),
      defaultShippingFee: parsedShipping,
      freeShippingMinAmount: parsedFreeMin,
      deliveryMunicipalities: sanitizedMunicipalities,
      deliveryPolicyTitle: deliveryPolicyTitle.trim(),
      deliveryPolicyText: deliveryPolicyText.trim(),
      paymentPolicyTitle: paymentPolicyTitle.trim(),
      paymentPolicyText: paymentPolicyText.trim(),
      termsPolicyTitle: termsPolicyTitle.trim(),
      termsPolicyText: termsPolicyText.trim(),
      supportPolicyTitle: supportPolicyTitle.trim(),
      supportPolicyText: supportPolicyText.trim(),
      footerDepartments,
    };

    try {
      // 1. Save to backend database & persistent store
      await api.updateSettings(payload);

      // 2. Direct client upsert to Supabase public.store_settings for maximum reliability
      try {
        await supabase.from('store_settings').upsert({
          id: 'default',
          store_name: payload.storeName,
          whatsapp_number: payload.whatsappNumber,
          support_phone: payload.supportPhone,
          email: payload.email,
          address: payload.address,
          city: payload.city,
          default_shipping_fee: payload.defaultShippingFee,
          free_shipping_min_amount: payload.freeShippingMinAmount,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'id' });
      } catch (supaErr) {
        console.warn('[AdminSettings] Supabase direct client upsert notice:', supaErr);
      }

      // 3. Update global context so header topbar, footer, and floating buttons update immediately
      await refreshSettings();

      setMessage('Configurações guardadas com sucesso no site e na base de dados Supabase! As alterações em email, morada e contactos já estão visíveis em toda a loja.');
      setTimeout(() => setMessage(''), 6000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao guardar configurações. Por favor, tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetCatalog = async () => {
    if (
      !confirm(
        'Tem a certeza que deseja restaurar o catálogo de demonstração para os artigos e fotos originais da CarcubaExpress?'
      )
    )
      return;

    try {
      await api.resetCatalog();
      setMessage('Catálogo reinicializado com sucesso!');
      await loadSettings();
      await refreshSettings();
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao restaurar catálogo');
    }
  };

  const updateMunicipalityFee = (index: number, newFeeStr: string) => {
    const updated = [...municipalities];
    updated[index] = { ...updated[index], fee: newFeeStr };
    setMunicipalities(updated);
  };

  if (isLoading || !settings) {
    return <div className="p-8 text-center text-xs text-slate-400">A carregar configurações...</div>;
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Configurações Gerais da Loja</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Defina contactos de WhatsApp, telefone, email, morada oficial e preçário de entregas em Luanda
          </p>
        </div>

        <button
          onClick={handleResetCatalog}
          className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs flex items-center gap-2 transition-colors self-start"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Restaurar Catálogo Oficial</span>
        </button>
      </div>

      {/* Supabase Cloud Database Integration Status */}
      <AdminSupabaseCard />

      {message && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2.5 animate-fade-in shadow-xs">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold leading-relaxed">{message}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2.5 animate-fade-in shadow-xs">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span className="font-semibold leading-relaxed">{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6 text-xs">
        {/* Contact info, Address & WhatsApp */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-amber-500" />
            <span>Dados da Loja, Contactos & Localização (Guardados no Site e Supabase)</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Nome da Loja:</label>
              <input
                type="text"
                value={storeName}
                onChange={e => setStoreName(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Número do WhatsApp para Envio de Pedidos:
              </label>
              <input
                type="text"
                placeholder="244951556411"
                value={whatsappNumber}
                onChange={e => setWhatsappNumber(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Formato com indicativo de Angola (ex: 244951556411)
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-amber-500" />
                <span>Telefone de Apoio / Contactos:</span>
              </label>
              <input
                type="text"
                value={supportPhone}
                onChange={e => setSupportPhone(e.target.value)}
                placeholder="+244 951 556 411"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-amber-500" />
                <span>Email de Contacto:</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="contacto@carcubaexpress.ao"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            {/* Address / Morada */}
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-500" />
                <span>Endereço / Morada da Loja (Apresentado no Rodapé e Contactos):</span>
              </label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                placeholder="Luanda, Angola (Entregas ao domicílio)"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Esta morada é apresentada no rodapé do site, na fatura PDF e nos dados oficiais da CarcubaExpress.
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Cidade Principal:</label>
              <input
                type="text"
                value={city}
                onChange={e => setCity(e.target.value)}
                placeholder="Luanda"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* Description & Store Presentation */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-500" />
            <span>Descrição & Apresentação da Loja (Apresentado no Rodapé)</span>
          </h3>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Texto de Apresentação / Slogan da CarcubaExpress:
            </label>
            <textarea
              rows={3}
              value={storeDescription}
              onChange={e => setStoreDescription(e.target.value)}
              placeholder="A sua loja online de referência em Luanda, Angola..."
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl leading-relaxed"
            />
            <span className="text-[10px] text-slate-400 mt-1 block">
              Este texto é apresentado sob o logótipo no rodapé e nas páginas institucionais da loja.
            </span>
          </div>
        </div>

        {/* Informações & Apoio ao Cliente (Políticas do Rodapé) */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-5">
          <div>
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-500" />
              <span>Textos de Informações & Apoio (Secção do Rodapé)</span>
            </h3>
            <p className="text-slate-500 text-xs mt-0.5">
              Edite os títulos e descrições das informações e políticas apresentadas aos clientes no rodapé do site.
            </p>
          </div>

          <div className="space-y-4">
            {/* Entregas em Luanda */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-2">
              <label className="block font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-amber-500" />
                <span>1. Entregas em Luanda & Municípios:</span>
              </label>
              <input
                type="text"
                value={deliveryPolicyTitle}
                onChange={e => setDeliveryPolicyTitle(e.target.value)}
                placeholder="Entregas em Luanda & Municípios"
                className="w-full p-2 bg-white border border-slate-200 rounded-lg font-semibold"
              />
              <textarea
                rows={2}
                value={deliveryPolicyText}
                onChange={e => setDeliveryPolicyText(e.target.value)}
                placeholder="Descrição das entregas, prazos e municípios atendidos..."
                className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            {/* Formas de Pagamento */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-2">
              <label className="block font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                <span>2. Formas de Pagamento (Apenas Dinheiro e Express):</span>
              </label>
              <input
                type="text"
                value={paymentPolicyTitle}
                onChange={e => setPaymentPolicyTitle(e.target.value)}
                placeholder="Formas de Pagamento (Apenas Dinheiro e Express)"
                className="w-full p-2 bg-white border border-slate-200 rounded-lg font-semibold"
              />
              <textarea
                rows={2}
                value={paymentPolicyText}
                onChange={e => setPaymentPolicyText(e.target.value)}
                placeholder="Descrição dos métodos de pagamento autorizados..."
                className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            {/* Termos e Condições */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-2">
              <label className="block font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-500" />
                <span>3. Termos e Condições de Compra:</span>
              </label>
              <input
                type="text"
                value={termsPolicyTitle}
                onChange={e => setTermsPolicyTitle(e.target.value)}
                placeholder="Termos e Condições de Compra"
                className="w-full p-2 bg-white border border-slate-200 rounded-lg font-semibold"
              />
              <textarea
                rows={2}
                value={termsPolicyText}
                onChange={e => setTermsPolicyText(e.target.value)}
                placeholder="Termos de garantia, trocas e inspecção na entrega..."
                className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            {/* Apoio ao Cliente */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-2">
              <label className="block font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <MessageCircle className="w-3.5 h-3.5 text-amber-500" />
                <span>4. Apoio ao Cliente & Contactos:</span>
              </label>
              <input
                type="text"
                value={supportPolicyTitle}
                onChange={e => setSupportPolicyTitle(e.target.value)}
                placeholder="Apoio ao Cliente & Contactos"
                className="w-full p-2 bg-white border border-slate-200 rounded-lg font-semibold"
              />
              <textarea
                rows={2}
                value={supportPolicyText}
                onChange={e => setSupportPolicyText(e.target.value)}
                placeholder="Horários de atendimento e canais de suporte..."
                className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>

        {/* Luanda Shipping Rates */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Truck className="w-4 h-4 text-amber-500" />
            <span>Tabela de Entregas por Município em Luanda</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-4 border-b border-slate-100">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Taxa Padrão de Entrega (Kz):
              </label>
              <input
                type="text"
                inputMode="decimal"
                placeholder="ex: 2000"
                value={defaultShippingFee}
                onChange={e => {
                  const val = e.target.value.replace(/[^0-9.,]/g, '');
                  setDefaultShippingFee(val);
                }}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Valor Mínimo para Entrega Grátis Automática (Kz):
              </label>
              <input
                type="text"
                inputMode="decimal"
                placeholder="ex: 40000"
                value={freeShippingMinAmount}
                onChange={e => {
                  const val = e.target.value.replace(/[^0-9.,]/g, '');
                  setFreeShippingMinAmount(val);
                }}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
              />
            </div>
          </div>

          <div className="space-y-2">
            <p className="font-semibold text-slate-700">Preçário por Região de Luanda:</p>
            <div className="space-y-2">
              {municipalities.map((m, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-900 truncate">{m.name}</p>
                    {m.estimatedHours ? (
                      <p className="text-[10px] text-slate-400">Previsão: {m.estimatedHours}</p>
                    ) : (
                      <p className="text-[10px] text-emerald-600 font-medium">Entrega direta sem taxas adicionais</p>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="text-slate-500">Taxa:</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder="0"
                      value={m.fee ?? ''}
                      onChange={e => {
                        const val = e.target.value.replace(/[^0-9.,]/g, '');
                        updateMunicipalityFee(idx, val);
                      }}
                      className="w-24 p-1.5 bg-white border border-slate-300 rounded-lg font-mono font-bold text-right"
                    />
                    <span className="font-bold text-slate-700">Kz</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="py-3 px-6 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl shadow-md flex items-center gap-2 active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'A guardar na Base de Dados...' : 'Guardar Alterações'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
