import React, { useState, useEffect } from 'react';
import { Users, Phone, Mail, Calendar, DollarSign, ShoppingBag, Search, RefreshCw, MessageCircle } from 'lucide-react';
import { api } from '../../services/api';
import type { CustomerData } from '../../types';

export const AdminCustomers: React.FC = () => {
  const [customers, setCustomers] = useState<CustomerData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const loadCustomers = async () => {
    setIsLoading(true);
    try {
      const res = await api.getCustomers();
      setCustomers(res.customers);
    } catch (err) {
      console.error('Erro ao carregar clientes:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const filtered = customers.filter(c => {
    const term = searchTerm.toLowerCase().trim();
    return (
      !term ||
      c.name.toLowerCase().includes(term) ||
      c.email.toLowerCase().includes(term) ||
      c.phone.includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Directório de Clientes Registados</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Acompanhe a base de clientes em Luanda, histórico de compras e valor gasto
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Pesquisar cliente ou telefone..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl w-60 text-slate-800"
            />
          </div>

          <button
            onClick={loadCustomers}
            className="p-2 bg-white text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl transition-colors"
            title="Atualizar"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            Nenhum cliente registado encontrado.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/50">
                  <th className="py-3 px-4">Cliente</th>
                  <th className="py-3 px-4">Contacto Telefónico</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4 text-center">Nº Encomendas</th>
                  <th className="py-3 px-4 text-right">Total Gasto (Kz)</th>
                  <th className="py-3 px-4">Data Registo</th>
                  <th className="py-3 px-4 text-center">Contacto</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {c.name}
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-700">
                      {c.phone}
                    </td>

                    <td className="py-3 px-4 text-slate-500">
                      {c.email}
                    </td>

                    <td className="py-3 px-4 text-center font-mono font-bold text-slate-800">
                      {c.ordersCount}
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-[#0B1E36] tabular-nums">
                      {c.totalSpent.toLocaleString('pt-AO')} Kz
                    </td>

                    <td className="py-3 px-4 text-slate-500">
                      {new Date(c.createdAt).toLocaleDateString('pt-PT')}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <a
                        href={`https://wa.me/${c.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                          `Olá ${c.name}! Entramos em contacto da CarcubaExpress Comércio.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 inline-block text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        title="Conversar no WhatsApp"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
