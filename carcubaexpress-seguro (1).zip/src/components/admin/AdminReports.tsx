import React, { useState, useEffect } from 'react';
import { Download, Printer, BarChart2, PieChart, RefreshCw, FileSpreadsheet, Check, Calendar } from 'lucide-react';
import { api } from '../../services/api';
import type { FinancialSummary } from '../../types';
import { generateFinancialPDF } from '../../utils/pdfExport';

export const AdminReports: React.FC = () => {
  const [summary, setSummary] = useState<FinancialSummary | null>(null);
  const [period, setPeriod] = useState<'all' | 'today' | '7d' | '30d'>('all');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const loadReport = async () => {
    setIsLoading(true);
    try {
      const res = selectedDate
        ? await api.getFinancialSummary({ date: selectedDate })
        : await api.getFinancialSummary(period);
      setSummary(res);
    } catch (err) {
      console.error('Erro ao carregar relatório:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [period, selectedDate]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    if (!summary) return;
    try {
      generateFinancialPDF(summary, undefined, selectedDate || undefined);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao gerar PDF:', err);
      handlePrint();
    }
  };

  // Download printable HTML report file directly to phone or computer
  const handleDownloadReport = () => {
    if (!summary) return;
    const dateStr = new Date().toLocaleDateString('pt-PT');
    const isoDate = new Date().toISOString().slice(0, 10);

    const htmlContent = `<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <title>Relatório CarcubaExpress - ${dateStr}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; padding: 24px; color: #0F172A; max-width: 800px; margin: 0 auto; background: #fff; line-height: 1.5; }
    .header { border-bottom: 2px solid #0B1E36; padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-start; }
    h1 { color: #0B1E36; margin: 0; font-size: 22px; font-weight: 800; }
    .gold { color: #D97706; }
    .subtitle { color: #64748B; font-size: 12px; margin-top: 4px; }
    .meta { font-size: 12px; color: #475569; text-align: right; }
    h2 { font-size: 14px; color: #0B1E36; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 1px solid #E2E8F0; padding-bottom: 6px; margin-top: 24px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 20px; font-size: 13px; }
    th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #E2E8F0; }
    th { background: #F8FAFC; color: #334155; font-weight: 700; }
    .text-right { text-align: right; }
    .highlight { background: #FEF3C7; font-weight: bold; }
    .positive { color: #059669; font-weight: bold; }
    .negative { color: #DC2626; font-weight: bold; }
    .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-top: 12px; }
    .card { background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 10px; padding: 12px; }
    .card-label { font-size: 11px; color: #64748B; display: block; }
    .card-val { font-size: 18px; font-weight: 800; color: #0B1E36; margin-top: 4px; font-family: monospace; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #E2E8F0; font-size: 11px; color: #94A3B8; text-align: center; }
    @media print { body { padding: 0; } }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1>Carcuba<span class="gold">Express</span> Comércio</h1>
      <p class="subtitle">Relatório Financeiro & Operacional · Luanda, Angola</p>
    </div>
    <div class="meta">
      <p><strong>Emissão:</strong> ${dateStr}</p>
      <p><strong>Moeda:</strong> Kwanza Angolano (Kz)</p>
    </div>
  </div>

  <h2>1. Desempenho Financeiro Global</h2>
  <table>
    <tbody>
      <tr>
        <td>Receita Total de Vendas Activas</td>
        <td class="text-right"><strong>${(summary.totalRevenue || 0).toLocaleString('pt-AO')} Kz</strong></td>
      </tr>
      <tr>
        <td>Receita com Pagamento Confirmado</td>
        <td class="text-right positive">${(summary.confirmedPaidRevenue || 0).toLocaleString('pt-AO')} Kz</td>
      </tr>
      <tr>
        <td>Custo Total das Mercadorias (CPV)</td>
        <td class="text-right negative">-${(summary.cogsTotal || 0).toLocaleString('pt-AO')} Kz</td>
      </tr>
      <tr>
        <td>Despesas Operacionais Registadas</td>
        <td class="text-right negative">-${(summary.totalExpenses || 0).toLocaleString('pt-AO')} Kz</td>
      </tr>
      <tr class="highlight">
        <td>Lucro Líquido Estimado</td>
        <td class="text-right positive" style="font-size: 15px;">${(summary.estimatedNetProfit || 0).toLocaleString('pt-AO')} Kz</td>
      </tr>
    </tbody>
  </table>

  <h2>2. Vendas por Departamento / Categoria</h2>
  <table>
    <thead>
      <tr>
        <th>Categoria</th>
        <th class="text-right">Unidades Vendidas</th>
        <th class="text-right">Total Faturado</th>
      </tr>
    </thead>
    <tbody>
      ${summary.categorySales.map(cat => `
        <tr>
          <td>${cat.name}</td>
          <td class="text-right">${cat.unitsSold} un.</td>
          <td class="text-right"><strong>${cat.totalSales.toLocaleString('pt-AO')} Kz</strong></td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <h2>3. Balanço de Pedidos & Entregas em Luanda</h2>
  <div class="card-grid">
    <div class="card">
      <span class="card-label">Total de Pedidos</span>
      <span class="card-val">${summary.statusCounts.total || 0}</span>
    </div>
    <div class="card">
      <span class="card-label">Entregues com Sucesso</span>
      <span class="card-val" style="color: #059669;">${summary.statusCounts.entregues || 0}</span>
    </div>
    <div class="card">
      <span class="card-label">Em Transporte</span>
      <span class="card-val" style="color: #2563EB;">${summary.statusCounts.emTransporte || 0}</span>
    </div>
    <div class="card">
      <span class="card-label">Cancelados</span>
      <span class="card-val" style="color: #DC2626;">${summary.statusCounts.cancelados || 0}</span>
    </div>
  </div>

  <div class="footer">
    CarcubaExpress Comércio · Relatório emitido automaticamente pelo Painel Administrativo.
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Relatorio_CarcubaExpress_${isoDate}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  // Download Excel / CSV data
  const handleDownloadCSV = () => {
    if (!summary) return;
    const isoDate = new Date().toISOString().slice(0, 10);

    const rows = [
      ['RELATÓRIO FINANCEIRO E OPERACIONAL - CARCUBAEXPRESS COMÉRCIO'],
      ['Data de Emissão', new Date().toLocaleDateString('pt-PT')],
      ['Moeda', 'Kwanza Angolano (Kz)'],
      [],
      ['INDICADOR FINANCEIRO', 'VALOR (Kz)'],
      ['Receita Total de Vendas Activas', summary.totalRevenue || 0],
      ['Receita com Pagamento Confirmado', summary.confirmedPaidRevenue || 0],
      ['Custo Total das Mercadorias (CPV)', -(summary.cogsTotal || 0)],
      ['Despesas Operacionais Registadas', -(summary.totalExpenses || 0)],
      ['Lucro Líquido Estimado', summary.estimatedNetProfit || 0],
      [],
      ['CATEGORIA', 'UNIDADES VENDIDAS', 'TOTAL (Kz)'],
      ...summary.categorySales.map(c => [c.name, c.unitsSold, c.totalSales]),
      [],
      ['PEDIDOS', 'QUANTIDADE'],
      ['Total de Pedidos', summary.statusCounts.total || 0],
      ['Entregues com Sucesso', summary.statusCounts.entregues || 0],
      ['Em Transporte', summary.statusCounts.emTransporte || 0],
      ['Cancelados', summary.statusCounts.cancelados || 0],
    ];

    const csvContent = '\uFEFF' + rows.map(e => e.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(';')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Dados_CarcubaExpress_${isoDate}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Relatórios Gerenciais e de Vendas</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Relatório consolidado de desempenho comercial da CarcubaExpress Comércio
          </p>
        </div>

        {/* Action buttons: Date picker, Download PDF, Download CSV, and Print */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Day Date Picker */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="text-[11px] font-semibold text-slate-600 whitespace-nowrap">Dia:</span>
            <input
              type="date"
              value={selectedDate}
              onChange={e => {
                setSelectedDate(e.target.value);
                if (e.target.value) setPeriod('all');
              }}
              className="text-xs font-semibold text-slate-800 bg-transparent focus:outline-none cursor-pointer font-mono"
              title="Selecione o dia específico para o relatório de vendas"
            />
            {selectedDate && (
              <button
                onClick={() => setSelectedDate('')}
                className="text-[11px] font-bold text-rose-500 hover:text-rose-700 ml-1 px-1 cursor-pointer"
                title="Limpar seleção e ver geral"
              >
                ✕
              </button>
            )}
          </div>

          {/* Quick period buttons */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => {
                setSelectedDate('');
                setPeriod('all');
              }}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                !selectedDate && period === 'all'
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Geral
            </button>
            <button
              onClick={() => {
                const today = new Date().toISOString().split('T')[0];
                setSelectedDate(today);
              }}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                selectedDate === new Date().toISOString().split('T')[0]
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hoje
            </button>
            <button
              onClick={() => {
                setSelectedDate('');
                setPeriod('7d');
              }}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                !selectedDate && period === '7d'
                  ? 'bg-[#0B1E36] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              7 Dias
            </button>
          </div>

          <button
            onClick={handleDownloadPDF}
            className="py-2 px-3.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer active:scale-95"
            title="Baixar ficheiro em formato PDF para o seu telefone ou computador"
          >
            {downloadSuccess ? <Check className="w-4 h-4 text-emerald-950" /> : <Download className="w-4 h-4" />}
            <span>Baixar PDF</span>
          </button>

          <button
            onClick={handleDownloadCSV}
            className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Exportar dados para Excel / Folha de Cálculo"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Excel / CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="py-2 px-3 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            title="Imprimir ou Guardar como PDF"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Imprimir</span>
          </button>

          <button
            onClick={loadReport}
            className="p-2 bg-white text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl cursor-pointer"
            title="Atualizar dados"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Printable / Viewable Report Sheet */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 text-xs">
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-slate-200">
          <div>
            <h3 className="text-lg font-black text-[#0B1E36] tracking-tight">
              Carcuba<span className="text-amber-500">Express</span> Comércio
            </h3>
            <p className="text-slate-500 text-xs">Relatório Financeiro & Operacional · Luanda, Angola</p>
          </div>
          <div className="text-right text-slate-400">
            <p>Data de Emissão: {new Date().toLocaleDateString('pt-PT')}</p>
            <p>Moeda: Kwanza Angolano (Kz)</p>
          </div>
        </div>

        {/* Financial Recap Table */}
        <div>
          <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-3">
            1. Desempenho Financeiro Global
          </h4>
          <table className="w-full text-left border border-slate-200 rounded-xl overflow-hidden">
            <tbody className="divide-y divide-slate-100">
              <tr className="bg-slate-50">
                <td className="py-2.5 px-4 font-semibold text-slate-700">Receita Total de Vendas Activas</td>
                <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                  {(summary?.totalRevenue || 0).toLocaleString('pt-AO')} Kz
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-700">Receita com Pagamento Confirmado</td>
                <td className="py-2.5 px-4 text-right font-mono font-bold text-emerald-600 tabular-nums">
                  {(summary?.confirmedPaidRevenue || 0).toLocaleString('pt-AO')} Kz
                </td>
              </tr>
              <tr className="bg-slate-50">
                <td className="py-2.5 px-4 font-semibold text-slate-700">Custo Total das Mercadorias (CPV)</td>
                <td className="py-2.5 px-4 text-right font-mono font-bold text-amber-600 tabular-nums">
                  -{(summary?.cogsTotal || 0).toLocaleString('pt-AO')} Kz
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-slate-700">Despesas Operacionais Registadas</td>
                <td className="py-2.5 px-4 text-right font-mono font-bold text-rose-600 tabular-nums">
                  -{(summary?.totalExpenses || 0).toLocaleString('pt-AO')} Kz
                </td>
              </tr>
              <tr className="bg-amber-50/60 font-bold">
                <td className="py-3 px-4 text-slate-900">Lucro Líquido Estimado</td>
                <td className="py-3 px-4 text-right font-mono text-emerald-700 text-sm tabular-nums">
                  {(summary?.estimatedNetProfit || 0).toLocaleString('pt-AO')} Kz
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Category Breakdown */}
        <div>
          <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-3">
            2. Vendas por Departamento / Categoria
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {summary?.categorySales.map((cat, i) => (
              <div key={i} className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="font-semibold text-slate-800 block truncate">{cat.name}</span>
                <div className="flex justify-between items-baseline mt-1 text-slate-600">
                  <span>{cat.unitsSold} unidade(s)</span>
                  <span className="font-mono font-bold text-[#0B1E36] tabular-nums">
                    {cat.totalSales.toLocaleString('pt-AO')} Kz
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Status Distribution */}
        <div>
          <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-3">
            3. Balanço de Pedidos & Entregas
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-500 block">Total de Pedidos</span>
              <span className="text-base font-bold font-mono text-slate-900">
                {summary?.statusCounts.total || 0}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-500 block">Entregues com Sucesso</span>
              <span className="text-base font-bold font-mono text-emerald-600">
                {summary?.statusCounts.entregues || 0}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-500 block">Em Transporte</span>
              <span className="text-base font-bold font-mono text-blue-600">
                {summary?.statusCounts.emTransporte || 0}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-500 block">Cancelados</span>
              <span className="text-base font-bold font-mono text-rose-600">
                {summary?.statusCounts.cancelados || 0}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
