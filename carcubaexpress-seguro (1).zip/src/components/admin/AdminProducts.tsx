import React, { useState, useEffect } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Check,
  X,
  Package,
  Layers,
  Image as ImageIcon,
  DollarSign,
  AlertCircle,
  RefreshCw,
  Power,
  Camera,
  FolderOpen,
  ImagePlus,
  Truck,
} from 'lucide-react';
import { api } from '../../services/api';
import type { Product, Category } from '../../types';

interface AdminProductsProps {
  initialOpenNewModal?: boolean;
  onResetNewModalFlag?: () => void;
}

export const AdminProducts: React.FC<AdminProductsProps> = ({
  initialOpenNewModal = false,
  onResetNewModalFlag,
}) => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('carcuba_cached_products_v2');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('carcuba_cached_categories_v2');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isLoading, setIsLoading] = useState(() => {
    try {
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('carcuba_cached_products_v2');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return false;
        }
      }
    } catch {
      // ignore
    }
    return true;
  });

  // Edit / Create modal state
  const [isModalOpen, setIsModalOpen] = useState(initialOpenNewModal);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form states (using strings so fields can be cleared and edited without sticky zeros)
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<string>('');
  const [costPrice, setCostPrice] = useState<string>('');
  const [promoPrice, setPromoPrice] = useState<string>('');
  const [stock, setStock] = useState<string>('10');
  const [categoryId, setCategoryId] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [customColorInput, setCustomColorInput] = useState('');
  const [freeShipping, setFreeShipping] = useState(false);
  const [shippingFee, setShippingFee] = useState<string>('2000');
  const [shippingFeeLabel, setShippingFeeLabel] = useState<string>('');
  const [isFeatured, setIsFeatured] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isClearingAll, setIsClearingAll] = useState(false);

  // Gallery file picker & image compression state
  const fileInputRef = React.useRef<HTMLInputElement | null>(null);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [showManualUrl, setShowManualUrl] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Por favor, selecione um ficheiro de imagem válido (JPG, PNG, WEBP).');
      return;
    }

    setIsProcessingImage(true);
    setFormError('');

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Downscale image to max 800px at 0.75 quality for lightning-fast saving and rendering
        const maxDimension = 800;
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.75);
          setImageUrl(compressedDataUrl);
        } else {
          setImageUrl(event.target?.result as string);
        }
        setIsProcessingImage(false);
      };
      img.onerror = () => {
        setImageUrl(event.target?.result as string);
        setIsProcessingImage(false);
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      setFormError('Erro ao abrir a fotografia da galeria.');
      setIsProcessingImage(false);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const toggleSize = (sz: string) => {
    setSelectedSizes(prev =>
      prev.includes(sz) ? prev.filter(s => s !== sz) : [...prev, sz]
    );
  };

  const handleAddColor = () => {
    const trimmed = customColorInput.trim();
    if (!trimmed) return;
    if (!selectedColors.includes(trimmed)) {
      setSelectedColors(prev => [...prev, trimmed]);
    }
    setCustomColorInput('');
  };

  const handleTogglePresetColor = (col: string) => {
    if (selectedColors.includes(col)) {
      setSelectedColors(prev => prev.filter(c => c !== col));
    } else {
      setSelectedColors(prev => [...prev, col]);
    }
  };

  const removeColor = (col: string) => {
    setSelectedColors(prev => prev.filter(c => c !== col));
  };

  // Delete confirmation modal state
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  const loadData = async () => {
    if (products.length === 0) {
      setIsLoading(true);
    }
    try {
      const [prodRes, catRes] = await Promise.all([
        api.getProducts({ activeOnly: false }),
        api.getCategories(),
      ]);
      setProducts(prodRes.products);
      setCategories(catRes.categories);
      if (catRes.categories.length > 0 && !categoryId) {
        setCategoryId(catRes.categories[0].id);
      }
    } catch (err) {
      console.error('Erro ao carregar produtos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (initialOpenNewModal) {
      openCreateModal();
      if (onResetNewModalFlag) onResetNewModalFlag();
    }
  }, [initialOpenNewModal]);

  const openCreateModal = () => {
    setEditingProduct(null);
    setName('');
    setDescription('');
    setPrice('');
    setCostPrice('');
    setPromoPrice('');
    setStock('10');
    setCategoryId(categories[0]?.id || 'cat-eletronicos');
    setImageUrl('');
    setSelectedSizes([]);
    setSelectedColors([]);
    setCustomColorInput('');
    setShowManualUrl(false);
    setFreeShipping(false);
    setShippingFee('2000');
    setShippingFeeLabel('');
    setIsFeatured(false);
    setIsActive(true);
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setDescription(p.description || '');
    setPrice(p.price ? String(p.price) : '');
    setCostPrice(p.costPrice !== undefined ? String(p.costPrice) : '');
    setPromoPrice(p.promoPrice ? String(p.promoPrice) : '');
    setStock(p.stock !== undefined ? String(p.stock) : '0');

    let initialCatId = p.categoryId;
    const lower = (p.name || '').toLowerCase();
    if (
      !initialCatId ||
      initialCatId === 'cat-eletronicos' &&
        (lower.includes('asad') || lower.includes('lattafa') || lower.includes('perfum'))
    ) {
      // Find matching perfume category in categories
      const perfCat = categories.find(
        c =>
          c.id.includes('perfum') ||
          c.name.toLowerCase().includes('perfum') ||
          c.slug.includes('perfum')
      );
      initialCatId = perfCat ? perfCat.id : 'perfumaria';
    }
    setCategoryId(initialCatId || categories[0]?.id || 'perfumaria');

    setImageUrl(p.images[0] || '');
    setSelectedSizes(p.sizes || []);
    setSelectedColors(p.colors || []);
    setCustomColorInput('');
    setShowManualUrl(false);
    setFreeShipping(p.freeShipping);
    setShippingFee(p.shippingFee !== undefined && p.shippingFee !== null ? String(p.shippingFee) : '2000');
    setShippingFeeLabel(p.shippingFeeLabel || '');
    setIsFeatured(p.isFeatured);
    setIsActive(p.isActive);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const numericPrice = Number(price);
    const numericCostPrice = costPrice.trim() === '' ? 0 : Number(costPrice);
    const numericStock = stock.trim() === '' ? 0 : Number(stock);
    const numericPromo = promoPrice.trim() !== '' ? Number(promoPrice) : undefined;
    const numericShippingFee = !freeShipping && shippingFee.trim() !== '' ? Number(shippingFee) : undefined;
    const cleanShippingLabel = !freeShipping && shippingFeeLabel.trim() !== '' ? shippingFeeLabel.trim() : undefined;

    if (!name.trim()) {
      setFormError('O nome do produto é obrigatório.');
      return;
    }
    if (isNaN(numericPrice) || numericPrice <= 0) {
      setFormError('O preço de venda deve ser maior que zero.');
      return;
    }
    if (isNaN(numericCostPrice) || numericCostPrice < 0) {
      setFormError('O custo do produto (CPV) não pode ser negativo.');
      return;
    }
    if (isNaN(numericStock) || numericStock < 0) {
      setFormError('O stock não pode ser negativo.');
      return;
    }
    if (!freeShipping && numericShippingFee !== undefined && (isNaN(numericShippingFee) || numericShippingFee < 0)) {
      setFormError('A taxa de entrega adicional deve ser um valor numérico válido.');
      return;
    }
    if (!imageUrl.trim()) {
      setFormError('Por favor, abra a sua galeria para anexar uma foto ao produto.');
      return;
    }

    setIsSaving(true);
    try {
      const selectedCategoryObj = categories.find(c => c.id === categoryId);
      const isPerfumeCat =
        categoryId.includes('perfum') ||
        categoryId.includes('fragr') ||
        name.toLowerCase().includes('asad') ||
        name.toLowerCase().includes('lattafa') ||
        name.toLowerCase().includes('perfume');

      const chosenCategoryName = selectedCategoryObj?.name
        ? selectedCategoryObj.name
        : isPerfumeCat
        ? 'Perfumes & fragrância'
        : categoryId === 'audio'
        ? 'Áudio & Gravação'
        : 'Eletrónicos & Som';

      const payload: Partial<Product> = {
        name: name.trim(),
        description: description.trim(),
        price: numericPrice,
        costPrice: numericCostPrice,
        promoPrice: numericPromo,
        stock: numericStock,
        categoryId: isPerfumeCat && !categoryId.includes('perfum') ? 'cat-perfumes-e-fragrancia' : categoryId,
        categoryName: chosenCategoryName,
        images: [imageUrl.trim() || '/assets/aistudio/mic-circular_f8930c2d.jpg'],
        sizes: selectedSizes,
        colors: selectedColors,
        freeShipping,
        shippingFee: numericShippingFee,
        shippingFeeLabel: cleanShippingLabel,
        isFeatured,
        isActive,
      };

      if (editingProduct) {
        const updatedProd: Product = {
          ...editingProduct,
          ...payload,
        } as Product;
        // Atualização instantânea na interface (0ms de latência)
        setProducts(prev => prev.map(p => p.id === editingProduct.id ? updatedProd : p));
        setIsModalOpen(false);
        setSuccessMessage(`Produto "${payload.name}" atualizado com sucesso!`);
        setTimeout(() => setSuccessMessage(''), 4000);

        api.updateProduct(editingProduct.id, payload).catch(err => {
          console.error('[AdminProducts Update Error]:', err);
          loadData();
        });
      } else {
        const optimisticId = `prod-${Date.now()}`;
        const newProd: Product = {
          id: optimisticId,
          slug: payload.name?.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'produto',
          createdAt: new Date().toISOString(),
          ...payload,
        } as Product;
        // Adição instantânea na lista sem congelar a interface
        setProducts(prev => [newProd, ...prev]);
        setIsModalOpen(false);
        setSuccessMessage(`Produto "${payload.name}" publicado com sucesso!`);
        setTimeout(() => setSuccessMessage(''), 4000);

        api.createProduct(payload).then(res => {
          if (res.product) {
            setProducts(prev => prev.map(p => p.id === optimisticId ? res.product : p));
          }
        }).catch(err => {
          console.error('[AdminProducts Create Error]:', err);
          loadData();
        });
      }
    } catch (err: any) {
      console.error('[AdminProducts] Falha ao processar produto:', err);
      setFormError(err.message || 'Erro ao guardar produto.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleProduct = async (p: Product) => {
    const nextState = !p.isActive;
    // Resposta instantânea na interface
    setProducts(prev => prev.map(item => item.id === p.id ? { ...item, isActive: nextState } : item));
    try {
      await api.toggleProduct(p.id);
    } catch (err: any) {
      // Reverter se a chamada falhar
      setProducts(prev => prev.map(item => item.id === p.id ? { ...item, isActive: !nextState } : item));
      alert(err.message || 'Erro ao alternar estado do produto');
    }
  };

  const handleDeleteProduct = async () => {
    if (!productToDelete) return;
    const targetId = productToDelete.id;
    const targetName = productToDelete.name;
    const prevProducts = [...products];

    // Remoção instantânea da lista (0ms de latência)
    setProducts(prev => prev.filter(item => item.id !== targetId));
    setProductToDelete(null);
    setSuccessMessage(`Produto "${targetName}" eliminado.`);
    setTimeout(() => setSuccessMessage(''), 4000);

    try {
      await api.deleteProduct(targetId);
    } catch (err: any) {
      setProducts(prevProducts);
      alert(err.message || 'Erro ao eliminar produto');
    }
  };

  const handleClearAllProducts = async () => {
    setIsClearingAll(true);
    try {
      const res = await api.clearAllProducts();
      setSuccessMessage(res.message || 'Todos os produtos foram removidos da loja e da base de dados Supabase.');
      setIsClearModalOpen(false);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao remover produtos');
    } finally {
      setIsClearingAll(false);
    }
  };

  // Filtered products
  const filteredProducts = products.filter(p => {
    const matchesCategory =
      selectedCategory === 'all' ||
      p.categoryId === selectedCategory ||
      p.categoryName?.toLowerCase() === selectedCategory.toLowerCase() ||
      (selectedCategory === 'perfumaria' &&
        (p.name.toLowerCase().includes('asad') ||
          p.name.toLowerCase().includes('lattafa') ||
          p.name.toLowerCase().includes('perfum')));
    const term = searchTerm.toLowerCase().trim();
    const matchesSearch =
      !term ||
      p.name.toLowerCase().includes(term) ||
      p.description.toLowerCase().includes(term) ||
      p.categoryName.toLowerCase().includes(term);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Catálogo de Produtos da Loja</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Adicione artigos, defina preços de venda e custos (CPV) e controle inventário
          </p>
        </div>

        <div className="flex items-center gap-2">
          {products.length > 0 && (
            <button
              onClick={() => setIsClearModalOpen(true)}
              className="py-2.5 px-3.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-rose-200"
              title="Remover todos os produtos da loja e do Supabase para começar do zero"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Remover Todos os Produtos</span>
            </button>
          )}

          <button
            onClick={openCreateModal}
            className="py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs flex items-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Novo Produto</span>
          </button>
        </div>
      </div>

      {/* Success Notification Banner */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-800 flex items-center justify-between shadow-sm animate-fade-in">
          <div className="flex items-center gap-2.5">
            <Check className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="font-semibold">{successMessage}</span>
          </div>
          <button
            onClick={() => setSuccessMessage('')}
            className="text-emerald-700 hover:text-emerald-950 font-bold text-sm ml-2 px-1 cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Pesquisar produto pelo nome..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full sm:w-72 text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 whitespace-nowrap">Categoria:</span>
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Todas as Categorias</option>
            {categories.map(c => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <button
            onClick={loadData}
            className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-600 hover:text-slate-900"
            title="Atualizar"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredProducts.length === 0 ? (
          <div className="p-16 text-center space-y-4 max-w-md mx-auto">
            <div className="w-16 h-16 rounded-3xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto shadow-2xs">
              <Package className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900">
                {products.length === 0 ? 'Catálogo Pronto para Novos Produtos' : 'Nenhum produto encontrado com os filtros'}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                {products.length === 0
                  ? 'A loja está limpa. Pode agora adicionar e editar todos os seus produtos manualmente, definindo imagens, preços em Kwanza (Kz) e custos (CPV).'
                  : 'Tente alterar os termos de pesquisa ou selecionar outra categoria.'}
              </p>
            </div>
            {products.length === 0 && (
              <button
                onClick={openCreateModal}
                className="mt-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs inline-flex items-center gap-2 shadow-md cursor-pointer active:scale-95 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Adicionar Primeiro Produto</span>
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/50">
                  <th className="py-3.5 px-4">Artigo</th>
                  <th className="py-3.5 px-4">Categoria</th>
                  <th className="py-3.5 px-4 text-right">Preço de Venda</th>
                  <th className="py-3.5 px-4 text-right">Custo (CPV)</th>
                  <th className="py-3.5 px-4 text-right">Margem Unitária</th>
                  <th className="py-3.5 px-4 text-center">Stock</th>
                  <th className="py-3.5 px-4 text-center">Entrega Grátis</th>
                  <th className="py-3.5 px-4 text-center">Estado</th>
                  <th className="py-3.5 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProducts.map(p => {
                  const unitMargin = p.price - (p.costPrice || 0);
                  const marginPercent = p.price > 0 ? Math.round((unitMargin / p.price) * 100) : 0;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
                            alt={p.name}
                            referrerPolicy="no-referrer"
                            className="w-12 h-12 object-cover rounded-lg bg-slate-100 shrink-0 border border-slate-200"
                          />
                          <div className="min-w-0 max-w-xs">
                            <p className="font-semibold text-slate-900 truncate">{p.name}</p>
                            {p.promoPrice && p.promoPrice > p.price && (
                              <p className="text-[10px] text-amber-600 font-medium">
                                Promoção (de {p.promoPrice.toLocaleString('pt-AO')} Kz)
                              </p>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-600">
                        <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-800 border border-slate-200">
                          {p.categoryName ||
                            categories.find(c => c.id === p.categoryId)?.name ||
                            (p.categoryId === 'perfumaria' ? 'Perfumaria & Fragrâncias' : 'Eletrónicos & Som')}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {p.price.toLocaleString('pt-AO')} Kz
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-slate-500 tabular-nums">
                        {(p.costPrice || 0).toLocaleString('pt-AO')} Kz
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                        <span className="text-emerald-700 font-semibold block">
                          +{unitMargin.toLocaleString('pt-AO')} Kz
                        </span>
                        <span className="text-[10px] text-slate-400">({marginPercent}%)</span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
                            p.stock <= 0
                              ? 'bg-rose-100 text-rose-800'
                              : p.stock <= 5
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {p.stock} un.
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        {p.freeShipping ? (
                          <span className="inline-block px-2 py-0.5 bg-emerald-50 text-emerald-700 font-semibold rounded text-[10px] border border-emerald-200">
                            Grátis
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Normal</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => handleToggleProduct(p)}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold transition-colors ${
                            p.isActive
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                              : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                          }`}
                          title="Clique para alternar activo/inactivo"
                        >
                          <Power className="w-3 h-3" />
                          <span>{p.isActive ? 'Activo' : 'Inactivo'}</span>
                        </button>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => openEditModal(p)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                            title="Editar Produto"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => setProductToDelete(p)}
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Eliminar Produto"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div
            className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8 animate-scale-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-6 bg-[#0B1E36] text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src="/assets/aistudio/logo_a1884a32.jpg"
                  alt="CarcubaExpress"
                  className="w-10 h-10 rounded-full object-contain bg-white p-0.5 border border-amber-400 shrink-0"
                />
                <div>
                  <h3 className="text-base font-bold">
                    {editingProduct ? 'Editar Produto' : 'Adicionar Novo Produto'}
                  </h3>
                  <p className="text-xs text-slate-300">CarcubaExpress Comércio</p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              {formError && (
                <div className="p-4 bg-rose-50 border-2 border-rose-300 rounded-2xl text-xs text-rose-800 space-y-1.5 animate-shake">
                  <div className="flex items-center gap-2 font-bold text-rose-900">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>Aviso do Supabase ao Gravar:</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-rose-700 whitespace-pre-wrap">{formError}</p>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nome do Produto <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Microfone Circular Wireless Duplo LCD"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Categoria <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={categoryId}
                    onChange={e => setCategoryId(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Quantidade em Stock <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    placeholder="ex: 15"
                    value={stock}
                    onChange={e => setStock(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs font-mono"
                  />
                </div>
              </div>

              {/* Financial fields: Price, Cost, Promo */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Preço de Venda (Kz) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    placeholder="ex: 15000"
                    value={price}
                    onChange={e => setPrice(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl text-slate-900 text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Custo de Aquisição / CPV (Kz)
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="ex: 8500"
                    value={costPrice}
                    onChange={e => setCostPrice(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl text-slate-900 text-xs font-mono"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Custo unitário para apurar o lucro
                  </span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Preço Promocional (riscado)
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="ex: 18000 (opcional)"
                    value={promoPrice}
                    onChange={e => setPromoPrice(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl text-slate-900 text-xs font-mono"
                  />
                </div>
              </div>

              {/* Variations: Sizes & Colors (Ideal for Clothes / Footwear / Stock) */}
              <div className="space-y-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      <span>Tamanhos Disponíveis em Stock</span>
                      <span className="text-[10px] font-normal text-slate-500">(Roupas, Calçado, Vestuário)</span>
                    </label>
                    {selectedSizes.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setSelectedSizes([])}
                        className="text-[10px] text-rose-500 hover:text-rose-700 underline font-medium cursor-pointer"
                      >
                        Limpar tamanhos
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Clique nos tamanhos disponíveis para este artigo para que os clientes possam escolher na loja:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {['S', 'M', 'L', 'XL', '2XL'].map(sz => {
                      const isSelected = selectedSizes.includes(sz);
                      return (
                        <button
                          key={sz}
                          type="button"
                          onClick={() => toggleSize(sz)}
                          className={`px-3.5 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#0B1E36] text-amber-400 border border-amber-400 shadow-sm scale-105'
                              : 'bg-white text-slate-700 border border-slate-300 hover:border-slate-400'
                          }`}
                        >
                          {isSelected && '✓ '}
                          {sz}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-2.5 border-t border-slate-200">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      <span>Cores Disponíveis em Stock</span>
                      <span className="text-[10px] font-normal text-slate-500">(Roupas e Artigos com Cores)</span>
                    </label>
                    {selectedColors.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setSelectedColors([])}
                        className="text-[10px] text-rose-500 hover:text-rose-700 underline font-medium cursor-pointer"
                      >
                        Limpar cores
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Selecione as cores predefinidas ou digite uma cor personalizada:
                  </p>

                  {/* Preset colors */}
                  <div className="flex flex-wrap gap-1.5 mb-2.5">
                    {['Preto', 'Branco', 'Azul', 'Vermelho', 'Verde', 'Cinza', 'Castanho', 'Rosa', 'Bege', 'Amarelo'].map(col => {
                      const isSelected = selectedColors.includes(col);
                      return (
                        <button
                          key={col}
                          type="button"
                          onClick={() => handleTogglePresetColor(col)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500 text-slate-900 font-bold shadow-xs'
                              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {isSelected && '✓ '}
                          {col}
                        </button>
                      );
                    })}
                  </div>

                  {/* Custom color input */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Outra cor (ex: Bordô, Dourado, Estampado)..."
                      value={customColorInput}
                      onChange={e => setCustomColorInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddColor();
                        }
                      }}
                      className="flex-1 p-2 bg-white border border-slate-200 rounded-xl text-slate-900 text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleAddColor}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs shrink-0 cursor-pointer"
                    >
                      + Adicionar Cor
                    </button>
                  </div>

                  {/* Active selected colors badges */}
                  {selectedColors.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      <span className="text-[10px] text-slate-500 self-center">Cores ativas:</span>
                      {selectedColors.map(c => (
                        <span
                          key={c}
                          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300"
                        >
                          {c}
                          <button
                            type="button"
                            onClick={() => removeColor(c)}
                            className="hover:text-rose-600 cursor-pointer ml-0.5 font-bold"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Fotografia do Produto (Galeria do dispositivo ou catálogo) */}
              <div className="space-y-2 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-amber-500" />
                    <span>Fotografia do Artigo</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowManualUrl(!showManualUrl)}
                    className="text-[11px] text-amber-600 hover:text-amber-700 underline font-medium cursor-pointer"
                  >
                    {showManualUrl ? 'Ocultar opções avançadas' : 'Usar fotos de catálogo ou URL'}
                  </button>
                </div>

                {/* Hidden input to open phone gallery or file picker */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />

                {/* Active Image Preview & Gallery Button */}
                <div className="flex flex-col sm:flex-row items-center gap-3.5 bg-white p-3 rounded-xl border border-slate-200">
                  <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 shrink-0 flex items-center justify-center">
                    {imageUrl ? (
                      <img
                        src={imageUrl}
                        alt="Pré-visualização do produto"
                        className="w-full h-full object-contain p-1"
                      />
                    ) : (
                      <div className="text-center p-2 text-slate-400">
                        <ImageIcon className="w-6 h-6 mx-auto mb-1 opacity-50" />
                        <span className="text-[10px]">Sem foto</span>
                      </div>
                    )}
                    {isProcessingImage && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center text-white text-[10px] font-semibold text-center p-1">
                        A carregar foto...
                      </div>
                    )}
                  </div>

                  <div className="flex-1 w-full space-y-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isProcessingImage}
                      className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-900 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                    >
                      <FolderOpen className="w-4 h-4 text-slate-900" />
                      <span>{imageUrl ? 'Trocar Foto da Galeria' : 'Abrir Minha Galeria para Anexar Foto'}</span>
                    </button>

                    <p className="text-[11px] text-slate-500 text-center sm:text-left leading-tight">
                      Toque no botão para abrir a galeria de fotos do seu telemóvel ou anexar ficheiro da câmara.
                    </p>

                    {imageUrl && (
                      <div className="flex items-center justify-between pt-0.5">
                        <span className="text-[10px] text-emerald-700 font-medium flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-600" /> Foto anexada com sucesso
                        </span>
                        <button
                          type="button"
                          onClick={() => setImageUrl('')}
                          className="text-[10px] text-rose-500 hover:text-rose-700 hover:underline font-semibold cursor-pointer"
                        >
                          Remover foto
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Optional Collapsible URL / Predefined Catalog images */}
                {showManualUrl && (
                  <div className="pt-2 border-t border-slate-200 space-y-2">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600 mb-1 block">
                        Caminho ou URL da imagem (opcional):
                      </label>
                      <input
                        type="text"
                        placeholder="/assets/aistudio/... ou https://..."
                        value={imageUrl}
                        onChange={e => setImageUrl(e.target.value)}
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg text-slate-800 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Imagens CarcubaExpress disponíveis:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { name: 'Mic Circular (15mil)', path: '/assets/aistudio/mic-circular_f8930c2d.jpg' },
                          { name: 'Mic TX (12mil)', path: '/assets/aistudio/mic-quadrado_3e698234.jpg' },
                          { name: 'Perfume Asad (16mil)', path: '/assets/aistudio/IMG-20261018-WA0022_10800326.jpg' },
                          { name: 'Fato Esplêndido', path: '/assets/aistudio/IMG-20261018-WA0018_c938fd42.jpg' },
                          { name: 'Saia de Cetim', path: '/assets/aistudio/IMG-20261016-WA0005_6f29b8f5.jpg' },
                          { name: 'Pastas Térmicas', path: '/assets/aistudio/IMG-20261016-WA0010_1__25dd2c4e.jpg' },
                          { name: 'Bolsa Lacoste', path: '/assets/aistudio/IMG-20261016-WA0021_1__44c4422e.jpg' },
                          { name: 'Bodys Modeladores', path: '/assets/aistudio/IMG-20261018-WA0019_7f1d9e53.jpg' },
                          { name: 'Colete e Calções', path: '/assets/aistudio/IMG-20261018-WA0017_17e2271b.jpg' },
                        ].map(img => (
                          <button
                            key={img.path}
                            type="button"
                            onClick={() => setImageUrl(img.path)}
                            className="px-2 py-0.5 bg-white hover:bg-amber-100 text-slate-700 hover:text-amber-800 rounded border border-slate-200 text-[10px] font-medium transition-colors"
                          >
                            {img.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Descrição Completa do Artigo
                </label>
                <textarea
                  rows={3}
                  placeholder="Descreva as características, material, compatibilidade e uso..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={freeShipping}
                    onChange={e => setFreeShipping(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                  />
                  <span className="font-semibold text-slate-700">Entrega Grátis em Luanda</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={e => setIsFeatured(e.target.checked)}
                    className="w-4 h-4 text-amber-500 rounded focus:ring-amber-500"
                  />
                  <span className="font-semibold text-slate-700">Destaque na Página Inicial</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={e => setIsActive(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <span className="font-semibold text-slate-700">Visível na Loja (Activo)</span>
                </label>
              </div>

              {/* Etiqueta e Taxa Adicional de Entrega para produtos sem Frete Grátis */}
              {!freeShipping && (
                <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-2xl space-y-3 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-amber-600" />
                      <span>Taxa de Entrega Adicional & Etiqueta (Sem Frete Grátis)</span>
                    </label>
                    <span className="text-[10px] bg-amber-200/90 text-amber-950 font-bold px-2 py-0.5 rounded-full border border-amber-300">
                      Guardado no Supabase
                    </span>
                  </div>

                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    Como este produto não possui entrega grátis, defina o valor da taxa adicional e a etiqueta personalizada para exibição no catálogo e nos detalhes do artigo:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Valor da Taxa Adicional (Kz)
                      </label>
                      <input
                        type="number"
                        placeholder="ex: 2000"
                        value={shippingFee}
                        onChange={e => setShippingFee(e.target.value)}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl text-slate-900 text-xs font-mono font-bold focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Etiqueta Personalizada (opcional)
                      </label>
                      <input
                        type="text"
                        placeholder="ex: + Taxa de entrega: 2.000 Kz"
                        value={shippingFeeLabel}
                        onChange={e => setShippingFeeLabel(e.target.value)}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl text-slate-900 text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Atalhos Rápidos para Taxa */}
                  <div>
                    <span className="text-[10px] text-slate-600 font-semibold mr-2">Taxas sugeridas para Luanda:</span>
                    <div className="inline-flex flex-wrap gap-1.5 mt-1">
                      {[
                        { val: '1500', label: '+ 1.500 Kz' },
                        { val: '2000', label: '+ 2.000 Kz' },
                        { val: '2500', label: '+ 2.500 Kz' },
                        { val: '3000', label: '+ 3.000 Kz' },
                      ].map(preset => (
                        <button
                          key={preset.val}
                          type="button"
                          onClick={() => {
                            setShippingFee(preset.val);
                            setShippingFeeLabel(`+ Taxa de entrega: ${Number(preset.val).toLocaleString('pt-AO')} Kz`);
                          }}
                          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border transition-all cursor-pointer ${
                            shippingFee === preset.val
                              ? 'bg-amber-500 text-slate-900 border-amber-600 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-2">
                {editingProduct ? (
                  <button
                    type="button"
                    onClick={() => {
                      setProductToDelete(editingProduct);
                      setIsModalOpen(false);
                    }}
                    className="px-3.5 py-2 text-rose-600 hover:bg-rose-50 border border-rose-200 font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar Produto</span>
                  </button>
                ) : <div />}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl shadow-md active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    {isSaving ? 'A guardar...' : editingProduct ? 'Salvar Alterações' : 'Criar Produto'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-200 text-xs">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-slate-900">Confirmar Eliminação de Produto</h3>
              <p className="text-slate-500">
                Tem a certeza que deseja eliminar o produto <strong className="text-slate-800">"{productToDelete.name}"</strong>? Esta ação não pode ser desfeita.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setProductToDelete(null)}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleDeleteProduct}
                className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-md cursor-pointer"
              >
                Sim, Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Products Modal */}
      {isClearModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-200 text-xs">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1.5">
              <h3 className="text-base font-bold text-slate-900">Remover Todos os Produtos?</h3>
              <p className="text-slate-500">
                Esta ação irá remover todos os {products.length} artigos existentes do catálogo da loja e da base de dados Supabase para que possa adicionar os seus próprios produtos manualmente.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setIsClearModalOpen(false)}
                disabled={isClearingAll}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllProducts}
                disabled={isClearingAll}
                className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-md cursor-pointer disabled:opacity-50"
              >
                {isClearingAll ? 'A remover...' : 'Sim, Limpar Tudo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
