import React, { useState, useEffect } from 'react';
import {
  X,
  Mail,
  Lock,
  User,
  Phone,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
  CheckCircle2,
  Circle,
  Loader2,
  Shield,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export interface PasswordStrength {
  score: number;
  label: 'Muito Fraca' | 'Fraca' | 'Média' | 'Forte' | 'Excelente';
  barColor: string;
  textColor: string;
  hasLength: boolean;
  hasUpper: boolean;
  hasLower: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
  isStrong: boolean;
}

export function evaluatePasswordStrength(pass: string): PasswordStrength {
  const hasLength = pass.length >= 8;
  const hasUpper = /[A-Z]/.test(pass);
  const hasLower = /[a-z]/.test(pass);
  const hasNumber = /[0-9]/.test(pass);
  const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~` ]/.test(pass);

  let score = 0;
  if (pass.length > 0) {
    if (hasLength) score += 1;
    if (hasUpper && hasLower) score += 1;
    if (hasNumber) score += 1;
    if (hasSpecial) score += 1;
  }

  let label: PasswordStrength['label'] = 'Muito Fraca';
  let barColor = 'bg-rose-500';
  let textColor = 'text-rose-600';

  if (score === 0 || score === 1) {
    label = 'Muito Fraca';
    barColor = 'bg-rose-500';
    textColor = 'text-rose-600';
  } else if (score === 2) {
    label = 'Fraca';
    barColor = 'bg-orange-500';
    textColor = 'text-orange-600';
  } else if (score === 3) {
    label = 'Média';
    barColor = 'bg-amber-500';
    textColor = 'text-amber-600';
  } else if (score === 4) {
    if (pass.length >= 10) {
      label = 'Excelente';
      barColor = 'bg-emerald-600';
      textColor = 'text-emerald-700';
    } else {
      label = 'Forte';
      barColor = 'bg-emerald-500';
      textColor = 'text-emerald-600';
    }
  }

  const isStrong = hasLength && hasUpper && hasLower && hasNumber && hasSpecial;

  return {
    score,
    label,
    barColor,
    textColor,
    hasLength,
    hasUpper,
    hasLower,
    hasNumber,
    hasSpecial,
    isStrong,
  };
}

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdminLoginSuccess: () => void;
  onCustomerLoginSuccess: () => void;
  initialTab?: 'login' | 'register' | 'admin' | 'forgot';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAdminLoginSuccess,
  onCustomerLoginSuccess,
  initialTab = 'login',
}) => {
  const { login, register, signInWithOAuth, resetPasswordForEmail, user, logout } = useAuth();

  const [tab, setTab] = useState<'login' | 'register' | 'forgot'>(
    initialTab === 'register' ? 'register' : initialTab === 'forgot' ? 'forgot' : 'login'
  );
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Password visibility eye toggles
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showRegisterConfirmPassword, setShowRegisterConfirmPassword] = useState(false);

  // Real-time password strength calculation
  const registerPasswordStrength = evaluatePasswordStrength(password);

  // Synchronize initialTab when modal opens
  useEffect(() => {
    if (isOpen) {
      setTab(initialTab === 'register' ? 'register' : initialTab === 'forgot' ? 'forgot' : 'login');
      setError('');
      setSuccess('');
    }
  }, [isOpen, initialTab]);

  // Auto-redirect when user logs in via OAuth or updates
  useEffect(() => {
    if (user && isOpen) {
      const isOfficialAdmin = user.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com';
      setSuccess(`Bem-vindo, ${isOfficialAdmin ? 'Domingos Quissanga' : user.name}! Sessão iniciada.`);
      const timer = setTimeout(() => {
        onClose();
        if (isOfficialAdmin) {
          onAdminLoginSuccess();
        } else {
          onCustomerLoginSuccess();
        }
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [user, isOpen, onClose, onAdminLoginSuccess, onCustomerLoginSuccess]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    try {
      const loggedUser = await login(email, password, false);
      const isOfficialAdmin = loggedUser.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com';

      if (isOfficialAdmin) {
        setSuccess(`Bem-vindo, Administrador Domingos Quissanga! A abrir o painel...`);
        setTimeout(() => {
          onClose();
          onAdminLoginSuccess();
        }, 600);
      } else {
        setSuccess(`Bem-vindo, ${loggedUser.name}! Sessão iniciada.`);
        setTimeout(() => {
          onClose();
          onCustomerLoginSuccess();
        }, 600);
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao iniciar sessão. Verifique o seu email e palavra-passe.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (password !== confirmPassword) {
      setError('As palavras-passe não coincidem.');
      return;
    }

    const strength = evaluatePasswordStrength(password);
    if (!strength.isStrong) {
      setError('A palavra-passe deve ser forte: mínimo de 8 caracteres, incluindo pelo menos uma letra maiúscula, uma minúscula, um número e um carácter especial (ex: @, #, $, !).');
      return;
    }

    setIsLoading(true);

    try {
      const result = await register({ name, email, phone, password });

      if (result.requiresEmailConfirmation) {
        setSuccess(result.message);
        setTimeout(() => {
          setTab('login');
        }, 4000);
      } else if (result.user) {
        const isOfficialAdmin = result.user.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com';
        setSuccess('Conta criada e autenticada com sucesso no Supabase! A aceder ao seu Painel...');
        setTimeout(() => {
          onClose();
          if (isOfficialAdmin) {
            onAdminLoginSuccess();
          } else {
            onCustomerLoginSuccess();
          }
        }, 700);
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao criar conta no Supabase.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email.trim()) {
      setError('Por favor, introduza o seu endereço de email.');
      return;
    }

    setIsLoading(true);

    try {
      await resetPasswordForEmail(email.trim());
      setSuccess('Se existir uma conta associada a este e-mail, enviámos uma ligação segura de recuperação. Por favor, consulte a sua caixa de entrada e pasta de spam.');
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro ao processar o seu pedido. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleOAuth = async () => {
    setError('');
    setSuccess('');
    setOauthLoading(true);
    try {
      await signInWithOAuth('google');
    } catch (err: any) {
      setError(err.message || 'Erro ao autenticar com o Google.');
    } finally {
      setOauthLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8 animate-scale-in transition-all"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-[#0B1E36] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/logo_a1884a32.jpg"
              alt="CarcubaExpress"
              className="w-11 h-11 rounded-full object-contain bg-white p-0.5 border border-amber-400 shrink-0 shadow-sm"
            />
            <div>
              <h2 className="text-base font-bold">
                {user ? 'Minha Conta' : tab === 'register' ? 'Criar Nova Conta' : tab === 'forgot' ? 'Recuperar Palavra-passe' : 'Iniciar Sessão'}
              </h2>
              <p className="text-xs text-slate-300">CarcubaExpress Comércio · Luanda</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If user is already logged in */}
        {user ? (
          <div className="p-6 space-y-4 text-center">
            <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-800 font-bold text-xl flex items-center justify-center mx-auto border-2 border-amber-400">
              {user.name ? user.name[0].toUpperCase() : 'U'}
            </div>
            <div>
              <div className="flex items-center justify-center gap-1.5">
                <h3 className="font-bold text-slate-900">{user.name}</h3>
                {user.role === 'admin' && (
                  <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-300">
                    Admin
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{user.email}</p>
              {user.phone && <p className="text-xs text-slate-500">{user.phone}</p>}
            </div>

            <div className="pt-2 flex flex-col gap-2.5">
              {/* If user is admin, prominent direct access button */}
              {user.role === 'admin' && (
                <button
                  onClick={() => {
                    onClose();
                    onAdminLoginSuccess();
                  }}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
                >
                  <Shield className="w-4 h-4 text-slate-900" />
                  <span>Aceder ao Painel Administrativo</span>
                </button>
              )}

              <button
                onClick={() => {
                  onClose();
                  onCustomerLoginSuccess();
                }}
                className="w-full py-2.5 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Os Meus Pedidos (Painel do Cliente)
              </button>

              <button
                onClick={async () => {
                  await logout();
                  onClose();
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Terminar Sessão
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 space-y-4">
            {/* Tabs: Iniciar Sessão vs Criar Nova Conta vs Recuperar Palavra-passe */}
            <div className="flex border-b border-slate-200">
              <button
                onClick={() => {
                  setTab('login');
                  setError('');
                  setSuccess('');
                }}
                className={`flex-1 pb-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  tab === 'login'
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                Iniciar Sessão
              </button>
              <button
                onClick={() => {
                  setTab('register');
                  setError('');
                  setSuccess('');
                }}
                className={`flex-1 pb-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  tab === 'register'
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                Criar Nova Conta
              </button>
              {tab === 'forgot' && (
                <button
                  type="button"
                  className="flex-1 pb-3 text-xs font-bold border-b-2 border-amber-500 text-amber-600 cursor-default"
                >
                  Recuperação
                </button>
              )}
            </div>

            {/* Error message */}
            {error && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex flex-col gap-2">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
                  <span className="leading-relaxed font-medium">{error}</span>
                </div>
                {error.includes('painel Supabase') && (
                  <div className="mt-1 p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 leading-relaxed">
                    💡 <strong>Como ativar o Google no Supabase:</strong> Aceda a <span className="font-mono font-semibold">supabase.com</span> &gt; <strong>Authentication</strong> &gt; <strong>Providers</strong> &gt; <strong>Google</strong> e ative a opção <em>Enable provider</em>.
                  </div>
                )}
              </div>
            )}

            {/* Success message */}
            {success && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{success}</span>
              </div>
            )}

            {/* TAB: LOGIN */}
            {tab === 'login' && (
              <div className="space-y-4">
                {/* Social Login: GOOGLE ONLY */}
                <div>
                  <button
                    type="button"
                    onClick={handleGoogleOAuth}
                    disabled={isLoading || oauthLoading}
                    className="w-full py-3 px-4 bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs rounded-xl border border-slate-300 shadow-sm flex items-center justify-center gap-3 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-50"
                  >
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <span>{oauthLoading ? 'A conectar ao Google...' : 'Entrar com o Google'}</span>
                  </button>
                </div>

                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-slate-200"></div>
                  <span className="flex-shrink mx-3 text-[10px] uppercase font-bold text-slate-400">
                    ou com email e palavra-passe
                  </span>
                  <div className="flex-grow border-t border-slate-200"></div>
                </div>

                <form onSubmit={handleLogin} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="email"
                        required
                        placeholder="o-seu-email@gmail.com"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">Palavra-passe</label>
                      <button
                        type="button"
                        onClick={() => {
                          setTab('forgot');
                          setError('');
                          setSuccess('');
                        }}
                        className="text-[11px] text-amber-600 hover:text-amber-700 font-semibold cursor-pointer hover:underline"
                      >
                        Esqueci-me da palavra-passe
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type={showLoginPassword ? 'text' : 'password'}
                        required
                        placeholder="••••••••"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowLoginPassword(!showLoginPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 rounded-md transition-colors cursor-pointer"
                        title={showLoginPassword ? 'Ocultar palavra-passe' : 'Visualizar palavra-passe'}
                        aria-label={showLoginPassword ? 'Ocultar palavra-passe' : 'Visualizar palavra-passe'}
                      >
                        {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-amber-600" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Entrar na Conta'}
                  </button>
                </form>
              </div>
            )}

            {/* TAB: FORGOT PASSWORD */}
            {tab === 'forgot' && (
              <div className="space-y-4 animate-fade-in">
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-950 flex items-start gap-2.5">
                  <Shield className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="leading-relaxed">
                    <p className="font-bold text-amber-950">Recuperação Segura da Palavra-passe</p>
                    <p className="text-[11px] text-amber-800 mt-0.5">
                      Introduza o seu email associado à sua conta. Se estiver registado, enviaremos uma ligação segura para redefinir a sua palavra-passe no Supabase.
                    </p>
                  </div>
                </div>

                <form onSubmit={handleForgotPassword} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">O seu Email</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="email"
                        required
                        placeholder="o-seu-email@gmail.com"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Enviar Ligação de Recuperação'}
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setTab('login');
                        setError('');
                        setSuccess('');
                      }}
                      className="text-xs font-bold text-slate-600 hover:text-slate-900 hover:underline cursor-pointer"
                    >
                      ← Voltar ao Início de Sessão
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* TAB: REGISTER */}
            {tab === 'register' && (
              <div className="space-y-4">
                {/* Social Sign Up: GOOGLE ONLY */}
                <div>
                  <button
                    type="button"
                    onClick={handleGoogleOAuth}
                    disabled={isLoading || oauthLoading}
                    className="w-full py-3 px-4 bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs rounded-xl border border-slate-300 shadow-sm flex items-center justify-center gap-3 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-50"
                  >
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <span>{oauthLoading ? 'A conectar ao Google...' : 'Criar conta com o Google'}</span>
                  </button>
                </div>

                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-slate-200"></div>
                  <span className="flex-shrink mx-3 text-[10px] uppercase font-bold text-slate-400">
                    ou preencha os seus dados
                  </span>
                  <div className="flex-grow border-t border-slate-200"></div>
                </div>

                <form onSubmit={handleRegister} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Nome Completo</label>
                    <div className="relative">
                      <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        required
                        placeholder="ex: Manuel Domingos"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="email"
                        required
                        placeholder="o-seu-email@gmail.com"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Telefone (Angola)</label>
                    <div className="relative">
                      <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="tel"
                        required
                        placeholder="+244 923 000 000"
                        value={phone}
                        onChange={e => setPhone(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">
                        Palavra-passe <span className="text-[11px] font-normal text-slate-500">(Forte)</span>
                      </label>
                      {password.length > 0 && (
                        <span className={`text-[11px] font-bold ${registerPasswordStrength.textColor}`}>
                          {registerPasswordStrength.label}
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type={showRegisterPassword ? 'text' : 'password'}
                        required
                        placeholder="Mín. 8 caracteres, maiúscula, número e símbolo"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className={`w-full pl-9 pr-10 py-2.5 bg-slate-50 border rounded-xl text-xs text-slate-900 focus:outline-none transition-colors ${
                          password.length === 0
                            ? 'border-slate-200 focus:ring-1 focus:ring-amber-500'
                            : registerPasswordStrength.isStrong
                            ? 'border-emerald-400 focus:ring-1 focus:ring-emerald-500'
                            : 'border-amber-300 focus:ring-1 focus:ring-amber-500'
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 rounded-md transition-colors cursor-pointer"
                        title={showRegisterPassword ? 'Ocultar palavra-passe' : 'Visualizar palavra-passe'}
                      >
                        {showRegisterPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-amber-600" />}
                      </button>
                    </div>

                    {/* Barra de Força da Palavra-passe e Requisitos */}
                    {password.length > 0 && (
                      <div className="mt-2 p-2.5 bg-slate-50 border border-slate-200/90 rounded-xl space-y-2 animate-fade-in text-[11px]">
                        {/* Segmentos de barra de força */}
                        <div className="grid grid-cols-4 gap-1.5 h-1.5 w-full">
                          <div className={`h-full rounded-full transition-all duration-300 ${registerPasswordStrength.score >= 1 ? registerPasswordStrength.barColor : 'bg-slate-200'}`} />
                          <div className={`h-full rounded-full transition-all duration-300 ${registerPasswordStrength.score >= 2 ? registerPasswordStrength.barColor : 'bg-slate-200'}`} />
                          <div className={`h-full rounded-full transition-all duration-300 ${registerPasswordStrength.score >= 3 ? registerPasswordStrength.barColor : 'bg-slate-200'}`} />
                          <div className={`h-full rounded-full transition-all duration-300 ${registerPasswordStrength.score >= 4 ? registerPasswordStrength.barColor : 'bg-slate-200'}`} />
                        </div>

                        {/* Checklist dos requisitos exigidos */}
                        <div className="grid grid-cols-2 gap-x-2 gap-y-1 pt-0.5 text-[10px]">
                          <div className={`flex items-center gap-1.5 ${registerPasswordStrength.hasLength ? 'text-emerald-700 font-semibold' : 'text-slate-500'}`}>
                            {registerPasswordStrength.hasLength ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                            )}
                            <span>Mínimo 8 caracteres</span>
                          </div>

                          <div className={`flex items-center gap-1.5 ${registerPasswordStrength.hasUpper && registerPasswordStrength.hasLower ? 'text-emerald-700 font-semibold' : 'text-slate-500'}`}>
                            {registerPasswordStrength.hasUpper && registerPasswordStrength.hasLower ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                            )}
                            <span>Maiúsculas e minúsculas</span>
                          </div>

                          <div className={`flex items-center gap-1.5 ${registerPasswordStrength.hasNumber ? 'text-emerald-700 font-semibold' : 'text-slate-500'}`}>
                            {registerPasswordStrength.hasNumber ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                            )}
                            <span>Pelo menos 1 número (0-9)</span>
                          </div>

                          <div className={`flex items-center gap-1.5 ${registerPasswordStrength.hasSpecial ? 'text-emerald-700 font-semibold' : 'text-slate-500'}`}>
                            {registerPasswordStrength.hasSpecial ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                            )}
                            <span>Símbolo especial (!@#$%^&*)</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Confirmar Palavra-passe</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type={showRegisterConfirmPassword ? 'text' : 'password'}
                        required
                        placeholder="••••••••"
                        value={confirmPassword}
                        onChange={e => setConfirmPassword(e.target.value)}
                        className="w-full pl-9 pr-10 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegisterConfirmPassword(!showRegisterConfirmPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 rounded-md transition-colors cursor-pointer"
                        title={showRegisterConfirmPassword ? 'Ocultar palavra-passe' : 'Visualizar palavra-passe'}
                      >
                        {showRegisterConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-amber-600" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Criar Conta'}
                  </button>
                </form>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
