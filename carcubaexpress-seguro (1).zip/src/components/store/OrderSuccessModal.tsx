import React, { useState } from 'react';
import { CheckCircle2, MessageCircle, Copy, Check, ArrowRight, Package, MapPin, ExternalLink, Calendar, Truck } from 'lucide-react';
import type { Order } from '../../types';
import { formatEstimatedDeliveryDate } from '../../utils/deliveryEstimation';

interface OrderSuccessModalProps {
  order: Order | null;
  whatsappUrl: string;
  whatsappMessage: string;
  onClose: () => void;
  onTrackOrder: (orderNumber: string) => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  whatsappUrl,
  whatsappMessage,
  onClose,
  onTrackOrder,
}) => {
  const [copied, setCopied] = useState(false);

  if (!order) return null;

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(whatsappMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenWhatsApp = () => {
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8 animate-scale-up"
        onClick={e => e.stopPropagation()}
      >
        {/* Banner */}
        <div className="p-6 bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-center">
          <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/20 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-xl font-extrabold tracking-tight">Pedido Realizado com Sucesso!</h2>
          <p className="text-xs text-emerald-100 mt-1">
            Nº do Pedido: <span className="font-bold text-white font-mono">{order.orderNumber}</span>
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* CRITICAL ACTION: WhatsApp Forwarding Banner */}
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-emerald-500 text-white shrink-0 mt-0.5">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-emerald-950">
                  Reencaminhamento para WhatsApp (+244 951 556 411)
                </h3>
                <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed">
                  O seu pedido foi preparado com a política de <strong>pagamento no acto da entrega</strong>. Caso o WhatsApp não tenha aberto automaticamente, clique no botão abaixo para enviar o resumo da sua encomenda.
                </p>
              </div>
            </div>

            <button
              onClick={handleOpenWhatsApp}
              className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-extrabold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Abrir WhatsApp (+244 951 556 411) com Pedido</span>
              <ExternalLink className="w-4 h-4 ml-1 opacity-80" />
            </button>
          </div>

          {/* Receipt details */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50 space-y-3">
            <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-200">
              <span className="font-semibold text-slate-700">Resumo da Encomenda</span>
              <span className="text-slate-500">{new Date(order.createdAt).toLocaleDateString('pt-PT')}</span>
            </div>

            {/* Item list */}
            <div className="space-y-2">
              {(order.items || []).map((item, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-bold text-slate-700 font-mono">{item.quantity}x</span>
                    <span className="text-slate-800 truncate">{item.productName}</span>
                  </div>
                  <span className="font-semibold text-slate-900 font-mono tabular-nums shrink-0 ml-3">
                    {(item.price * item.quantity).toLocaleString('pt-AO')} Kz
                  </span>
                </div>
              ))}
            </div>

            {/* Delivery address & Estimated Date preview */}
            <div className="pt-2 border-t border-slate-200 text-xs text-slate-600 space-y-2">
              <div className="flex items-center gap-1.5 font-medium text-slate-800">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                <span>{order.deliveryMunicipality}</span>
              </div>
              <p className="text-[11px] text-slate-500 pl-5">{order.deliveryAddress}</p>

              {(() => {
                const est = formatEstimatedDeliveryDate(
                  order.estimatedDeliveryDate,
                  order.createdAt,
                  order.deliveryMunicipality
                );
                return (
                  <div className="flex items-center gap-2 p-2.5 bg-amber-50 rounded-xl border border-amber-200/80 text-amber-950">
                    <Calendar className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">
                        Previsão de Entrega ao Domicílio:
                      </span>
                      <strong className="text-slate-900 font-bold block text-xs">
                        {est.formattedDate}
                      </strong>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Total */}
            <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline text-sm font-bold text-[#0B1E36]">
              <span>Total a Pagar na Entrega:</span>
              <span className="text-base text-amber-600 font-mono tabular-nums">
                {order.total.toLocaleString('pt-AO')} Kz
              </span>
            </div>
          </div>

          {/* Copyable WhatsApp message backup */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
              <span>Texto formatado para WhatsApp:</span>
              <button
                onClick={handleCopyMessage}
                className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-semibold text-[11px]"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado!' : 'Copiar Texto'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-slate-200 rounded-xl text-[10px] font-mono whitespace-pre-wrap max-h-28 overflow-y-auto border border-slate-800">
              {whatsappMessage}
            </pre>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => {
                onClose();
                onTrackOrder(order.orderNumber);
              }}
              className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors text-center"
            >
              Acompanhar Estado do Pedido
            </button>

            <button
              onClick={onClose}
              className="py-2.5 px-3 bg-[#0B1E36] hover:bg-[#132c4d] text-white rounded-xl text-xs font-bold transition-colors text-center"
            >
              Concluir e Voltar à Loja
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
