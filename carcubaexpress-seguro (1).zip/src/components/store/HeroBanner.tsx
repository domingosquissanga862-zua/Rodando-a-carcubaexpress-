import React from 'react';
import { ArrowDown, MessageCircle, Truck, CheckCircle2, Sparkles } from 'lucide-react';
import type { Product } from '../../types';
import { useCart } from '../../context/CartContext';

interface HeroBannerProps {
  onScrollToCatalog: () => void;
  onQuickView: (product: Product) => void;
  featuredProducts: Product[];
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onScrollToCatalog,
  onQuickView,
  featuredProducts,
}) => {
  const { settings } = useCart();
  const whatsappPhone = (settings?.whatsappNumber || '244951556411').replace(/\D/g, '');

  const whatsappDirect =
    `https://wa.me/${whatsappPhone}?text=` +
    encodeURIComponent('Olá CarcubaExpress! Gostaria de fazer uma encomenda para entrega em Luanda.');

  // Dynamically resolve up to 3 spotlight items from products
  const spotlightItems = React.useMemo(() => {
    if (!featuredProducts || featuredProducts.length === 0) return [];
    
    // 1. First look for explicitly featured products
    const featured = featuredProducts.filter(p => p.isFeatured && p.isActive);
    if (featured.length > 0) {
      return featured.slice(0, 3);
    }
    
    // 2. Otherwise take active products available in store
    return featuredProducts.filter(p => p.isActive).slice(0, 3);
  }, [featuredProducts]);

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#0B1E36] via-[#0D2442] to-[#0A192F] text-white">
      {/* Subtle background decoration */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#F59E0B_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Main Hero Copy */}
          <div className="lg:col-span-7 space-y-6 animate-slide-up">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 text-amber-400 text-xs font-semibold backdrop-blur-sm border border-white/10 animate-fade-in">
              <Truck className="w-3.5 h-3.5" />
              <span>Entregas Rápidas em Todos os Municípios de Luanda</span>
            </div>

            <h1
              className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.15]"
              style={{ textWrap: 'balance' }}
            >
              Compre online em <span className="text-amber-400">Luanda</span> com pagamento na entrega.
            </h1>
            <div className="flex items-center gap-2 pt-1 text-xs text-amber-300/90 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Receba na sua morada em Luanda · Pagamento apenas em Dinheiro ou Multicaixa Express</span>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onScrollToCatalog}
                className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold text-sm rounded-xl transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-amber-500/20 flex items-center gap-2 group cursor-pointer"
              >
                <span>Ver produtos</span>
                <ArrowDown className="w-4 h-4 transition-transform group-hover:translate-y-1 duration-200" />
              </button>

              <a
                href={whatsappDirect}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2 shadow-lg shadow-emerald-600/20"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Encomendar via WhatsApp</span>
              </a>
            </div>

            {/* Micro value props */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Pagamento no Acto</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Entrega Grátis Selecionada</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Reencaminha p/ WhatsApp</span>
              </div>
            </div>
          </div>

          {/* Featured Deals Spotlight Cards */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Destaques Especiais Carcuba
                </span>
                <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  Entrega em Luanda
                </span>
              </div>

              <div className="space-y-3">
                {spotlightItems.length > 0 ? (
                  spotlightItems.map(product => (
                    <div
                      key={product.id}
                      onClick={() => onQuickView(product)}
                      className="flex items-center gap-3.5 p-2.5 rounded-xl bg-white/5 hover:bg-white/15 transition-all cursor-pointer border border-white/5 group"
                    >
                      <img
                        src={product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 object-contain p-1 rounded-lg bg-white/10 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-white group-hover:text-amber-400 transition-colors truncate">
                          {product.name}
                        </p>
                        <p className="text-[11px] text-slate-300 line-clamp-1 mt-0.5">
                          {product.categoryName || 'CarcubaExpress Comércio'}
                        </p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm font-extrabold text-amber-400 font-mono tabular-nums">
                            {product.price.toLocaleString('pt-AO')} Kz
                          </span>
                          <span className="text-[10px] text-emerald-300 font-medium">
                            {product.freeShipping ? 'Entrega Grátis' : 'Pagamento na Entrega'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-slate-400">
                    A carregar artigos em destaque da loja...
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
