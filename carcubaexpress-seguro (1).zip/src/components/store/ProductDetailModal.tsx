import React, { useState, useEffect } from 'react';
import { X, ShoppingBag, MessageCircle, Truck, ShieldCheck, Check, Plus, Minus, ArrowLeft, ZoomIn } from 'lucide-react';
import type { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onDirectCheckout: () => void;
  onRequireAuth?: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onDirectCheckout,
  onRequireAuth,
}) => {
  const { addItem, settings } = useCart();
  const { user } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [isZoomOpen, setIsZoomOpen] = useState(false);

  useEffect(() => {
    if (product) {
      setSelectedSize(product.sizes && product.sizes.length > 0 ? product.sizes[0] : '');
      setSelectedColor(product.colors && product.colors.length > 0 ? product.colors[0] : '');
      setSelectedImageIndex(0);
      setQuantity(1);
    }
  }, [product]);

  // Lock body scroll and listen for Escape key to close modal seamlessly
  useEffect(() => {
    if (!product) return;

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [product, onClose]);

  if (!product) return null;

  const isOutOfStock = product.stock <= 0;

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    if (!user) {
      onRequireAuth?.();
      return;
    }
    addItem(product, quantity, selectedSize || undefined, selectedColor || undefined);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleBuyNow = () => {
    if (isOutOfStock) return;
    if (!user) {
      onRequireAuth?.();
      return;
    }
    addItem(product, quantity, selectedSize || undefined, selectedColor || undefined);
    onClose();
    onDirectCheckout();
  };

  const handleWhatsAppOrder = () => {
    const phone = settings?.whatsappNumber || '244951556411';
    const totalAmount = (product.price * quantity).toLocaleString('pt-AO');
    const shippingNote = product.freeShipping
      ? `• *Entrega:* Grátis em Luanda`
      : product.shippingFeeLabel
      ? `• *Entrega:* ${product.shippingFeeLabel}`
      : product.shippingFee
      ? `• *Entrega:* + Taxa ${product.shippingFee.toLocaleString('pt-AO')} Kz`
      : `• *Entrega:* Luanda (a calcular no acto)`;

    const text = [
      `*Olá CarcubaExpress!* 🛍️`,
      `Gostaria de encomendar:`,
      `• *Produto:* ${product.name}`,
      selectedSize ? `• *Tamanho:* ${selectedSize}` : null,
      selectedColor ? `• *Cor:* ${selectedColor}` : null,
      `• *Quantidade:* ${quantity} unidade(s)`,
      `• *Valor Unitário:* ${product.price.toLocaleString('pt-AO')} Kz`,
      `• *Total:* ${totalAmount} Kz`,
      shippingNote,
      `Poderiam confirmar a disponibilidade e agendar a entrega ao domicílio?`,
    ].filter(Boolean).join('\n');

    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-4 sm:my-8"
        onClick={e => e.stopPropagation()}
      >
        {/* Mobile-Only Top Sticky Bar to exit easily on phones */}
        <div className="md:hidden sticky top-0 z-30 bg-[#0B1E36] text-white px-4 py-2.5 flex items-center justify-between border-b border-slate-700 shadow-md">
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300 transition-colors py-1 px-2 rounded-lg bg-white/10 active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar ao Catálogo</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white rounded-full bg-white/10 transition-colors active:scale-95"
            aria-label="Fechar e voltar à loja"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Floating High-Contrast Close Button (Desktop & Tablet) */}
        <button
          onClick={onClose}
          className="hidden md:flex absolute top-4 right-4 z-20 p-2.5 text-slate-700 hover:text-slate-900 bg-white/90 hover:bg-white rounded-full transition-all shadow-lg ring-1 ring-slate-200 active:scale-95 items-center justify-center"
          aria-label="Fechar"
          title="Fechar e voltar ao catálogo"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image Gallery with Complete View (No Cropping) */}
          <div className="relative w-full bg-slate-900/[0.04] flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-slate-200">
            {/* Main Image Stage */}
            <div
              className="relative w-full h-[320px] sm:h-[400px] md:h-[480px] flex items-center justify-center p-3 sm:p-4 overflow-hidden cursor-zoom-in group select-none"
              onClick={() => setIsZoomOpen(true)}
              title="Toque para ampliar a fotografia em ecrã completo"
            >
              {/* Ambient blurred backdrop to frame the photo naturally without empty borders */}
              <img
                src={product.images[selectedImageIndex] || product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
                alt=""
                aria-hidden="true"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-20 scale-125 pointer-events-none"
              />

              {/* Complete product image: 100% visible from top to bottom without cutting heads, straps or hems */}
              <img
                src={product.images[selectedImageIndex] || product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="relative z-10 max-h-full max-w-full w-auto h-auto object-contain drop-shadow-md rounded-xl group-hover:scale-[1.02] transition-transform duration-300"
              />

              {/* Shipping Badges */}
              {product.freeShipping ? (
                <div className="absolute top-3 left-3 z-20 bg-emerald-600 text-white text-xs font-semibold px-2.5 py-1 rounded-md shadow-sm">
                  Entrega Grátis em Luanda
                </div>
              ) : (product.shippingFee || product.shippingFeeLabel) ? (
                <div className="absolute top-3 left-3 z-20 bg-amber-600 text-white text-xs font-semibold px-2.5 py-1 rounded-md shadow-sm flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5" />
                  <span>{product.shippingFeeLabel || `+ Taxa: ${product.shippingFee?.toLocaleString('pt-AO')} Kz`}</span>
                </div>
              ) : null}

              {/* Zoom / Fullscreen Button */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsZoomOpen(true);
                }}
                className="absolute bottom-3 right-3 z-20 px-2.5 py-1.5 bg-black/70 hover:bg-black/90 text-white text-[11px] font-semibold rounded-lg backdrop-blur-md flex items-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
              >
                <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                <span>Ver Foto Completa</span>
              </button>
            </div>

            {/* Thumbnail Gallery (if product has multiple photos) */}
            {product.images && product.images.length > 1 && (
              <div className="w-full p-2.5 bg-white border-t border-slate-200 flex items-center gap-2 overflow-x-auto scrollbar-none">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-12 h-12 rounded-lg border-2 overflow-hidden shrink-0 transition-all cursor-pointer ${
                      selectedImageIndex === idx
                        ? 'border-amber-500 shadow-sm ring-1 ring-amber-400'
                        : 'border-slate-200 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details & Purchase Module */}
          <div className="p-6 md:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="font-semibold uppercase tracking-wider text-amber-600">
                  {product.categoryName}
                </span>
                <span>·</span>
                <span>Luanda, Angola</span>
              </div>

              <h2 className="text-xl font-bold text-slate-900 leading-snug">
                {product.name}
              </h2>

              <div className="flex items-baseline gap-3 pt-1">
                <span className="text-2xl font-extrabold text-[#0B1E36] font-mono tabular-nums">
                  {product.price.toLocaleString('pt-AO')} Kz
                </span>
                {product.promoPrice && product.promoPrice > product.price && (
                  <span className="text-sm text-slate-400 line-through font-mono tabular-nums">
                    {product.promoPrice.toLocaleString('pt-AO')} Kz
                  </span>
                )}
              </div>

              {/* Stock condition */}
              <div className="text-xs">
                {isOutOfStock ? (
                  <span className="text-rose-600 font-semibold">Produto Esgotado de momento</span>
                ) : (
                  <span className="text-emerald-700 font-medium flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    Em stock ({product.stock} unidades disponíveis no armazém de Luanda)
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-600 leading-relaxed pt-2 border-t border-slate-100">
                {product.description}
              </p>

              {/* Size Selector */}
              {product.sizes && product.sizes.length > 0 && (
                <div className="pt-3 border-t border-slate-100 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-700">Tamanho:</span>
                    <span className="text-xs font-bold text-amber-700">{selectedSize || 'Selecione'}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {product.sizes.map(size => {
                      const isSelected = selectedSize === size;
                      return (
                        <button
                          key={size}
                          type="button"
                          onClick={() => setSelectedSize(size)}
                          className={`min-w-9 h-8 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#0B1E36] text-white shadow-sm ring-2 ring-amber-400'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                          }`}
                        >
                          {size}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Color Selector */}
              {product.colors && product.colors.length > 0 && (
                <div className="pt-2 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-700">Cor disponível:</span>
                    <span className="text-xs font-bold text-amber-700">{selectedColor || 'Selecione'}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {product.colors.map(color => {
                      const isSelected = selectedColor === color;
                      return (
                        <button
                          key={color}
                          type="button"
                          onClick={() => setSelectedColor(color)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500 text-slate-900 font-bold shadow-sm ring-2 ring-amber-300'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                          }`}
                        >
                          {color}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Quantity and Actions */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              {!isOutOfStock && (
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-700">Quantidade:</span>
                  <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2 text-slate-600 hover:bg-slate-100 transition-colors"
                      disabled={quantity <= 1}
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-4 py-1 text-sm font-semibold text-slate-800 font-mono tabular-nums">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      className="p-2 text-slate-600 hover:bg-slate-100 transition-colors"
                      disabled={quantity >= product.stock}
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <button
                  onClick={handleAddToCart}
                  disabled={isOutOfStock}
                  className={`w-full py-3 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                    isOutOfStock
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : added
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#0B1E36] hover:bg-[#132c4d] text-white active:scale-[0.98]'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Adicionado ao Carrinho!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4 text-amber-400" />
                      <span>Adicionar ao Carrinho</span>
                    </>
                  )}
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleBuyNow}
                    disabled={isOutOfStock}
                    className="py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-xl text-xs font-bold transition-all text-center"
                  >
                    Finalizar Compra
                  </button>

                  <button
                    onClick={handleWhatsAppOrder}
                    className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Pedir no WhatsApp</span>
                  </button>
                </div>
              </div>

              {/* Delivery & Security Note */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-[11px] text-slate-600 space-y-2">
                {(!product.freeShipping && (product.shippingFee || product.shippingFeeLabel)) && (
                  <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 text-xs flex items-start gap-2">
                    <Truck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block">
                        {product.shippingFeeLabel || `Taxa adicional de entrega: ${product.shippingFee?.toLocaleString('pt-AO')} Kz`}
                      </span>
                      <p className="text-[11px] text-amber-800 mt-0.5">
                        Taxa de entrega ao domicílio para Luanda e municípios.
                      </p>
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-1.5 font-medium text-slate-800">
                  <Truck className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Entrega rápida em Luanda</span>
                </div>
                <p>Receba no próprio dia ou em até 24h. Pagamento no acto da entrega: apenas Dinheiro ou Multicaixa Express.</p>
              </div>

              {/* Bottom Return / Exit Button for easy closing especially on mobile devices */}
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all border border-slate-200 flex items-center justify-center gap-2 cursor-pointer active:scale-98 shadow-xs"
              >
                <ArrowLeft className="w-4 h-4 text-slate-500" />
                <span>Voltar ao Catálogo de Produtos / Fechar</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Fullscreen High-Resolution Image Lightbox Modal */}
      {isZoomOpen && (
        <div
          className="fixed inset-0 z-[60] bg-black/95 flex flex-col items-center justify-center p-3 sm:p-6 animate-fade-in backdrop-blur-md"
          onClick={() => setIsZoomOpen(false)}
        >
          {/* Top Bar with Close button */}
          <div className="absolute top-4 right-4 z-50 flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsZoomOpen(false)}
              className="p-2.5 text-white bg-white/20 hover:bg-white/30 rounded-full transition-all active:scale-95 cursor-pointer shadow-lg"
              aria-label="Fechar ampliação"
              title="Fechar ecrã completo"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div
            className="relative max-w-5xl max-h-[85vh] w-full flex items-center justify-center"
            onClick={e => e.stopPropagation()}
          >
            <img
              src={product.images[selectedImageIndex] || product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
              alt={product.name}
              className="max-w-full max-h-[85vh] w-auto h-auto object-contain rounded-2xl shadow-2xl"
            />
          </div>

          <div className="text-center mt-3 text-white/80 space-y-0.5">
            <p className="text-sm font-bold text-white">{product.name}</p>
            <p className="text-xs text-white/60">Toque em qualquer lugar ou no X para voltar</p>
          </div>
        </div>
      )}
    </div>
  );
};
