import React from 'react';
import { ShoppingBag, MessageCircle, Check, Eye, Truck } from 'lucide-react';
import type { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
  onRequireAuth?: (tab?: 'login' | 'register') => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView, onRequireAuth }) => {
  const { addItem, settings } = useCart();
  const { user } = useAuth();
  const [added, setAdded] = React.useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.stock <= 0) return;

    // Se o cliente não tem conta criada / sessão iniciada, abre imediatamente o painel de login / criar conta
    if (!user) {
      onRequireAuth?.('login');
      return;
    }

    addItem(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleWhatsAppQuickOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    const phone = settings?.whatsappNumber || '244951556411';
    const text = `Olá CarcubaExpress! Tenho interesse no produto: *${product.name}* (${product.price.toLocaleString('pt-AO')} Kz). Está disponível para entrega em Luanda com pagamento no acto da entrega?`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const isOutOfStock = product.stock <= 0;

  return (
    <div
      onClick={() => onQuickView(product)}
      className="group relative bg-white rounded-2xl border border-slate-200/80 overflow-hidden card-hover animate-fade-in flex flex-col cursor-pointer"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden flex items-center justify-center">
        <img
          src={product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Free Shipping Tag or Additional Shipping Fee Tag - with z-20 so it is NEVER covered */}
        {product.freeShipping ? (
          <div className="absolute top-2.5 left-2.5 z-20 bg-emerald-600 text-white text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-md shadow-sm">
            Entrega Grátis
          </div>
        ) : (product.shippingFee || product.shippingFeeLabel) ? (
          <div className="absolute top-2.5 left-2.5 z-20 bg-amber-500 text-slate-900 text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-md shadow-sm flex items-center gap-1">
            <Truck className="w-3 h-3 text-slate-900 shrink-0" />
            <span>{product.shippingFeeLabel || `+ Taxa: ${Number(product.shippingFee).toLocaleString('pt-AO')} Kz`}</span>
          </div>
        ) : null}

        {/* Low Stock or Out of Stock Tag */}
        {isOutOfStock ? (
          <div className="absolute top-2.5 right-2.5 z-20 bg-rose-600 text-white text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-md shadow-sm">
            Esgotado
          </div>
        ) : product.stock <= 5 ? (
          <div className="absolute top-2.5 right-2.5 z-20 bg-amber-500 text-slate-900 text-[10px] font-bold px-1.5 py-0.5 rounded-md shadow-sm">
            Apenas {product.stock} restantes
          </div>
        ) : null}

        {/* Quick View Hover Button */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-4 z-10">
          <span className="px-3 py-1.5 bg-white/90 backdrop-blur-sm text-slate-900 text-xs font-semibold rounded-lg shadow flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5 text-slate-700" />
            <span>Ver Detalhes</span>
          </span>
        </div>
      </div>

      {/* Body details */}
      <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category kicker */}
          <p className="text-[10px] sm:text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1 truncate">
            {product.categoryName}
          </p>

          <h3 className="text-xs sm:text-sm font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-amber-600 transition-colors">
            {product.name}
          </h3>
        </div>

        <div className="pt-2 sm:pt-3 mt-2 border-t border-slate-100">
          <div className="flex items-baseline justify-between mb-1 sm:mb-2">
            <div>
              <span className="text-sm sm:text-base font-extrabold text-[#0B1E36] font-mono tabular-nums block">
                {product.price.toLocaleString('pt-AO')} Kz
              </span>
              {product.promoPrice && product.promoPrice > product.price && (
                <span className="text-[10px] sm:text-xs text-slate-400 line-through font-mono tabular-nums">
                  {product.promoPrice.toLocaleString('pt-AO')} Kz
                </span>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] text-slate-400 hidden xs:inline">Luanda</span>
          </div>

          {/* Delivery fee note under price */}
          {product.freeShipping ? (
            <p className="text-[10px] font-semibold text-emerald-700 mb-2 truncate flex items-center gap-1">
              <Truck className="w-3 h-3 text-emerald-600 shrink-0" />
              <span>Entrega Grátis em Luanda</span>
            </p>
          ) : (product.shippingFee || product.shippingFeeLabel) ? (
            <p className="text-[10px] font-semibold text-amber-700 mb-2 truncate flex items-center gap-1">
              <Truck className="w-3 h-3 text-amber-600 shrink-0" />
              <span>{product.shippingFeeLabel || `+ Taxa de entrega: ${Number(product.shippingFee).toLocaleString('pt-AO')} Kz`}</span>
            </p>
          ) : null}

          {/* Action buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-2">
            <button
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className={`py-1.5 sm:py-2 px-2 rounded-lg text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                isOutOfStock
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : added
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#0B1E36] hover:bg-[#132c4d] text-white active:scale-95'
              }`}
            >
              {added ? (
                <>
                  <Check className="w-3 h-3 text-white" />
                  <span>Adicionado</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3 h-3 text-amber-400" />
                  <span>Carrinho</span>
                </>
              )}
            </button>

            <button
              onClick={handleWhatsAppQuickOrder}
              className="py-1.5 sm:py-2 px-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 rounded-lg text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1 transition-colors active:scale-95"
              title="Pedir diretamente por WhatsApp"
            >
              <MessageCircle className="w-3 h-3 text-emerald-600" />
              <span>WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
