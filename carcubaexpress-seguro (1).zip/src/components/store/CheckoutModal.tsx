import React, { useState } from 'react';
import { X, CheckCircle, Truck, MapPin, Phone, User, MessageCircle, AlertCircle, Loader2, Banknote, Smartphone, ShieldCheck, Lock } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import type { Order } from '../../types';
import { LegalModal } from '../legal/LegalModal';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (order: Order, whatsappUrl: string, whatsappMessage: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, onOrderSuccess }) => {
  const { items, subtotal, shippingFee, total, hasFreeShipping, selectedMunicipality, setSelectedMunicipality, clearCart, settings } = useCart();
  const { user } = useAuth();

  const [customerName, setCustomerName] = useState(user?.name || '');
  const [customerPhone, setCustomerPhone] = useState(user?.phone || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryReference, setDeliveryReference] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Dinheiro (no acto da entrega)' | 'Multicaixa Express'>('Dinheiro (no acto da entrega)');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [legalTab, setLegalTab] = useState<'terms' | 'privacy' | 'shipping' | 'warranty' | null>(null);

  React.useEffect(() => {
    if (user) {
      if (user.name && !customerName) setCustomerName(user.name);
      if (user.phone && !customerPhone) setCustomerPhone(user.phone);
      if (user.email && !customerEmail) setCustomerEmail(user.email);
    }
  }, [user]);

  if (!isOpen) return null;

  const municipalities = settings?.deliveryMunicipalities || [
    { name: 'Luanda (Ingombota, Maianga, Rangel, Sambizanga)', fee: 0, estimatedHours: '' },
    { name: 'Talatona (Benfica, Morro Bento, Camama)', fee: 0, estimatedHours: '' },
    { name: 'Belas (Kilamba, Centralidade do Kilamba)', fee: 0, estimatedHours: '' },
    { name: 'Kilamba Kiaxi (Golf 1 e 2, Palanca)', fee: 0, estimatedHours: '' },
    { name: 'Viana (Zango 1 a 4, Estalagem, Vila)', fee: 0, estimatedHours: '' },
    { name: 'Cazenga (Hoji-ya-Henda, Tala Hady)', fee: 0, estimatedHours: '' },
    { name: 'Cacuaco (Vila, Sequele, Kifangondo)', fee: 0, estimatedHours: '' },
    { name: 'Icolo e Bengo (Catete)', fee: 0, estimatedHours: '' },
    { name: 'Quiçama', fee: 0, estimatedHours: '' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!user) {
      setErrorMessage('É obrigatório ter uma conta criada e iniciar sessão para registar a sua encomenda na CarcubaExpress.');
      return;
    }

    if (!customerName.trim()) {
      setErrorMessage('Por favor, indique o seu nome completo.');
      return;
    }
    if (!customerPhone.trim() || customerPhone.replace(/[^0-9]/g, '').length < 9) {
      setErrorMessage('Por favor, indique um número de telefone angolano válido (ex: 923 000 000).');
      return;
    }
    if (!deliveryAddress.trim()) {
      setErrorMessage('Por favor, introduza o endereço de entrega (rua, número ou condomínio).');
      return;
    }
    if (items.length === 0) {
      setErrorMessage('O seu carrinho está vazio.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerEmail: (user?.email || customerEmail).trim(),
        customerId: user?.id,
        deliveryAddress: deliveryAddress.trim(),
        deliveryMunicipality: selectedMunicipality,
        deliveryReference: deliveryReference.trim() || undefined,
        items: items.map(i => ({
          productId: i.product.id,
          productName: i.product.name,
          quantity: i.quantity,
          size: i.selectedSize || undefined,
          color: i.selectedColor || undefined,
          image: (i.product.images && i.product.images.length > 0 ? i.product.images[0] : (i.product as any).image) || undefined,
        })),
        paymentMethod,
        notes: notes.trim() || undefined,
      };

      const res = await api.createOrder(payload);
      clearCart();
      onClose();
      
      // Automatically redirect to CarcubaExpress WhatsApp with structured message
      if (res.whatsappUrl) {
        try {
          window.open(res.whatsappUrl, '_blank');
        } catch (err) {
          console.warn('Redirecionamento automático bloqueado pelo navegador, use o botão no ecrã de sucesso.', err);
        }
      }

      onOrderSuccess(res.order, res.whatsappUrl, res.whatsappMessage);
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao processar o pedido. Tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-[#0B1E36] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Finalizar Encomenda — Luanda</h2>
              <p className="text-xs text-slate-300">Entrega rápida ao domicílio com pagamento no acto</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Customer Data */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-amber-500" />
              1. Dados do Cliente
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nome Completo <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: João Baptista"
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Telefone / WhatsApp <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="ex: +244 923 000 000"
                  value={customerPhone}
                  onChange={e => setCustomerPhone(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email (opcional para envio de fatura/recibo)
                </label>
                <input
                  type="email"
                  placeholder="ex: cliente@gmail.com"
                  value={customerEmail}
                  onChange={e => setCustomerEmail(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Luanda Delivery Address */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              2. Endereço de Entrega em Luanda
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Município de Luanda <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedMunicipality}
                  onChange={e => setSelectedMunicipality(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
                  {municipalities.map(m => (
                    <option key={m.name} value={m.name}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Rua, Bairro e Número da Casa / Condomínio <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Bairro Benfica, Rua das Acácias, Casa nº 4"
                  value={deliveryAddress}
                  onChange={e => setDeliveryAddress(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ponto de Referência (ajuda o estafeta a chegar rapidamente)
                </label>
                <input
                  type="text"
                  placeholder="ex: Próximo à bomba Sonangol ou em frente ao colégio"
                  value={deliveryReference}
                  onChange={e => setDeliveryReference(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Payment Method */}
          {/* Section 3: Payment Method - Only Dinheiro & Express */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Banknote className="w-3.5 h-3.5 text-amber-500" />
                <span>3. Forma de Pagamento</span>
              </h3>
              <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full">
                Apenas Dinheiro ou Express
              </span>
            </div>

            {/* Crucial Notice: Only Cash and Express */}
            <div className="p-3 bg-amber-50/80 border border-amber-200/80 rounded-xl text-[11px] text-amber-900 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Política de Pagamento CarcubaExpress</p>
                <p className="text-amber-800 mt-0.5">
                  Só aceitamos pagamento em <strong>Dinheiro</strong> e <strong>Multicaixa Express</strong> no acto da entrega em Luanda. Não dispomos de terminal TPA.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label
                className={`p-3.5 rounded-2xl border-2 flex items-start gap-3 cursor-pointer transition-all ${
                  paymentMethod === 'Dinheiro (no acto da entrega)'
                    ? 'border-amber-500 bg-amber-50/50 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  checked={paymentMethod === 'Dinheiro (no acto da entrega)'}
                  onChange={() => setPaymentMethod('Dinheiro (no acto da entrega)')}
                  className="mt-1 text-amber-500 focus:ring-amber-500"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <Banknote className="w-4 h-4 text-emerald-600" />
                    <p className="text-xs font-bold text-slate-900">Dinheiro</p>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                    Pagamento com notas em mão ao estafeta no momento de receber a sua encomenda.
                  </p>
                  <span className="inline-block mt-2 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    No acto da entrega
                  </span>
                </div>
              </label>

              <label
                className={`p-3.5 rounded-2xl border-2 flex items-start gap-3 cursor-pointer transition-all ${
                  paymentMethod === 'Multicaixa Express'
                    ? 'border-amber-500 bg-amber-50/50 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  checked={paymentMethod === 'Multicaixa Express'}
                  onChange={() => setPaymentMethod('Multicaixa Express')}
                  className="mt-1 text-amber-500 focus:ring-amber-500"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-blue-600" />
                    <p className="text-xs font-bold text-slate-900">Multicaixa Express</p>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                    Pague via app Multicaixa Express no acto da entrega diretamente ao estafeta após conferir a sua encomenda.
                  </p>
                  <span className="inline-block mt-2 text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    Express / No acto
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Order Summary Box */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Itens ({items.reduce((s, i) => s + i.quantity, 0)}):</span>
              <span className="font-semibold text-slate-900 font-mono tabular-nums">
                {subtotal.toLocaleString('pt-AO')} Kz
              </span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Taxa de Entrega ({selectedMunicipality.split(' ')[0]}):</span>
              <span className="font-semibold font-mono tabular-nums">
                {shippingFee === 0 || hasFreeShipping ? (
                  <span className="text-emerald-600 font-bold">GRÁTIS</span>
                ) : (
                  `${shippingFee.toLocaleString('pt-AO')} Kz`
                )}
              </span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline text-sm font-bold text-[#0B1E36]">
              <span>Total a Pagar na Entrega:</span>
              <span className="text-base text-amber-600 font-mono tabular-nums">
                {total.toLocaleString('pt-AO')} Kz
              </span>
            </div>
          </div>

          {/* Legal Compliance & Terms Disclaimer */}
          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl text-[11px] text-slate-500 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              Ao confirmar a encomenda, declara que aceita os nossos{' '}
              <button
                type="button"
                onClick={() => setLegalTab('terms')}
                className="text-amber-700 font-bold hover:underline cursor-pointer"
              >
                Termos Gerais
              </button>
              , a nossa{' '}
              <button
                type="button"
                onClick={() => setLegalTab('privacy')}
                className="text-amber-700 font-bold hover:underline cursor-pointer"
              >
                Política de Privacidade
              </button>{' '}
              e a nossa{' '}
              <button
                type="button"
                onClick={() => setLegalTab('warranty')}
                className="text-amber-700 font-bold hover:underline cursor-pointer"
              >
                Garantia de 7 Dias
              </button>
              . Pagamento apenas no acto da entrega (Dinheiro ou Multicaixa Express).
            </p>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-900 font-extrabold rounded-xl text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-amber-500/20 active:scale-[0.98] disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>A processar o pedido...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Confirmar Pedido & Reencaminhar para WhatsApp</span>
                </>
              )}
            </button>
            <p className="text-[11px] text-slate-400 text-center mt-2">
              Após confirmar, o seu pedido será automaticamente preparado para envio pelo WhatsApp da CarcubaExpress.
            </p>
          </div>
        </form>
      </div>

      {/* Legal Modal Triggered from Checkout */}
      <LegalModal
        isOpen={Boolean(legalTab)}
        onClose={() => setLegalTab(null)}
        initialTab={legalTab || 'terms'}
      />
    </div>
  );
};
