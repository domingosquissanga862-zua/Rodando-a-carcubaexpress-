import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Truck, ShieldCheck } from 'lucide-react';
import { useCart } from '../../context/CartContext';

interface CartDrawerProps {
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onProceedToCheckout }) => {
  const {
    items,
    isCartOpen,
    setIsCartOpen,
    removeItem,
    updateQuantity,
    clearCart,
    subtotal,
    shippingFee,
    total,
    hasFreeShipping,
    selectedMunicipality,
    setSelectedMunicipality,
    settings,
  } = useCart();

  if (!isCartOpen) return null;

  const municipalities = settings?.deliveryMunicipalities || [
    { name: 'Luanda (Ingombota, Maianga, Rangel, Sambizanga)', fee: 1500, estimatedHours: '2h - 6h' },
    { name: 'Talatona (Benfica, Morro Bento, Camama)', fee: 2000, estimatedHours: '3h - 8h' },
    { name: 'Belas (Kilamba, Centralidade do Kilamba)', fee: 2500, estimatedHours: '4h - 12h' },
    { name: 'Kilamba Kiaxi (Golf 1 e 2, Palanca)', fee: 2000, estimatedHours: '3h - 8h' },
    { name: 'Viana (Zango 1 a 4, Estalagem, Vila)', fee: 2500, estimatedHours: '4h - 12h' },
    { name: 'Cazenga (Hoji-ya-Henda, Tala Hady)', fee: 2000, estimatedHours: '3h - 8h' },
    { name: 'Cacuaco (Vila, Sequele, Kifangondo)', fee: 3000, estimatedHours: '6h - 24h' },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between animate-slide-in-right"
        onClick={e => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-slate-900">
              O Seu Carrinho de Compras
            </h2>
            <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-semibold">
              {items.reduce((s, i) => s + i.quantity, 0)}
            </span>
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            aria-label="Fechar carrinho"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h3 className="text-sm font-bold text-slate-800">O carrinho está vazio</h3>
              <p className="text-xs text-slate-500 max-w-xs">
                Explore os nossos produtos em destaque e adicione os melhores artigos com entrega rápida em Luanda.
              </p>
              <button
                onClick={() => setIsCartOpen(false)}
                className="mt-2 px-4 py-2 bg-[#0B1E36] text-white text-xs font-semibold rounded-xl hover:bg-[#132c4d] transition-colors"
              >
                Continuar a Comprar
              </button>
            </div>
          ) : (
            <>
              {/* Product list */}
              <div className="space-y-3">
                {items.map((item, idx) => {
                  const itemKey = `${item.product.id}-${item.selectedSize || ''}-${item.selectedColor || ''}-${idx}`;
                  return (
                    <div
                      key={itemKey}
                      className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200/60"
                    >
                      <img
                        src={item.product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg'}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 object-contain p-1 rounded-lg bg-white shrink-0 border border-slate-100"
                      />

                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-semibold text-slate-800 line-clamp-1">
                          {item.product.name}
                        </h4>

                        {(item.selectedSize || item.selectedColor) && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {item.selectedSize && (
                              <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                                Tam: {item.selectedSize}
                              </span>
                            )}
                            {item.selectedColor && (
                              <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-800">
                                Cor: {item.selectedColor}
                              </span>
                            )}
                          </div>
                        )}

                        <p className="text-xs font-bold text-[#0B1E36] font-mono tabular-nums mt-1">
                          {item.product.price.toLocaleString('pt-AO')} Kz
                        </p>

                        {/* Quantity adjuster */}
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center border border-slate-300 rounded-md bg-white">
                            <button
                              onClick={() =>
                                updateQuantity(
                                  item.product.id,
                                  item.quantity - 1,
                                  item.selectedSize,
                                  item.selectedColor
                                )
                              }
                              className="p-1 text-slate-600 hover:bg-slate-100"
                              aria-label="Diminuir"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-semibold text-slate-800 font-mono tabular-nums">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() =>
                                updateQuantity(
                                  item.product.id,
                                  item.quantity + 1,
                                  item.selectedSize,
                                  item.selectedColor
                                )
                              }
                              className="p-1 text-slate-600 hover:bg-slate-100"
                              aria-label="Aumentar"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            onClick={() =>
                              removeItem(item.product.id, item.selectedSize, item.selectedColor)
                            }
                            className="text-slate-400 hover:text-rose-600 p-1 transition-colors"
                            title="Remover"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Luanda Municipality Selector for Shipping */}
              <div className="pt-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-amber-500" />
                  <span>Selecionar Município de Entrega em Luanda:</span>
                </label>
                <select
                  value={selectedMunicipality}
                  onChange={e => setSelectedMunicipality(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
                >
                  {municipalities.map(m => (
                    <option key={m.name} value={m.name}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              {hasFreeShipping && (
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200/80 text-[11px] text-emerald-800 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Parabéns! O seu pedido qualifica para <strong>Entrega Grátis em Luanda</strong>!
                  </span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Drawer Footer with Financial Totals */}
        {items.length > 0 && (
          <div className="p-5 border-t border-slate-200 bg-slate-50 space-y-3">
            <div className="space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Subtotal dos produtos:</span>
                <span className="font-semibold text-slate-900 font-mono tabular-nums">
                  {subtotal.toLocaleString('pt-AO')} Kz
                </span>
              </div>
              <div className="flex justify-between">
                <span>Taxa de entrega em Luanda:</span>
                <span className="font-semibold font-mono tabular-nums">
                  {shippingFee === 0 || hasFreeShipping ? (
                    <span className="text-emerald-600 font-bold">GRÁTIS</span>
                  ) : (
                    `${shippingFee.toLocaleString('pt-AO')} Kz`
                  )}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline text-sm">
                <span className="font-bold text-slate-900">Total a Pagar:</span>
                <span className="font-extrabold text-lg text-[#0B1E36] font-mono tabular-nums">
                  {total.toLocaleString('pt-AO')} Kz
                </span>
              </div>
              <p className="text-[10px] text-slate-600 text-right">
                Pagamento no acto da entrega (Apenas Dinheiro ou Multicaixa Express)
              </p>
            </div>

            <div className="space-y-2 pt-1">
              <button
                onClick={() => {
                  setIsCartOpen(false);
                  onProceedToCheckout();
                }}
                className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.98]"
              >
                <span>Finalizar Compra</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={clearCart}
                className="w-full py-2 text-center text-xs text-slate-500 hover:text-slate-800 transition-colors"
              >
                Limpar carrinho
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
