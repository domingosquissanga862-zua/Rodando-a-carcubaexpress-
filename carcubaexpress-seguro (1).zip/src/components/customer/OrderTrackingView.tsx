import React, { useState, useEffect } from 'react';
import { Search, Package, Clock, CheckCircle2, Truck, AlertCircle, MessageCircle, MapPin, Calendar, UserCheck, Phone, FileText, Download, ShieldCheck } from 'lucide-react';
import { api } from '../../services/api';
import { useCart } from '../../context/CartContext';
import type { Order, OrderStatus } from '../../types';
import { generateOrderInvoicePDF } from '../../utils/pdfExport';
import { formatEstimatedDeliveryDate } from '../../utils/deliveryEstimation';
import { resolveProductImage, cleanAndNormalizeProductName } from '../../utils/productImages';

interface OrderTrackingViewProps {
  initialOrderNumber?: string;
  onBackToStore: () => void;
}

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({ initialOrderNumber, onBackToStore }) => {
  const { settings } = useCart();
  const whatsappPhone = (settings?.whatsappNumber || '244951556411').replace(/\D/g, '');
  const [searchTerm, setSearchTerm] = useState(initialOrderNumber || '');
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchOrder = async (numberToLookup: string) => {
    if (!numberToLookup.trim()) return;
    setIsLoading(true);
    setError('');
    try {
      const res = await api.getOrder(numberToLookup.trim(), true);
      setOrder(res.order);
    } catch (err: any) {
      setOrder(null);
      setError(err.message || 'Pedido não encontrado. Verifique o número introduzido.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialOrderNumber) {
      fetchOrder(initialOrderNumber);
    }
  }, [initialOrderNumber]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchOrder(searchTerm);
  };

  const statusSteps = [
    { label: 'Pendente', desc: 'Pedido recebido' },
    { label: 'Em preparação', desc: 'A embalar e preparar' },
    { label: 'Em transporte', desc: 'Com o estafeta a caminho' },
    { label: 'Entregue', desc: 'Chegou ao cliente' },
    { label: 'Pagamento confirmado', desc: 'Validado pelo administrador' },
  ];

  const getLogisticalStepIndex = (status: OrderStatus) => {
    if (status === 'Cancelado') return -1;
    if (status === 'Entregue') return 3;
    if (status === 'Em transporte') return 2;
    if (status === 'Em preparação' || (status as string) === 'processando') return 1;
    return 0; // Pendente
  };

  const isCancelled = order?.status === 'Cancelado';
  const logisticalStep = order ? getLogisticalStepIndex(order.status) : 0;
  const isPaymentConfirmed = order?.paymentStatus === 'Confirmado';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Search Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">
          <Truck className="w-3.5 h-3.5 text-amber-600" />
          <span>Localização e Acompanhamento de Entregas em Luanda</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0B1E36]">
          Acompanhe o Seu Pedido em Tempo Real
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          Insira o número da sua encomenda (ex: <code className="text-amber-600 font-mono font-semibold">CAR-2026-001</code>) para consultar o estado do envio.
        </p>

        <form onSubmit={handleSearch} className="max-w-md mx-auto flex gap-2 pt-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              required
              placeholder="Ex: CAR-2026-001"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="px-5 py-2.5 bg-[#0B1E36] hover:bg-[#132c4d] text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-sm cursor-pointer"
          >
            {isLoading ? 'A pesquisar...' : 'Consultar'}
          </button>
        </form>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs sm:text-sm text-rose-700 flex items-center gap-3 max-w-md mx-auto">
          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Order Results */}
      {order && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden animate-fade-in">
          {/* Header */}
          <div className="p-6 bg-[#0B1E36] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                  Pedido Confirmado
                </span>
                <span className="text-slate-400">·</span>
                <span className="text-xs text-slate-300 font-mono">{order.orderNumber}</span>
              </div>
              <h2 className="text-lg font-bold mt-1 text-white">
                Olá, {order.customerName}
              </h2>
            </div>

            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              {/* Logistical Status Badge */}
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold ${
                  isCancelled
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : order.status === 'Entregue'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}
              >
                Logística: {order.status}
              </span>

              {/* Independent Payment Status Badge */}
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                  isPaymentConfirmed
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${isPaymentConfirmed ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'}`} />
                {isPaymentConfirmed
                  ? 'Pagamento: Confirmado com sucesso'
                  : 'Pagamento: Pendente (No acto da entrega)'}
              </span>

              {(order.status === 'Entregue' || order.paymentStatus === 'Confirmado') && (
                <button
                  onClick={() => generateOrderInvoicePDF(order, settings)}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                  title="Descarregar Fatura / Recibo Oficial (PDF)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Fatura Recibo</span>
                </button>
              )}

              <a
                href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent(
                  `Olá CarcubaExpress! Gostaria de consultar o estado do meu pedido *${order.orderNumber}*.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Suporte WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Stepper Progress Bar */}
          <div className="p-6 sm:p-8 border-b border-slate-100 bg-slate-50/50">
            {isCancelled ? (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                <div>
                  <p className="font-bold">Este pedido foi cancelado.</p>
                  <p className="text-rose-600 mt-0.5">
                    Caso tenha dúvidas ou pretenda reativar a encomenda, entre em contacto com a nossa equipa pelo WhatsApp.
                  </p>
                </div>
              </div>
            ) : (
              <div className="relative">
                {/* Horizontal line for desktop */}
                <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-slate-200 -translate-y-1/2 z-0" />
                <div
                  className="hidden md:block absolute top-1/2 left-0 h-1 bg-amber-500 -translate-y-1/2 z-0 transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(0, ((logisticalStep + (isPaymentConfirmed ? 1 : 0)) / 4) * 100))}%`,
                  }}
                />

                <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 relative z-10">
                  {statusSteps.map((stepObj, idx) => {
                    let isDone = false;
                    let isCurrent = false;

                    if (idx <= 3) {
                      isDone = logisticalStep >= idx;
                      isCurrent = logisticalStep === idx;
                    } else if (idx === 4) {
                      // Step 5: Pagamento confirmado (strictly dependent on payment status)
                      isDone = isPaymentConfirmed;
                      isCurrent = !isPaymentConfirmed && logisticalStep >= 3;
                    }

                    return (
                      <div key={stepObj.label} className="flex md:flex-col items-center gap-3 md:text-center">
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all shrink-0 ${
                            isDone
                              ? 'bg-amber-500 text-slate-900 shadow-md'
                              : 'bg-white border-2 border-slate-300 text-slate-400'
                          } ${isCurrent ? 'ring-4 ring-amber-100' : ''}`}
                        >
                          {isDone ? <CheckCircle2 className="w-5 h-5" /> : idx + 1}
                        </div>

                        <div>
                          <p
                            className={`text-xs font-semibold ${
                              isDone ? 'text-slate-900' : 'text-slate-400'
                            }`}
                          >
                            {stepObj.label}
                          </p>
                          <span className="text-[10px] text-slate-400 block hidden md:block">
                            {stepObj.desc}
                          </span>
                          {isCurrent && (
                            <span className="text-[10px] text-amber-600 font-bold block">
                              Em curso
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* High-Visibility Estimated Delivery Date Card */}
          {(() => {
            const deliveryEstimate = formatEstimatedDeliveryDate(
              order.estimatedDeliveryDate,
              order.createdAt,
              order.deliveryMunicipality
            );

            return (
              <div className="mx-6 sm:mx-8 mt-6 p-5 sm:p-6 bg-gradient-to-br from-amber-50/90 via-white to-slate-50 border-2 border-amber-300/80 rounded-2xl sm:rounded-3xl shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-200/60">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-900 flex items-center justify-center font-bold shrink-0 shadow-xs">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-black uppercase tracking-wider text-amber-900">
                          Previsão de Entrega ao Domicílio
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200/80 text-amber-900">
                          {order.status === 'Entregue' ? 'Concluída' : deliveryEstimate.relativeLabel}
                        </span>
                      </div>
                      <h3 className="text-base sm:text-lg font-black text-[#0B1E36]">
                        {order.status === 'Entregue'
                          ? 'Encomenda Entregue ao Cliente'
                          : deliveryEstimate.formattedDate}
                      </h3>
                    </div>
                  </div>

                  <div className="sm:text-right bg-white/80 sm:bg-transparent p-2.5 sm:p-0 rounded-xl border sm:border-0 border-amber-100">
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">
                      Janela de Entrega
                    </span>
                    <span className="text-xs font-bold text-slate-800 flex items-center sm:justify-end gap-1">
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      {deliveryEstimate.timeWindow}
                    </span>
                  </div>
                </div>

                {/* Status-specific delivery message */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Destino em Luanda</span>
                      <strong className="text-slate-900 font-bold block">{order.deliveryMunicipality}</strong>
                      <span className="text-[11px] text-slate-500 line-clamp-1">{order.deliveryAddress}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                    <Truck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Estado do Envio</span>
                      <strong className="text-slate-900 font-bold block">{order.status}</strong>
                      <span className="text-[11px] text-slate-500">
                        {order.status === 'Entregue'
                          ? 'Artigo rececionado com sucesso'
                          : order.status === 'Em transporte'
                          ? 'Estafeta em trânsito com o seu artigo'
                          : order.status === 'Em preparação'
                          ? 'A ser embalado e conferido'
                          : 'Aguardando despacho logístico'}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Pagamento Protegido</span>
                      <strong className="text-slate-900 font-bold block">No acto da entrega</strong>
                      <span className="text-[11px] text-slate-500">Dinheiro ou Multicaixa Express</span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-600 bg-amber-100/50 p-2.5 rounded-xl border border-amber-200/50 flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                  <span>
                    <strong>Atenção:</strong> O nosso estafeta entrará sempre em contacto consigo por chamada ou WhatsApp antes da deslocação para confirmar a sua localização exata.
                  </span>
                </p>
              </div>
            );
          })()}

          {/* Delivered & Confirmed Payment Receipt Banner */}
          {(order.status === 'Entregue' || order.paymentStatus === 'Confirmado') && (
            <div className="mx-6 sm:mx-8 mt-6 p-4 sm:p-5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
              <div className="flex items-start gap-3.5">
                <div className="p-3 bg-emerald-600 text-white rounded-xl shadow-xs shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Fatura / Recibo de Venda Liquidado (FR-{order.orderNumber})
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    A sua encomenda foi entregue com sucesso e o pagamento foi validado. Pode descarregar ou imprimir a sua fatura/recibo oficial para efeitos de garantia.
                  </p>
                </div>
              </div>
              <button
                onClick={() => generateOrderInvoicePDF(order, settings)}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-colors shrink-0 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Descarregar Recibo PDF</span>
              </button>
            </div>
          )}

          {/* Details & Delivery Dispatcher */}
          <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Delivery Courier / Logistics */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-amber-500" />
                Dados do Envio em Luanda
              </h3>

              <div className="space-y-3 text-xs text-slate-700 bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold block">{order.deliveryMunicipality}</span>
                    <span className="text-slate-500">{order.deliveryAddress}</span>
                    {order.deliveryReference && (
                      <span className="block text-[11px] text-slate-400 mt-0.5">
                        Ref: {order.deliveryReference}
                      </span>
                    )}
                  </div>
                </div>

                {(order.courierName || order.deliveryAgent) && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-amber-100 text-amber-800 rounded-lg shrink-0">
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[11px] text-amber-800 font-semibold uppercase tracking-wider block">
                          Estafeta Responsável
                        </span>
                        <strong className="text-slate-900 font-bold text-xs block">
                          {order.courierName || order.deliveryAgent}
                        </strong>
                        {order.courierPhone && (
                          <span className="text-slate-600 font-mono text-[11px] block mt-0.5">
                            {order.courierPhone}
                          </span>
                        )}
                      </div>
                    </div>

                    {order.courierPhone && (
                      <a
                        href={`https://wa.me/${order.courierPhone.replace(/\D/g, '')}?text=${encodeURIComponent(
                          `Olá! Sou ${order.customerName}, cliente da CarcubaExpress referente ao pedido ${order.orderNumber}.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors shrink-0 shadow-xs"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Falar com Estafeta</span>
                      </a>
                    )}
                  </div>
                )}

                {(() => {
                  const est = formatEstimatedDeliveryDate(
                    order.estimatedDeliveryDate,
                    order.createdAt,
                    order.deliveryMunicipality
                  );
                  return (
                    <div className="flex items-center gap-2 p-2.5 bg-blue-50/80 rounded-xl border border-blue-200/70 text-blue-950">
                      <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                      <div>
                        <span className="text-[10px] uppercase font-bold text-blue-800 block">
                          Previsão de Entrega:
                        </span>
                        <strong className="text-slate-900 font-bold block text-xs">
                          {order.status === 'Entregue' ? 'Entregue ao cliente' : est.formattedDate}
                        </strong>
                      </div>
                    </div>
                  );
                })()}

                <div className="pt-2 border-t border-slate-200 flex justify-between">
                  <span className="text-slate-500">Forma de Pagamento:</span>
                  <span className="font-semibold text-slate-800">{order.paymentMethod}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500">Estado do Pagamento:</span>
                  <span className="font-semibold text-emerald-600">{order.paymentStatus}</span>
                </div>
              </div>
            </div>

            {/* Purchased Items */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Package className="w-4 h-4 text-amber-500" />
                Produtos Comprados
              </h3>

              <div className="space-y-2">
                {Array.isArray(order.items) && order.items.length > 0 ? (
                  order.items.map((item, i) => {
                    const cleanName = cleanAndNormalizeProductName(item.productName, item.productId);
                    const prodImage = resolveProductImage({
                      ...item,
                      productName: cleanName,
                    });

                    return (
                      <div
                        key={i}
                        className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 text-xs shadow-xs"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={prodImage}
                            alt={cleanName}
                            referrerPolicy="no-referrer"
                            className="w-12 h-12 object-cover rounded-xl bg-white shrink-0 border border-slate-200 shadow-xs"
                          />
                          <div>
                            <p className="font-bold text-slate-800 text-xs sm:text-sm line-clamp-1">{cleanName}</p>
                            <div className="flex items-center gap-2 mt-0.5 text-slate-400 font-mono text-[11px]">
                              <span>Qtd: {item.quantity}</span>
                              {item.size && <span>· Tam: {item.size}</span>}
                              {item.color && <span>· Cor: {item.color}</span>}
                            </div>
                          </div>
                        </div>
                        <span className="font-extrabold text-[#0B1E36] font-mono tabular-nums text-sm">
                          {(item.price * item.quantity).toLocaleString('pt-AO')} Kz
                        </span>
                      </div>
                    );
                  })
                ) : (
                  <div className="p-3 bg-slate-50 rounded-xl text-slate-500 text-xs italic">
                    Nenhum artigo discriminado neste pedido.
                  </div>
                )}
              </div>

              {/* Financial Totals */}
              <div className="pt-3 border-t border-slate-200 space-y-1.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-slate-800 font-mono tabular-nums">
                    {order.subtotal.toLocaleString('pt-AO')} Kz
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Taxa de Entrega:</span>
                  <span className="font-semibold font-mono tabular-nums">
                    {order.shippingFee === 0 ? 'GRÁTIS' : `${order.shippingFee.toLocaleString('pt-AO')} Kz`}
                  </span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-bold text-[#0B1E36]">
                  <span>Total da Compra:</span>
                  <span className="text-base text-amber-600 font-mono tabular-nums">
                    {order.total.toLocaleString('pt-AO')} Kz
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Status History Audit Trail */}
          {order.statusHistory && order.statusHistory.length > 0 && (
            <div className="p-6 sm:p-8 bg-slate-50 border-t border-slate-200 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Histórico de Atualizações do Pedido
              </h4>
              <div className="space-y-2">
                {order.statusHistory.map((hist, index) => {
                  const formatActor = (actor?: string) => {
                    if (!actor) return 'Equipa CarcubaExpress';
                    const clean = actor.toLowerCase().trim();
                    if (
                      clean.includes('@') ||
                      clean.includes('domingos') ||
                      clean.includes('quissanga') ||
                      clean.includes('admin') ||
                      clean.startsWith('user-') ||
                      clean.includes('supabase')
                    ) {
                      return 'Equipa CarcubaExpress';
                    }
                    if (order.customerName && clean.includes(order.customerName.toLowerCase().split(' ')[0])) {
                      return order.customerName.split(' ')[0];
                    }
                    return 'Equipa CarcubaExpress';
                  };

                  return (
                    <div key={index} className="flex items-start gap-3 text-xs text-slate-600">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-slate-800">{hist.status}</span>
                        <span className="text-slate-400 mx-1.5">·</span>
                        <span className="text-[11px] text-slate-400">
                          {new Date(hist.timestamp).toLocaleString('pt-PT')} ({formatActor(hist.changedBy)})
                        </span>
                        {hist.note && <p className="text-[11px] text-slate-500 italic mt-0.5">{hist.note}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Back to store */}
      <div className="text-center pt-4">
        <button
          onClick={onBackToStore}
          className="text-xs text-slate-500 hover:text-slate-800 font-semibold"
        >
          ← Voltar à Loja CarcubaExpress
        </button>
      </div>
    </div>
  );
};
