import React, { useState, useEffect } from 'react';
import { User, Phone, Mail, Package, Clock, ShieldCheck, Shield, LogOut, ArrowRight, RefreshCw, MessageCircle, FileText, Download, Calendar } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { api } from '../../services/api';
import type { Order } from '../../types';
import { generateOrderInvoicePDF } from '../../utils/pdfExport';
import { formatEstimatedDeliveryDate } from '../../utils/deliveryEstimation';
import { cleanAndNormalizeProductName } from '../../utils/productImages';

interface CustomerPortalProps {
  onTrackOrder: (orderNumber: string) => void;
  onBackToStore: () => void;
  onNavigateAdmin?: () => void;
}

export const CustomerPortal: React.FC<CustomerPortalProps> = ({ onTrackOrder, onBackToStore, onNavigateAdmin }) => {
  const { user, isAdmin, logout } = useAuth();
  const { settings } = useCart();
  const whatsappPhone = (settings?.whatsappNumber || '244951556411').replace(/\D/g, '');
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadMyOrders = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const isOfficialStoreAdmin =
        isAdmin && user.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com';

      // Requisita estritamente os pedidos do utilizador se for cliente
      const res = await api.getOrders({
        onlyForUser: isOfficialStoreAdmin
          ? undefined
          : {
              email: user.email,
              id: user.id,
            },
      });

      // Dupla camada de isolamento e privacidade rigorosa:
      // Garante que uma conta recém-criada NUNCA veja pedidos de outro cliente
      // Isolamento estrito por email do utilizador autenticado e ID de conta
      let userOrders = res.orders;
      if (!isOfficialStoreAdmin) {
        const uEmail = user.email.toLowerCase().trim();

        userOrders = userOrders.filter(o => {
          // 1. Validar por email (campo oficial da encomenda ou notas)
          const ordEmail = (o.customerEmail || '').toLowerCase().trim();
          if (ordEmail && ordEmail === uEmail) return true;

          if (o.notes) {
            const match = o.notes.match(/Email:\s*([^\s|]+@[^\s|]+)/i);
            if (match && match[1].toLowerCase().trim() === uEmail) return true;
          }

          // 2. Validar por ID de conta Supabase
          if (o.customerId && user.id && String(o.customerId) === String(user.id)) return true;

          // Nunca herdar pedidos de outros utilizadores
          return false;
        });
      }

      setOrders(userOrders);
    } catch (err) {
      console.error('Erro ao carregar pedidos do cliente:', err);
      setOrders([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      loadMyOrders();
    } else {
      onBackToStore();
    }
  }, [user, onBackToStore]);

  if (!user) {
    return null;
  }

  const isOfficialAdmin = isAdmin && user.email.toLowerCase().trim() === 'domingosquissanga862@gmail.com';
  const displayName = isOfficialAdmin
    ? 'Domingos Quissanga'
    : user.name === 'Administrador CarcubaExpress'
    ? 'Cliente CarcubaExpress'
    : user.name;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fade-in text-xs">
      {/* Header Profile Bar */}
      <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-600 font-extrabold text-xl flex items-center justify-center">
            {displayName.charAt(0)}
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900">{displayName}</h1>
            <div className="flex flex-wrap items-center gap-3 text-slate-500 mt-1">
              <span className="flex items-center gap-1 font-mono">
                <Phone className="w-3.5 h-3.5 text-amber-500" />
                {user.phone}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-amber-500" />
                {user.email}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center flex-wrap">
          {isOfficialAdmin && onNavigateAdmin && (
            <button
              onClick={onNavigateAdmin}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              title="Aceder ao Painel Administrativo CarcubaExpress"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Painel de Administração</span>
            </button>
          )}

          <button
            onClick={logout}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-rose-500" />
            <span>Terminar Sessão</span>
          </button>
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Os Meus Pedidos</h2>
            <p className="text-slate-500">Histórico de encomendas efetuadas na CarcubaExpress</p>
          </div>
          <button
            onClick={loadMyOrders}
            className="p-2 bg-white text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl"
            title="Atualizar"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {orders.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
            <Package className="w-10 h-10 mx-auto text-slate-300" />
            <h3 className="font-bold text-slate-800 text-sm">Ainda não realizou nenhum pedido</h3>
            <p className="text-slate-500 max-w-sm mx-auto">
              Aproveite os nossos preços em Kwanza com entrega rápida em Luanda e pagamento no acto da entrega.
            </p>
            <button
              onClick={onBackToStore}
              className="mt-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl"
            >
              Ver Produtos em Destaque
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map(order => (
              <div
                key={order.id}
                className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 card-hover animate-slide-up"
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900 text-sm">
                      {order.orderNumber}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-500">
                      {new Date(order.createdAt).toLocaleDateString('pt-PT')}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        order.status === 'Entregue'
                          ? 'bg-emerald-100 text-emerald-800'
                          : order.status === 'Cancelado'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {order.status}
                    </span>
                  </div>

                  {/* Items summary */}
                  <div className="text-slate-600 font-medium">
                    {Array.isArray(order.items) && order.items.length > 0
                      ? order.items
                          .map(
                            i =>
                              `${i.quantity || 1}x ${cleanAndNormalizeProductName(
                                i.productName,
                                i.productId
                              )}`
                          )
                          .join(' · ')
                      : 'Artigos da Encomenda'}
                  </div>

                  <div className="text-[11px] text-slate-500">
                    Entrega em: <strong className="text-slate-700">{order.deliveryMunicipality}</strong>
                  </div>

                  {(() => {
                    const est = formatEstimatedDeliveryDate(
                      order.estimatedDeliveryDate,
                      order.createdAt,
                      order.deliveryMunicipality
                    );
                    return (
                      <div className="flex items-center gap-1.5 text-[11px] font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg w-fit border border-blue-200/60 mt-0.5">
                        <Calendar className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span>
                          Previsão de Entrega:{' '}
                          <strong className="text-slate-900">
                            {order.status === 'Entregue' ? 'Entregue com sucesso' : est.formattedDate}
                          </strong>
                        </span>
                      </div>
                    );
                  })()}
                </div>

                <div className="flex items-center gap-4 justify-between md:justify-end border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">Total da Encomenda</span>
                    <span className="font-mono font-extrabold text-[#0B1E36] text-sm tabular-nums">
                      {order.total.toLocaleString('pt-AO')} Kz
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {(order.status === 'Entregue' || order.paymentStatus === 'Confirmado') && (
                      <button
                        onClick={() => generateOrderInvoicePDF(order, settings)}
                        className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer border border-emerald-200"
                        title="Descarregar Fatura / Recibo Liquidado (PDF)"
                      >
                        <FileText className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Recibo</span>
                      </button>
                    )}

                    <button
                      onClick={() => onTrackOrder(order.orderNumber)}
                      className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Acompanhar</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <a
                      href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent(
                        `Olá CarcubaExpress! Gostaria de falar sobre o meu pedido *${order.orderNumber}*.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl transition-colors cursor-pointer"
                      title="Suporte no WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="pt-4 text-center">
        <button onClick={onBackToStore} className="text-slate-500 hover:text-slate-800 font-semibold">
          ← Voltar ao Catálogo da Loja
        </button>
      </div>
    </div>
  );
};
