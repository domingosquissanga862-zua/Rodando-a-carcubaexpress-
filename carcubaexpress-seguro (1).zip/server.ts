import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { authenticate } from './server/auth.js';
import { authRouter } from './server/routes/auth.js';
import { productsRouter } from './server/routes/products.js';
import { ordersRouter } from './server/routes/orders.js';
import { categoriesRouter } from './server/routes/categories.js';
import { financialsRouter } from './server/routes/financials.js';
import { settingsRouter } from './server/routes/settings.js';
import { customersRouter } from './server/routes/customers.js';
import { supabaseRouter } from './server/routes/supabase.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  // Cybersecurity Headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=()');
    next();
  });

  // Brute-force protection for login attempts
  const loginAttempts = new Map<string, { count: number; resetAt: number }>();
  app.use('/api/auth/login', (req, res, next) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    const entry = loginAttempts.get(ip);

    if (entry) {
      if (now > entry.resetAt) {
        loginAttempts.set(ip, { count: 1, resetAt: now + 5 * 60 * 1000 });
      } else if (entry.count >= 15) {
        return res.status(429).json({
          error: 'Demasiadas tentativas de início de sessão. Por favor aguarde 5 minutos por motivos de segurança.',
        });
      } else {
        entry.count += 1;
      }
    } else {
      loginAttempts.set(ip, { count: 1, resetAt: now + 5 * 60 * 1000 });
    }
    next();
  });

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Attach session/auth middleware
  app.use(authenticate);

  // Mount API endpoints
  app.use('/api/auth', authRouter);
  app.use('/api/products', productsRouter);
  app.use('/api/orders', ordersRouter);
  app.use('/api/categories', categoriesRouter);
  app.use('/api/financials', financialsRouter);
  app.use('/api/settings', settingsRouter);
  app.use('/api/customers', customersRouter);
  app.use('/api/supabase', supabaseRouter);

  // Prevent API fallback to SPA index.html: all unmatched /api/* requests return 404 JSON
  app.all('/api/*', (_req, res) => {
    res.status(404).json({ error: 'Endpoint da API não encontrado.' });
  });

  // Serve static assets from public
  app.use('/assets', express.static(path.resolve(__dirname, 'public/assets')));

  if (!isProd) {
    // Development mode: Vite middleware
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT,
      },
      appType: 'spa',
    });

    app.use(vite.middlewares);
  } else {
    // Production mode: Serve built dist
    const distPath = path.resolve(__dirname, 'dist');
    // Páginas legais públicas (sem redirecionamento de barra final, sem autenticação)
    for (const slug of ['privacy-policy', 'terms']) {
      app.get([`/${slug}`, `/${slug}/`], (_req, res) => {
        res.sendFile(path.resolve(distPath, slug, 'index.html'));
      });
    }
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CarcubaExpress] Servidor ativo em http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[CarcubaExpress] Falha ao iniciar servidor:', err);
  process.exit(1);
});
