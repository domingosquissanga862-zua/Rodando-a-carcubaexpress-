import { Router } from 'express';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { requireAdmin, type AuthenticatedRequest } from '../auth.js';
import type { Order, OrderItem, OrderStatus, PaymentStatus, StatusHistoryEntry } from '../types.js';
import {
  syncOrderToSupabase,
  fetchOrdersFromSupabase,
  updateOrderStatusInSupabase,
  deleteOrderFromSupabase,
  fetchProductsFromSupabase,
  updateProductInSupabase,
} from '../supabase.js';

export const ordersRouter = Router();

// Function to generate pre-filled WhatsApp message
export function buildWhatsAppMessage(order: Order, whatsappNumber: string): { messageText: string; whatsappUrl: string } {
  const itemsText = order.items
    .map(i => `  ▫️ *${i.quantity}x* ${i.productName} — ${(i.price * i.quantity).toLocaleString('pt-AO')} Kz`)
    .join('\n');

  const lines = [
    `🛍️ *NOVO PEDIDO — CARCUBAEXPRESS COMÉRCIO*`,
    `----------------------------------------`,
    `📦 *Nº DO PEDIDO:* *${order.orderNumber}*`,
    `📅 *Data do Registo:* ${new Date(order.createdAt).toLocaleDateString('pt-PT')} às ${new Date(order.createdAt).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}`,
    ``,
    `👤 *DADOS DO CLIENTE:*`,
    `• *Nome:* ${order.customerName}`,
    `• *Contacto:* ${order.customerPhone}`,
    order.customerEmail ? `• *Email:* ${order.customerEmail}` : null,
    ``,
    `📍 *ENDEREÇO DE ENTREGA (LUANDA):*`,
    `• *Município:* ${order.deliveryMunicipality}`,
    `• *Morada:* ${order.deliveryAddress}`,
    order.deliveryReference ? `• *Ponto de Referência:* ${order.deliveryReference}` : null,
    ``,
    `🛒 *ITENS SELECIONADOS:*`,
    itemsText,
    ``,
    `💰 *RESUMO DE VALORES:*`,
    `• *Subtotal:* ${order.subtotal.toLocaleString('pt-AO')} Kz`,
    `• *Taxa de Entrega:* ${order.shippingFee === 0 ? 'GRÁTIS' : `${order.shippingFee.toLocaleString('pt-AO')} Kz`}`,
    `• *TOTAL A PAGAR NO ACTO DA ENTREGA:* *${order.total.toLocaleString('pt-AO')} Kz*`,
    ``,
    `💳 *FORMA DE PAGAMENTO:* *${order.paymentMethod}*`,
    ``,
    `🤝 *POLÍTICA DE PAGAMENTO CARCUBAEXPRESS:*`,
    `• Pagamento no acto da entrega em Luanda.`,
    `• Aceitamos exclusivamente *Dinheiro* e *Multicaixa Express*.`,
    `• Verifique a sua encomenda no acto do recebimento.`,
    ``,
    `Aguardo a confirmação da disponibilidade e envio da equipa CarcubaExpress! 🇦🇴`,
  ].filter(Boolean);

  const messageText = lines.join('\n');
  const cleanPhone = whatsappNumber.replace(/[^0-9]/g, '');
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(messageText)}`;

  return { messageText, whatsappUrl };
}

/**
 * Helper to get unified merged list of orders from Supabase and local store
 */
export function sanitizeStatusHistory(order: Order): Order {
  if (!order.statusHistory || !Array.isArray(order.statusHistory)) return order;
  const sanitized = order.statusHistory.map(entry => {
    let changedBy = entry.changedBy || 'Equipa CarcubaExpress';
    // If changedBy has an email, or contains domingos, or is admin email/username
    if (
      changedBy.includes('@') ||
      changedBy.toLowerCase().includes('domingos') ||
      changedBy.toLowerCase().includes('quissanga') ||
      changedBy.toLowerCase().includes('admin')
    ) {
      changedBy = 'Equipa CarcubaExpress';
    }
    return {
      ...entry,
      changedBy,
    };
  });
  return { ...order, statusHistory: sanitized };
}

async function getMergedOrders(): Promise<Order[]> {
  for (const lo of db.data.orders) {
    if (lo.statusHistory) {
      lo.statusHistory = lo.statusHistory.map(h => {
        if (
          h.changedBy?.includes('@') ||
          h.changedBy?.toLowerCase().includes('domingos') ||
          h.changedBy?.toLowerCase().includes('quissanga') ||
          h.changedBy?.toLowerCase().includes('admin')
        ) {
          return { ...h, changedBy: 'Equipa CarcubaExpress' };
        }
        return h;
      });
    }
  }

  const localOrders = [...db.data.orders];
  try {
    const supaOrders = await fetchOrdersFromSupabase();
    if (supaOrders && supaOrders.length > 0) {
      const mergedMap = new Map<string, Order>();

      // Put local orders first
      for (const lo of localOrders) {
        mergedMap.set(lo.orderNumber, sanitizeStatusHistory(lo));
      }

      // Add/merge Supabase orders
      for (const so of supaOrders) {
        if (!mergedMap.has(so.orderNumber)) {
          mergedMap.set(so.orderNumber, sanitizeStatusHistory(so));
        } else {
          // If local order exists, merge Supabase status if newer
          const existing = mergedMap.get(so.orderNumber)!;
          if (so.status && so.status !== existing.status) {
            existing.status = so.status;
          }
        }
      }

      return Array.from(mergedMap.values());
    }
  } catch (err) {
    console.warn('[Orders Sync] Aviso ao carregar pedidos do Supabase:', err);
  }
  return localOrders.map(sanitizeStatusHistory);
}

// GET orders (Admin gets all, customer gets only their own matched by ID, email, or phone)
ordersRouter.get('/', async (req: AuthenticatedRequest, res) => {
  const isAdmin = req.user?.role === 'admin';
  const customerId = req.user?.id;
  const userEmail = req.user?.email?.toLowerCase().trim();
  const userPhone = req.user?.phone ? req.user.phone.replace(/[^0-9]/g, '') : '';

  const allOrders = await getMergedOrders();

  if (isAdmin) {
    const { status, search } = req.query;
    let list = [...allOrders];

    if (status && typeof status === 'string' && status !== 'all') {
      list = list.filter(o => o.status.toLowerCase() === status.toLowerCase());
    }

    if (search && typeof search === 'string') {
      const term = search.toLowerCase().trim();
      list = list.filter(
        o =>
          o.orderNumber.toLowerCase().includes(term) ||
          o.customerName.toLowerCase().includes(term) ||
          o.customerPhone.includes(term) ||
          o.deliveryMunicipality.toLowerCase().includes(term)
      );
    }

    // Sort newest first
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return res.json({ orders: list });
  }

  // If customer is logged in, return their orders (matching ID, email, or phone)
  if (customerId) {
    const customerOrders = allOrders
      .filter(o => {
        if (o.customerId && o.customerId === customerId) return true;
        if (userEmail && o.customerEmail && o.customerEmail.toLowerCase().trim() === userEmail) return true;
        if (userPhone && o.customerPhone) {
          const cleanOPhone = o.customerPhone.replace(/[^0-9]/g, '');
          if (cleanOPhone.endsWith(userPhone) || userPhone.endsWith(cleanOPhone)) return true;
        }
        return false;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return res.json({ orders: customerOrders });
  }

  // If not logged in, require private authentication
  return res.status(401).json({ error: 'Inicie sessão com as suas credenciais privadas para aceder às suas encomendas.' });
});

// GET single order by ID or orderNumber
ordersRouter.get('/:idOrNumber', (req: AuthenticatedRequest, res) => {
  const { idOrNumber } = req.params;
  const order = db.data.orders.find(o => o.id === idOrNumber || o.orderNumber === idOrNumber);

  if (!order) {
    return res.status(404).json({ error: 'Pedido não encontrado.' });
  }

  // Authorization check: admin or order owner
  const isAdmin = req.user?.role === 'admin';
  const isOwner = Boolean(
    req.user && (
      order.customerId === req.user.id ||
      (req.user.email && order.customerEmail && order.customerEmail.toLowerCase().trim() === req.user.email.toLowerCase().trim())
    )
  );

  if (!isAdmin && !isOwner && !req.query.guestLookup) {
    return res.status(403).json({ error: 'Não tem permissão para aceder a este pedido.' });
  }

  let safeOrder = sanitizeStatusHistory(order);
  // Privacy Protection: Mask sensitive PII for unauthenticated guest lookups
  if (!isAdmin && !isOwner) {
    const maskPhone = (p: string) => {
      if (!p || p.length < 6) return p;
      return p.slice(0, 4) + ' ••• •' + p.slice(-3);
    };
    const maskEmail = (e?: string) => {
      if (!e) return undefined;
      const parts = e.split('@');
      if (parts.length < 2) return e;
      return (parts[0][0] || '') + '•••@' + parts[1];
    };
    safeOrder = {
      ...safeOrder,
      customerPhone: maskPhone(safeOrder.customerPhone),
      customerEmail: maskEmail(safeOrder.customerEmail),
    };
  }

  const { messageText, whatsappUrl } = buildWhatsAppMessage(safeOrder, db.data.settings.whatsappNumber);
  res.json({ order: safeOrder, whatsappMessage: messageText, whatsappUrl });
});

// POST create order (Public / Customer Checkout)
ordersRouter.post('/', async (req: AuthenticatedRequest, res) => {
  const {
    customerName,
    customerEmail,
    customerPhone,
    deliveryAddress,
    deliveryMunicipality,
    deliveryReference,
    items: incomingItems,
    paymentMethod,
    notes,
  } = req.body;

  if (!customerName || !customerPhone || !deliveryAddress || !deliveryMunicipality) {
    return res.status(400).json({ error: 'Por favor, preencha todos os dados obrigatórios de entrega.' });
  }

  if (!Array.isArray(incomingItems) || incomingItems.length === 0) {
    return res.status(400).json({ error: 'O carrinho está vazio.' });
  }

  // Synchronize and ensure product catalog is up to date with Supabase
  try {
    const supaProds = await fetchProductsFromSupabase();
    if (supaProds && supaProds.length > 0) {
      const pMap = new Map<string, any>();
      for (const sp of supaProds) pMap.set(sp.id, sp);
      for (const lp of db.data.products) if (!pMap.has(lp.id)) pMap.set(lp.id, lp);
      db.data.products = Array.from(pMap.values());
      db.save();
    }
  } catch (err: any) {
    console.warn('[Orders POST] Supabase product sync fallback:', err.message);
  }

  // SERVER-SIDE VALIDATION: verify each product, price, cost price, and stock
  let calculatedSubtotal = 0;
  let allHaveFreeShipping = true;
  const verifiedItems: OrderItem[] = [];

  for (const item of incomingItems) {
    const product = db.data.products.find(p => p.id === item.productId || p.slug === item.productId);
    if (!product) {
      return res.status(400).json({ error: `O produto "${item.productName || item.productId}" já não se encontra disponível.` });
    }

    if (!product.isActive) {
      return res.status(400).json({ error: `O produto "${product.name}" está temporariamente indisponível.` });
    }

    const qty = parseInt(item.quantity, 10);
    if (isNaN(qty) || qty <= 0) {
      return res.status(400).json({ error: `Quantidade inválida para o produto "${product.name}".` });
    }

    if (product.stock < qty) {
      return res.status(400).json({
        error: `Stock insuficiente para "${product.name}". Apenas ${product.stock} unidade(s) disponível(is).`,
      });
    }

    if (!product.freeShipping) {
      allHaveFreeShipping = false;
    }

    // Use strictly the server database price
    const unitPrice = product.price;
    calculatedSubtotal += unitPrice * qty;

    verifiedItems.push({
      productId: product.id,
      productName: product.name,
      price: unitPrice,
      costPrice: product.costPrice || Math.round(unitPrice * 0.6),
      quantity: qty,
      image: product.images[0] || '/assets/aistudio/mic-circular_f8930c2d.jpg',
    });
  }

  // Calculate Shipping fee for Luanda
  const municipalityConfig = db.data.settings.deliveryMunicipalities.find(
    m => m.name.toLowerCase() === deliveryMunicipality.toLowerCase()
  );
  let shippingFee = municipalityConfig ? municipalityConfig.fee : db.data.settings.defaultShippingFee;

  // Free shipping check: if product qualifies or order exceeds threshold
  if (allHaveFreeShipping || calculatedSubtotal >= db.data.settings.freeShippingMinAmount) {
    shippingFee = 0;
  }

  const grandTotal = calculatedSubtotal + shippingFee;

  // Reduce product stock in database and Supabase atomically
  for (const item of verifiedItems) {
    const product = db.data.products.find(p => p.id === item.productId);
    if (product) {
      product.stock = Math.max(0, product.stock - item.quantity);
      product.updatedAt = new Date().toISOString();
      updateProductInSupabase(product.id, { stock: product.stock }).catch(e => {
        console.warn(`[Supabase Stock Sync] Erro ao sincronizar stock no Supabase:`, e);
      });
    }
  }

  // Generate sequential/formatted order number CAR-2026-XXX
  const currentOrdersList = await getMergedOrders();
  const orderCount = currentOrdersList.length + 1;
  const orderNumber = `CAR-2026-${String(orderCount).padStart(3, '0')}`;

  const initialStatus: OrderStatus = 'Pendente';
  const initialPaymentStatus: PaymentStatus =
    paymentMethod === 'Pagamento no acto da entrega' ? 'No acto da entrega' : 'Pendente';

  const newOrder: Order = {
    id: `ord-${crypto.randomUUID()}`,
    orderNumber,
    customerId: req.user ? req.user.id : undefined,
    customerName: customerName.trim(),
    customerEmail: customerEmail ? customerEmail.trim() : undefined,
    customerPhone: customerPhone.trim(),
    deliveryAddress: deliveryAddress.trim(),
    deliveryMunicipality: deliveryMunicipality.trim(),
    deliveryReference: deliveryReference ? deliveryReference.trim() : undefined,
    items: verifiedItems,
    subtotal: calculatedSubtotal,
    shippingFee,
    total: grandTotal,
    paymentMethod: paymentMethod || 'Pagamento no acto da entrega',
    paymentStatus: initialPaymentStatus,
    status: initialStatus,
    statusHistory: [
      {
        status: initialStatus,
        timestamp: new Date().toISOString(),
        changedBy: req.user?.name || customerName.trim(),
        note: 'Pedido submetido pelo cliente no website.',
      },
    ],
    notes: notes ? notes.trim() : undefined,
    whatsappSent: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.data.orders.unshift(newOrder);
  db.save();

  // Asynchronously synchronize order to Supabase
  syncOrderToSupabase(newOrder).then(result => {
    if (result.success) {
      console.log(`[Supabase] Pedido ${newOrder.orderNumber} sincronizado com sucesso com Supabase (ID #${result.supabaseOrderId})`);
    } else {
      console.log(`[Supabase] Pedido guardado localmente; sincronização com Supabase: ${result.error}`);
    }
  }).catch(err => {
    console.warn('[Supabase] Falha ao sincronizar pedido:', err);
  });

  const { messageText, whatsappUrl } = buildWhatsAppMessage(newOrder, db.data.settings.whatsappNumber);

  res.status(201).json({
    message: 'Pedido realizado com sucesso!',
    order: newOrder,
    whatsappMessage: messageText,
    whatsappUrl,
  });
});

// PATCH update order status (Admin only)
ordersRouter.patch('/:id/status', requireAdmin, (req: AuthenticatedRequest, res) => {
  const target = db.data.orders.find(o => o.id === req.params.id);
  if (!target) {
    return res.status(404).json({ error: 'Pedido não encontrado.' });
  }

  const {
    status,
    paymentStatus,
    note,
    courierName,
    courierPhone,
    deliveryAgent,
    estimatedDeliveryDate,
  } = req.body;

  const validStatuses: OrderStatus[] = [
    'Pendente',
    'A aguardar pagamento',
    'Pagamento confirmado',
    'Em preparação',
    'Em transporte',
    'Entregue',
    'Cancelado',
  ];

  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Estado de pedido inválido.' });
  }

  // Check rule: Cannot switch directly from Cancelado to Entregue without explicit authorization
  if (target.status === 'Cancelado' && status === 'Entregue') {
    return res.status(400).json({
      error: 'Regra de negócio: Um pedido Cancelado não pode ser marcado diretamente como Entregue.',
    });
  }

  // If canceling order, restore stock
  if (status === 'Cancelado' && target.status !== 'Cancelado') {
    for (const item of target.items) {
      const prod = db.data.products.find(p => p.id === item.productId);
      if (prod) {
        prod.stock += item.quantity;
      }
    }
  }

  // If un-canceling an order, re-check and decrement stock
  if (target.status === 'Cancelado' && status !== 'Cancelado') {
    for (const item of target.items) {
      const prod = db.data.products.find(p => p.id === item.productId);
      if (prod) {
        prod.stock = Math.max(0, prod.stock - item.quantity);
      }
    }
  }

  target.status = status;

  // Courier information
  if (courierName !== undefined) {
    target.courierName = courierName.trim();
    target.deliveryAgent = courierName.trim();
  } else if (deliveryAgent !== undefined) {
    target.deliveryAgent = deliveryAgent.trim();
    target.courierName = deliveryAgent.trim();
  }

  if (courierPhone !== undefined) {
    target.courierPhone = courierPhone.trim();
  }

  if (estimatedDeliveryDate !== undefined) {
    target.estimatedDeliveryDate = estimatedDeliveryDate;
  }

  // Explicit payment status update only (strictly decoupled from logistical status)
  if (paymentStatus) {
    target.paymentStatus = paymentStatus;
  }

  const statusNote =
    note ||
    (target.courierName
      ? `Estafeta: ${target.courierName}${target.courierPhone ? ` (${target.courierPhone})` : ''}`
      : undefined);

  target.statusHistory.push({
    status,
    timestamp: new Date().toISOString(),
    changedBy: 'Equipa CarcubaExpress',
    note: statusNote,
  });

  target.updatedAt = new Date().toISOString();
  db.save();

  // Synchronize status update to Supabase
  updateOrderStatusInSupabase(target.orderNumber, status, {
    paymentStatus: target.paymentStatus,
    notes: target.notes,
  }).catch(err => {
    console.warn('[Supabase Status Update] Erro ao sincronizar estado:', err);
  });

  res.json({
    message: `Estado atualizado para "${status}".`,
    order: target,
  });
});

// PATCH update payment status (Admin only)
ordersRouter.patch('/:id/payment', requireAdmin, (req: AuthenticatedRequest, res) => {
  const target = db.data.orders.find(o => o.id === req.params.id);
  if (!target) {
    return res.status(404).json({ error: 'Pedido não encontrado.' });
  }

  const { paymentStatus, note } = req.body;
  const validPaymentStatuses: PaymentStatus[] = ['Pendente', 'Confirmado', 'No acto da entrega', 'Cancelado', 'Reembolsado'];

  if (!validPaymentStatuses.includes(paymentStatus)) {
    return res.status(400).json({ error: 'Estado de pagamento inválido.' });
  }

  target.paymentStatus = paymentStatus;
  target.updatedAt = new Date().toISOString();

  if (paymentStatus === 'Confirmado' && target.status === 'A aguardar pagamento') {
    target.status = 'Pagamento confirmado';
    target.statusHistory.push({
      status: 'Pagamento confirmado',
      timestamp: new Date().toISOString(),
      changedBy: 'Equipa CarcubaExpress',
      note: note || 'Pagamento validado pelo administrador.',
    });
  }

  db.save();

  // Sync to Supabase
  updateOrderStatusInSupabase(target.orderNumber, target.status, {
    paymentStatus,
    notes: target.notes,
  }).catch(err => {
    console.warn('[Supabase Payment Update] Erro ao sincronizar pagamento:', err);
  });

  res.json({ message: 'Estado de pagamento atualizado com sucesso.', order: target });
});

// PATCH update delivery info (Admin only)
ordersRouter.patch('/:id/delivery', requireAdmin, (req, res) => {
  const target = db.data.orders.find(o => o.id === req.params.id);
  if (!target) {
    return res.status(404).json({ error: 'Pedido não encontrado.' });
  }

  const { courierName, courierPhone, deliveryAgent, estimatedDeliveryDate, notes } = req.body;

  if (courierName !== undefined) {
    target.courierName = courierName.trim();
    target.deliveryAgent = courierName.trim();
  } else if (deliveryAgent !== undefined) {
    target.deliveryAgent = deliveryAgent.trim();
    target.courierName = deliveryAgent.trim();
  }

  if (courierPhone !== undefined) {
    target.courierPhone = courierPhone.trim();
  }

  if (estimatedDeliveryDate !== undefined) {
    target.estimatedDeliveryDate = estimatedDeliveryDate;
  }

  if (notes !== undefined) {
    target.notes = notes;
  }

  target.updatedAt = new Date().toISOString();
  db.save();

  res.json({ message: 'Informações de entrega e estafeta atualizadas.', order: target });
});

// DELETE order (Admin only)
ordersRouter.delete('/:id', requireAdmin, async (req: AuthenticatedRequest, res) => {
  const idOrNumber = req.params.id;
  const index = db.data.orders.findIndex(o => o.id === idOrNumber || o.orderNumber === idOrNumber);

  let removedOrder: Order | undefined;
  if (index !== -1) {
    removedOrder = db.data.orders[index];
    db.data.orders.splice(index, 1);
    db.save();
  }

  // Delete from Supabase
  const supaResult = await deleteOrderFromSupabase(removedOrder?.orderNumber || idOrNumber);

  res.json({
    message: `Pedido ${removedOrder?.orderNumber || idOrNumber} eliminado com sucesso.`,
    supabaseResult: supaResult,
  });
});
