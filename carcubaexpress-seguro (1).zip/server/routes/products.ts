import { Router } from 'express';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { requireAdmin, type AuthenticatedRequest } from '../auth.js';
import type { Product } from '../types.js';
import {
  fetchProductsFromSupabase,
  insertProductToSupabase,
  updateProductInSupabase,
  deleteProductFromSupabase,
  clearAllProductsFromSupabase,
} from '../supabase.js';

export const productsRouter = Router();

// GET all products (Public: active only, unless admin is querying)
productsRouter.get('/', async (req: AuthenticatedRequest, res) => {
  const { category, search, activeOnly, featured } = req.query;
  const isAdmin = req.user?.role === 'admin';

  let list: Product[] = [];

  try {
    // Attempt to fetch fresh live products from Supabase
    const supabaseProducts = await fetchProductsFromSupabase();

    if (supabaseProducts && supabaseProducts.length > 0) {
      // Merge with local database to ensure local enriched data & assets are preserved
      const mergedMap = new Map<string, Product>();

      // Put Supabase products
      for (const sp of supabaseProducts) {
        mergedMap.set(sp.id, sp);
      }

      // Ensure local products with richer assets/slugs exist if not in Supabase
      for (const lp of db.data.products) {
        const found = supabaseProducts.find(
          sp => sp.id === lp.id || sp.slug === lp.slug || sp.name.toLowerCase() === lp.name.toLowerCase()
        );
        if (!found) {
          mergedMap.set(lp.id, lp);
        } else {
          // If Supabase product had no image or default image, preserve high-res local image
          if (lp.images && lp.images.length > 0 && (!found.images || found.images.length === 0)) {
            found.images = lp.images;
          }
        }
      }

      list = Array.from(mergedMap.values());
    } else {
      list = [...db.data.products];
    }
  } catch (err: any) {
    console.warn('[Products Router] Fallback para base de dados local:', err.message);
    list = [...db.data.products];
  }

  // If not admin or explicitly requested activeOnly, filter by isActive
  if (!isAdmin || activeOnly === 'true') {
    list = list.filter(p => p.isActive);
  }

  if (category && typeof category === 'string' && category !== 'all') {
    list = list.filter(p => p.categoryId === category || p.categoryName?.toLowerCase() === category.toLowerCase());
  }

  if (featured === 'true') {
    list = list.filter(p => p.isFeatured);
  }

  if (search && typeof search === 'string') {
    const term = search.toLowerCase().trim();
    list = list.filter(
      p =>
        p.name.toLowerCase().includes(term) ||
        p.description?.toLowerCase().includes(term) ||
        p.categoryName?.toLowerCase().includes(term)
    );
  }

  res.json({ products: list });
});

// GET single product by ID
productsRouter.get('/:id', async (req, res) => {
  try {
    const supabaseProducts = await fetchProductsFromSupabase();
    const found = supabaseProducts.find(p => p.id === req.params.id || p.slug === req.params.id);
    if (found) {
      return res.json({ product: found });
    }
  } catch {
    // fallback
  }

  const product = db.data.products.find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Produto não encontrado.' });
  }
  res.json({ product });
});

// POST new product (Admin only)
productsRouter.post('/', requireAdmin, async (req: AuthenticatedRequest, res) => {
  const {
    name,
    description,
    price,
    costPrice,
    promoPrice,
    categoryId,
    categoryName: clientCategoryName,
    images,
    stock,
    isActive,
    isFeatured,
    freeShipping,
  } = req.body;

  if (!name || price === undefined || stock === undefined || !categoryId) {
    return res.status(400).json({ error: 'Nome, preço de venda, quantidade em stock e categoria são obrigatórios.' });
  }

  const numericPrice = Number(price);
  if (isNaN(numericPrice) || numericPrice <= 0) {
    return res.status(400).json({ error: 'O preço de venda deve ser maior que zero.' });
  }

  // Resolve categoryName accurately
  let categoryName = clientCategoryName;
  if (!categoryName) {
    const category = db.data.categories.find(c => c.id === categoryId || c.slug === categoryId || c.name.toLowerCase() === categoryId.toLowerCase());
    if (category) {
      categoryName = category.name;
    } else if (categoryId === 'perfumaria' || categoryId === 'cat-perfumes' || categoryId.toLowerCase().includes('perfum')) {
      categoryName = 'Perfumaria & Fragrâncias';
    } else if (categoryId === 'audio') {
      categoryName = 'Áudio & Gravação';
    } else if (categoryId === 'cat-eletronicos') {
      categoryName = 'Eletrónicos & Som';
    } else {
      categoryName = 'Eletrónicos & Som';
    }
  }

  const slug = name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');

  const productPayload: Partial<Product> = {
    name: name.trim(),
    slug: `${slug}-${Date.now().toString().slice(-4)}`,
    description: description ? description.trim() : '',
    price: numericPrice,
    costPrice: costPrice !== undefined ? Number(costPrice) : Math.round(numericPrice * 0.6),
    promoPrice: promoPrice ? Number(promoPrice) : undefined,
    categoryId,
    categoryName,
    images: Array.isArray(images) && images.length > 0 ? images : ['/assets/aistudio/mic-circular_f8930c2d.jpg'],
    stock: Math.max(0, parseInt(stock, 10)),
    isActive: isActive !== undefined ? Boolean(isActive) : true,
    isFeatured: isFeatured !== undefined ? Boolean(isFeatured) : false,
    freeShipping: freeShipping !== undefined ? Boolean(freeShipping) : false,
  };

  // Attempt Supabase insert operation
  const supabaseResult = await insertProductToSupabase(productPayload);

  let productId: string;
  let statusMessage: string;
  let warningMessage: string | undefined;

  if (supabaseResult.success && supabaseResult.insertedProduct?.id) {
    productId = String(supabaseResult.insertedProduct.id);
    statusMessage = 'Produto cadastrado com sucesso no Supabase e publicado na loja pública!';
  } else {
    // If Supabase RLS blocked insert, assign local ID and publish to store anyway so the product is live!
    productId = `prod-${Date.now().toString().slice(-6)}`;
    if (supabaseResult.code === '42501') {
      warningMessage = 'Produto publicado na loja! Sincronização direta com o Supabase aguarda execução do comando SQL no Supabase Dashboard.';
    } else {
      warningMessage = `Produto publicado na loja! Aviso de sincronização: ${supabaseResult.error || 'Aguardando sincronização'}`;
    }
    statusMessage = `Produto cadastrado e publicado na loja! ${warningMessage}`;
    console.warn('[Products Router]:', warningMessage);
  }

  const newProduct: Product = {
    ...productPayload,
    id: productId,
    createdAt: supabaseResult.insertedProduct?.created_at || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  } as Product;

  db.data.products.unshift(newProduct);
  db.save();

  res.status(201).json({
    message: statusMessage,
    product: newProduct,
    supabaseSynced: Boolean(supabaseResult.success),
    warning: warningMessage,
  });
});

// PUT update product (Admin only)
productsRouter.put('/:id', requireAdmin, async (req: AuthenticatedRequest, res) => {
  const target = db.data.products.find(p => p.id === req.params.id);

  const {
    name,
    description,
    price,
    costPrice,
    promoPrice,
    categoryId,
    categoryName,
    images,
    stock,
    isActive,
    isFeatured,
    freeShipping,
  } = req.body;

  let resolvedCategoryName = categoryName;
  if (!resolvedCategoryName && categoryId) {
    const cat = db.data.categories.find(c => c.id === categoryId || c.slug === categoryId);
    if (cat) {
      resolvedCategoryName = cat.name;
    } else if (categoryId === 'perfumaria' || categoryId === 'cat-perfumes' || categoryId.toLowerCase().includes('perfum')) {
      resolvedCategoryName = 'Perfumaria & Fragrâncias';
    } else if (categoryId === 'audio') {
      resolvedCategoryName = 'Áudio & Gravação';
    } else if (categoryId === 'cat-eletronicos') {
      resolvedCategoryName = 'Eletrónicos & Som';
    }
  }

  const updateData: Partial<Product> = {
    name,
    description,
    price,
    costPrice,
    promoPrice,
    categoryId,
    categoryName: resolvedCategoryName,
    images,
    stock,
    isActive,
    isFeatured,
    freeShipping,
  };

  // Sync to Supabase
  await updateProductInSupabase(req.params.id, updateData);

  if (target) {
    if (name) target.name = name.trim();
    if (description !== undefined) target.description = description.trim();
    if (price !== undefined) target.price = Number(price);
    if (costPrice !== undefined) target.costPrice = Number(costPrice);
    if (promoPrice !== undefined) target.promoPrice = promoPrice ? Number(promoPrice) : undefined;
    if (categoryId) {
      target.categoryId = categoryId;
      target.categoryName = resolvedCategoryName || target.categoryName;
    } else if (resolvedCategoryName) {
      target.categoryName = resolvedCategoryName;
    }
    if (Array.isArray(images) && images.length > 0) target.images = images;
    if (stock !== undefined) target.stock = Math.max(0, parseInt(stock, 10));
    if (isActive !== undefined) target.isActive = Boolean(isActive);
    if (isFeatured !== undefined) target.isFeatured = Boolean(isFeatured);
    if (freeShipping !== undefined) target.freeShipping = Boolean(freeShipping);

    target.updatedAt = new Date().toISOString();
    db.save();
  }

  res.json({ message: 'Produto atualizado com sucesso no Supabase e na loja.', product: target || updateData });
});

// PATCH toggle active state (Admin only)
productsRouter.patch('/:id/toggle', requireAdmin, async (req, res) => {
  const target = db.data.products.find(p => p.id === req.params.id);

  const newActiveState = target ? !target.isActive : true;

  // Sync to Supabase
  await updateProductInSupabase(req.params.id, { isActive: newActiveState });

  if (target) {
    target.isActive = newActiveState;
    target.updatedAt = new Date().toISOString();
    db.save();
  }

  res.json({ message: `Estado do produto alternado com sucesso.`, active: newActiveState });
});

// DELETE product (Admin only)
productsRouter.delete('/:id', requireAdmin, async (req, res) => {
  const targetId = String(req.params.id);

  // Sync deletion with Supabase
  const supaResult = await deleteProductFromSupabase(targetId);

  // Identify product name for confirmation message
  let removedName = supaResult.deletedProduct?.name || 'Produto';

  // Remove from local database by matching id, slug, or name
  const removeIndex = db.data.products.findIndex(p => {
    if (p.id === targetId || p.slug === targetId) return true;
    if (supaResult.deletedProduct) {
      if (String(p.id) === String(supaResult.deletedProduct.id)) return true;
      if (p.slug === supaResult.deletedProduct.slug) return true;
      if (p.name.toLowerCase() === supaResult.deletedProduct.name?.toLowerCase()) return true;
    }
    // Also handle initial 3 products fallback mappings if targetId was numeric
    if (targetId === '1' && p.name.toLowerCase().includes('asad')) return true;
    if (targetId === '2' && p.name.toLowerCase().includes('circular')) return true;
    if (targetId === '3' && (p.name.toLowerCase().includes('quadrado') || p.name.toLowerCase().includes('tx'))) return true;
    return false;
  });

  if (removeIndex !== -1) {
    removedName = db.data.products[removeIndex].name;
    db.data.products.splice(removeIndex, 1);
    db.save();
  }

  if (supaResult.error) {
    console.warn('[Products DELETE] Supabase aviso:', supaResult.error);
    return res.status(200).json({
      success: true,
      message: `Produto "${removedName}" removido da loja. (Aviso Supabase: ${supaResult.error})`,
      warning: supaResult.error,
      id: targetId,
    });
  }

  res.json({
    success: true,
    message: `Produto "${removedName}" eliminado com sucesso no Supabase e na loja.`,
    id: targetId,
    deletedProduct: supaResult.deletedProduct,
  });
});

// POST /api/products/clear-all (Admin only: removes all products from store & Supabase)
productsRouter.post('/clear-all', requireAdmin, async (_req, res) => {
  const count = db.data.products.length;
  db.data.products = [];
  db.save();

  const supaResult = await clearAllProductsFromSupabase();

  res.json({
    success: true,
    message: 'Todos os produtos foram removidos com sucesso da loja e da base de dados Supabase.',
    removedCount: count,
    supabase: supaResult,
  });
});

