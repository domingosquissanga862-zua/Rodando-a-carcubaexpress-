import { Router } from 'express';
import { db, initialProducts, initialCategories, initialSettings } from '../db.js';
import { requireAdmin } from '../auth.js';
import { fetchStoreSettingsFromSupabase, syncStoreSettingsToSupabase } from '../supabase.js';

export const settingsRouter = Router();

// GET store settings (Public)
settingsRouter.get('/', async (_req, res) => {
  try {
    // Attempt to hydrate latest settings from Supabase
    const supaSettings = await fetchStoreSettingsFromSupabase();
    if (supaSettings) {
      if (supaSettings.storeName) db.data.settings.storeName = supaSettings.storeName;
      if (supaSettings.whatsappNumber) db.data.settings.whatsappNumber = supaSettings.whatsappNumber;
      if (supaSettings.supportPhone) db.data.settings.supportPhone = supaSettings.supportPhone;
      if (supaSettings.email) db.data.settings.email = supaSettings.email;
      if (supaSettings.address) db.data.settings.address = supaSettings.address;
      if (supaSettings.city) db.data.settings.city = supaSettings.city;
      if (supaSettings.country) db.data.settings.country = supaSettings.country;
      if (supaSettings.defaultShippingFee !== undefined) db.data.settings.defaultShippingFee = supaSettings.defaultShippingFee;
      if (supaSettings.freeShippingMinAmount !== undefined) db.data.settings.freeShippingMinAmount = supaSettings.freeShippingMinAmount;
      db.save();
    }
  } catch (err: any) {
    console.warn('[Settings GET] Erro ao sincronizar com Supabase:', err.message);
  }

  res.json({ settings: db.data.settings });
});

// PUT update store settings (Admin only)
settingsRouter.put('/', requireAdmin, async (req, res) => {
  const {
    storeName,
    storeDescription,
    whatsappNumber,
    supportPhone,
    email,
    address,
    city,
    country,
    defaultShippingFee,
    freeShippingMinAmount,
    deliveryMunicipalities,
    deliveryPolicyTitle,
    deliveryPolicyText,
    paymentPolicyTitle,
    paymentPolicyText,
    termsPolicyTitle,
    termsPolicyText,
    supportPolicyTitle,
    supportPolicyText,
    footerDepartments,
  } = req.body;

  if (storeName) db.data.settings.storeName = storeName.trim();
  if (storeDescription !== undefined) db.data.settings.storeDescription = storeDescription.trim();
  if (whatsappNumber) db.data.settings.whatsappNumber = whatsappNumber.replace(/[^0-9]/g, '');
  if (supportPhone) db.data.settings.supportPhone = supportPhone.trim();
  if (email) db.data.settings.email = email.trim();
  if (address !== undefined) db.data.settings.address = address.trim();
  if (city) db.data.settings.city = city.trim();
  if (country) db.data.settings.country = country.trim();
  if (defaultShippingFee !== undefined) db.data.settings.defaultShippingFee = Number(defaultShippingFee);
  if (freeShippingMinAmount !== undefined) db.data.settings.freeShippingMinAmount = Number(freeShippingMinAmount);
  if (Array.isArray(deliveryMunicipalities)) {
    db.data.settings.deliveryMunicipalities = deliveryMunicipalities;
  }
  if (deliveryPolicyTitle !== undefined) db.data.settings.deliveryPolicyTitle = deliveryPolicyTitle.trim();
  if (deliveryPolicyText !== undefined) db.data.settings.deliveryPolicyText = deliveryPolicyText.trim();
  if (paymentPolicyTitle !== undefined) db.data.settings.paymentPolicyTitle = paymentPolicyTitle.trim();
  if (paymentPolicyText !== undefined) db.data.settings.paymentPolicyText = paymentPolicyText.trim();
  if (termsPolicyTitle !== undefined) db.data.settings.termsPolicyTitle = termsPolicyTitle.trim();
  if (termsPolicyText !== undefined) db.data.settings.termsPolicyText = termsPolicyText.trim();
  if (supportPolicyTitle !== undefined) db.data.settings.supportPolicyTitle = supportPolicyTitle.trim();
  if (supportPolicyText !== undefined) db.data.settings.supportPolicyText = supportPolicyText.trim();
  if (Array.isArray(footerDepartments)) {
    db.data.settings.footerDepartments = footerDepartments;
  }

  // Save to local persistence
  db.save();

  // Sync to Supabase public.store_settings
  const supaSyncResult = await syncStoreSettingsToSupabase(db.data.settings);

  res.json({
    message: supaSyncResult.success
      ? 'Configurações guardadas com sucesso no site e na base de dados Supabase.'
      : 'Configurações guardadas no site (com aviso ao sincronizar com Supabase).',
    settings: db.data.settings,
    supabaseSync: supaSyncResult,
  });
});

// POST restore / re-seed catalog (Admin only)
settingsRouter.post('/reset-catalog', requireAdmin, async (_req, res) => {
  db.data.products = [...initialProducts];
  db.data.categories = [...initialCategories];
  db.data.settings = { ...initialSettings };
  db.save();

  await syncStoreSettingsToSupabase(db.data.settings);

  res.json({ message: 'Catálogo de demonstração reinicializado com os produtos oficiais da CarcubaExpress.' });
});
