import { Router } from 'express';
import { testSupabaseConnection, supabaseServer, SUPABASE_URL } from '../supabase.js';
import { db } from '../db.js';
import { requireAdmin, type AuthenticatedRequest } from '../auth.js';

export const supabaseRouter = Router();

// GET /api/supabase/status - Check connection with Supabase
supabaseRouter.get('/status', async (_req, res) => {
  const status = await testSupabaseConnection();
  res.json(status);
});

// GET /api/supabase/products - Fetch products directly from Supabase
supabaseRouter.get('/products', async (_req, res) => {
  try {
    const { data, error } = await supabaseServer
      .from('products')
      .select('*')
      .order('id', { ascending: true });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ products: data || [] });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao consultar produtos no Supabase' });
  }
});

// GET /api/supabase/orders - Fetch orders from Supabase (Admin only)
supabaseRouter.get('/orders', requireAdmin, async (_req, res) => {
  try {
    const { data: orders, error: ordersErr } = await supabaseServer
      .from('orders')
      .select('*')
      .order('id', { ascending: false });

    if (ordersErr) {
      return res.status(400).json({ error: ordersErr.message });
    }

    res.json({ orders: orders || [] });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao consultar pedidos no Supabase' });
  }
});

// GET /api/supabase/sql-setup - Returns SQL instructions for the user's Supabase project
supabaseRouter.get('/sql-setup', (_req, res) => {
  const sql = `
-- ==============================================================================
-- CARCUBAEXPRESS - SCRIPT COMPLETO SUPABASE (TABELAS + RLS POLICIES)
-- Projeto: ${SUPABASE_URL}
-- Execução: Cole no Supabase Dashboard -> SQL Editor -> Clique em "RUN"
-- ==============================================================================

-- 1. Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- TABELA: CATEGORIES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- TABELA: PRODUCTS (Catálogo de Produtos)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.products (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT,
  description TEXT,
  price NUMERIC NOT NULL DEFAULT 0,
  cost_price NUMERIC DEFAULT 0,
  promo_price NUMERIC,
  category_id TEXT,
  category_name TEXT,
  images TEXT[] DEFAULT ARRAY[]::TEXT[],
  stock INTEGER NOT NULL DEFAULT 10,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  free_shipping BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Assegurar colunas adicionais caso a tabela já existisse previamente
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS slug TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS cost_price NUMERIC DEFAULT 0;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS promo_price NUMERIC;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS category_id TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS category_name TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS images TEXT[] DEFAULT ARRAY[]::TEXT[];
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS stock INTEGER DEFAULT 10;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS free_shipping BOOLEAN DEFAULT false;

-- ==============================================================================
-- TABELA: ORDERS (Pedidos dos Clientes)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.orders (
  id BIGSERIAL PRIMARY KEY,
  order_number TEXT,
  customer_name TEXT NOT NULL,
  phone TEXT,
  customer_phone TEXT,
  address TEXT,
  delivery_address TEXT,
  delivery_municipality TEXT,
  delivery_reference TEXT,
  subtotal NUMERIC DEFAULT 0,
  shipping_fee NUMERIC DEFAULT 0,
  total_kz NUMERIC NOT NULL DEFAULT 0,
  total NUMERIC DEFAULT 0,
  payment_method TEXT DEFAULT 'Pagamento no acto da entrega',
  payment_status TEXT DEFAULT 'Pendente',
  status TEXT NOT NULL DEFAULT 'Pendente',
  notes TEXT,
  whatsapp_sent BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Assegurar colunas de sincronização e compatibilidade
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS order_number TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_phone TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_address TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_municipality TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_reference TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS subtotal NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shipping_fee NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_kz NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT 'Pagamento no acto da entrega';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_id TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_date TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS estimated_delivery_date TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS whatsapp_sent BOOLEAN DEFAULT false;

-- ==============================================================================
-- TABELA: ORDER_ITEMS (Itens dos Pedidos)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.order_items (
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id TEXT,
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price_kz NUMERIC NOT NULL DEFAULT 0,
  cost_price NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS product_id TEXT;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS cost_price NUMERIC DEFAULT 0;

-- ==============================================================================
-- TABELA: EXPENSES (Despesas Financeiras - Acesso Admin)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.expenses (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  amount NUMERIC NOT NULL DEFAULT 0,
  date TEXT,
  note TEXT,
  created_by_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- TABELA: STORE_SETTINGS (Configurações da Loja)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.store_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  store_name TEXT DEFAULT 'CarcubaExpress',
  whatsapp_number TEXT DEFAULT '244936087579',
  support_phone TEXT DEFAULT '+244 936 087 579',
  email TEXT DEFAULT 'suporte@carcubaexpress.ao',
  city TEXT DEFAULT 'Luanda',
  country TEXT DEFAULT 'Angola',
  currency TEXT DEFAULT 'Kz',
  default_shipping_fee NUMERIC DEFAULT 2000,
  free_shipping_min_amount NUMERIC DEFAULT 50000,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) - ATIVAÇÃO
-- ==============================================================================
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- POLÍTICAS RLS (POLICIES)
-- ==============================================================================

-- Helper de Segurança: Validação de Administrador Oficial
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT COALESCE(
    (LOWER(TRIM(COALESCE(auth.jwt() ->> 'email', ''))) = 'domingosquissanga862@gmail.com') OR
    (auth.jwt() -> 'app_metadata' ->> 'role' = 'admin') OR
    (auth.jwt() -> 'user_metadata' ->> 'role' = 'admin'),
    FALSE
  );
$$;

-- 1. PRODUTOS:
-- Leitura pública para catálogo
DROP POLICY IF EXISTS "Permitir leitura de produtos" ON public.products;
CREATE POLICY "Permitir leitura de produtos" ON public.products
  FOR SELECT TO anon, authenticated
  USING (true);

-- Modificações restritas exclusivamente ao Administrador
DROP POLICY IF EXISTS "Permitir insercao de produtos" ON public.products;
CREATE POLICY "Admin insert products" ON public.products
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Permitir actualizacao de produtos" ON public.products;
CREATE POLICY "Admin update products" ON public.products
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Permitir eliminacao de produtos" ON public.products;
CREATE POLICY "Admin delete products" ON public.products
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- Alias para garantir compatibilidade
CREATE OR REPLACE VIEW public.produtos AS SELECT * FROM public.products;

-- 2. PEDIDOS:
-- Clientes podem criar pedidos na finalização de compra
DROP POLICY IF EXISTS "Permitir criacao de pedidos" ON public.orders;
CREATE POLICY "Permitir criacao de pedidos" ON public.orders
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

-- Leitura isolada: Administrador vê todos; Clientes autenticados apenas os seus próprios
DROP POLICY IF EXISTS "Permitir leitura de pedidos" ON public.orders;
CREATE POLICY "Secure orders select" ON public.orders
  FOR SELECT TO anon, authenticated
  USING (
    public.is_admin() OR
    (auth.uid() IS NOT NULL AND customer_id = auth.uid()::text) OR
    (auth.jwt() ->> 'email' IS NOT NULL AND customer_email = auth.jwt() ->> 'email')
  );

-- Atualização e Eliminação de pedidos exclusivas ao Administrador
DROP POLICY IF EXISTS "Permitir actualizacao de pedidos para autenticados" ON public.orders;
CREATE POLICY "Admin update orders" ON public.orders
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Orders admin delete" ON public.orders;
CREATE POLICY "Admin delete orders" ON public.orders
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- 3. ITENS DE PEDIDOS:
DROP POLICY IF EXISTS "Permitir criacao de itens de pedidos" ON public.order_items;
CREATE POLICY "Permitir criacao de itens de pedidos" ON public.order_items
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "Order items admin delete" ON public.order_items;
CREATE POLICY "Admin delete order items" ON public.order_items
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "Permitir leitura de itens de pedidos" ON public.order_items;
CREATE POLICY "Secure order items select" ON public.order_items
  FOR SELECT TO anon, authenticated
  USING (
    public.is_admin() OR
    EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = order_items.order_id AND (
        (auth.uid() IS NOT NULL AND o.customer_id = auth.uid()::text) OR
        (auth.jwt() ->> 'email' IS NOT NULL AND o.customer_email = auth.jwt() ->> 'email')
      )
    )
  );

-- 4. CATEGORIAS:
DROP POLICY IF EXISTS "Permitir leitura de categorias" ON public.categories;
CREATE POLICY "Permitir leitura de categorias" ON public.categories
  FOR SELECT TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "Permitir gestao de categorias para autenticados" ON public.categories;
CREATE POLICY "Admin manage categories" ON public.categories
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 5. DESPESAS: Totalmente confidenciais (Apenas Administrador)
DROP POLICY IF EXISTS "Permitir gestao de despesas para autenticados" ON public.expenses;
CREATE POLICY "Admin manage expenses" ON public.expenses
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 6. CONFIGURAÇÕES DA LOJA:
DROP POLICY IF EXISTS "Permitir leitura de configs da loja" ON public.store_settings;
CREATE POLICY "Permitir leitura de configs da loja" ON public.store_settings
  FOR SELECT TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "Permitir gestao de configs para autenticados" ON public.store_settings;
CREATE POLICY "Admin manage settings" ON public.store_settings
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Revogação preventiva de privilégios destrutivos anónimos
REVOKE DELETE, UPDATE, INSERT ON TABLE public.products FROM anon;
REVOKE DELETE, UPDATE, INSERT ON TABLE public.categories FROM anon;
REVOKE DELETE, UPDATE ON TABLE public.orders FROM anon;
REVOKE DELETE, UPDATE ON TABLE public.order_items FROM anon;
REVOKE ALL ON TABLE public.expenses FROM anon;
REVOKE DELETE, UPDATE, INSERT ON TABLE public.store_settings FROM anon;

-- ==============================================================================
-- DADOS INICIAIS (SEED) - 3 PRODUTOS EXCLUSIVOS DA CARCUBAEXPRESS
-- ==============================================================================
INSERT INTO public.categories (id, name, slug, description)
VALUES 
  ('perfumaria', 'Perfumaria & Fragrâncias', 'perfumaria', 'Perfumes originais Lattafa e fragrâncias premium'),
  ('audio', 'Áudio & Gravação', 'audio', 'Microfones de lapela sem fios profissionais')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.store_settings (id, store_name, whatsapp_number, support_phone, email, city, country, currency, default_shipping_fee, free_shipping_min_amount)
VALUES ('default', 'CarcubaExpress', '244936087579', '+244 936 087 579', 'suporte@carcubaexpress.ao', 'Luanda', 'Angola', 'Kz', 2000, 50000)
ON CONFLICT (id) DO NOTHING;

-- Notificação de sucesso
SELECT 'Configuração concluída com sucesso! Tabelas e políticas RLS ativadas para o CarcubaExpress.' AS resultado;
`.trim();

  res.json({
    projectUrl: SUPABASE_URL,
    sqlScript: sql,
  });
});
