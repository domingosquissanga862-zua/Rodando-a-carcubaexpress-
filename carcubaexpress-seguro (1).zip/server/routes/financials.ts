import { Router } from 'express';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { requireAdmin, type AuthenticatedRequest } from '../auth.js';
import type { Expense, Product, Order } from '../types.js';
import { fetchProductsFromSupabase, fetchOrdersFromSupabase } from '../supabase.js';

export const financialsRouter = Router();

// GET financial metrics (Admin only)
financialsRouter.get('/summary', requireAdmin, async (req, res) => {
  const { period, date, startDate, endDate } = req.query; // 'all', 'today', '7d', '30d' or custom date

  // Synchronize and load live products from Supabase and local DB
  let products: Product[] = [];
  try {
    const supabaseProducts = await fetchProductsFromSupabase();
    if (supabaseProducts && supabaseProducts.length > 0) {
      const pMap = new Map<string, Product>();
      for (const sp of supabaseProducts) {
        pMap.set(sp.id, sp);
      }
      for (const lp of db.data.products) {
        if (!pMap.has(lp.id)) {
          pMap.set(lp.id, lp);
        }
      }
      products = Array.from(pMap.values());
      // Keep db.data.products in sync
      if (db.data.products.length === 0 || db.data.products.length !== products.length) {
        db.data.products = [...products];
        db.save();
      }
    } else {
      products = [...db.data.products];
    }
  } catch (err: any) {
    console.warn('[Financials] Fallback para produtos locais:', err.message);
    products = [...db.data.products];
  }

  // Synchronize and load live orders from Supabase and local DB
  let orders: Order[] = [...db.data.orders];
  try {
    const supabaseOrders = await fetchOrdersFromSupabase();
    if (supabaseOrders && supabaseOrders.length > 0) {
      const oMap = new Map<string, Order>();
      for (const lo of db.data.orders) {
        oMap.set(lo.orderNumber, lo);
      }
      for (const so of supabaseOrders) {
        if (!oMap.has(so.orderNumber)) {
          oMap.set(so.orderNumber, so);
        }
      }
      orders = Array.from(oMap.values());
    }
  } catch (err: any) {
    console.warn('[Financials] Fallback para pedidos locais:', err.message);
  }

  const expenses = db.data.expenses;
  const now = new Date();
  let filteredOrders = [...orders];
  let filteredExpenses = [...expenses];

  if (date && typeof date === 'string') {
    const targetDate = date.trim();
    filteredOrders = orders.filter(o => o.createdAt.startsWith(targetDate));
    filteredExpenses = expenses.filter(e => e.date === targetDate || e.createdAt.startsWith(targetDate));
  } else if (startDate || endDate) {
    if (startDate && typeof startDate === 'string') {
      filteredOrders = filteredOrders.filter(o => o.createdAt.slice(0, 10) >= startDate);
      filteredExpenses = filteredExpenses.filter(e => (e.date || e.createdAt.slice(0, 10)) >= startDate);
    }
    if (endDate && typeof endDate === 'string') {
      filteredOrders = filteredOrders.filter(o => o.createdAt.slice(0, 10) <= endDate);
      filteredExpenses = filteredExpenses.filter(e => (e.date || e.createdAt.slice(0, 10)) <= endDate);
    }
  } else if (period === 'today') {
    const todayStr = now.toISOString().split('T')[0];
    filteredOrders = orders.filter(o => o.createdAt.startsWith(todayStr));
    filteredExpenses = expenses.filter(e => e.date === todayStr || e.createdAt.startsWith(todayStr));
  } else if (period === '7d') {
    const cutoff = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    filteredOrders = orders.filter(o => new Date(o.createdAt) >= cutoff);
    filteredExpenses = expenses.filter(e => new Date(e.date) >= cutoff);
  } else if (period === '30d') {
    const cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    filteredOrders = orders.filter(o => new Date(o.createdAt) >= cutoff);
    filteredExpenses = expenses.filter(e => new Date(e.date) >= cutoff);
  }

  // Non-cancelled orders
  const activeOrders = filteredOrders.filter(o => o.status !== 'Cancelado');
  const deliveredOrders = filteredOrders.filter(o => o.status === 'Entregue');
  const paidOrders = filteredOrders.filter(o => o.paymentStatus === 'Confirmado');

  // Total Gross Sales / Revenue (from active orders)
  const totalRevenue = activeOrders.reduce((sum, o) => sum + o.total, 0);

  // Confirmed Paid Revenue
  const confirmedPaidRevenue = paidOrders.reduce((sum, o) => sum + o.total, 0);

  // Delivered orders revenue
  const deliveredRevenue = deliveredOrders.reduce((sum, o) => sum + o.total, 0);

  // Cost of Goods Sold (CPV)
  const cogsTotal = activeOrders.reduce((sum, o) => {
    const orderCost = o.items.reduce((acc, i) => acc + (i.costPrice || 0) * i.quantity, 0);
    return sum + orderCost;
  }, 0);

  const cogsDelivered = deliveredOrders.reduce((sum, o) => {
    const orderCost = o.items.reduce((acc, i) => acc + (i.costPrice || 0) * i.quantity, 0);
    return sum + orderCost;
  }, 0);

  // Total Operating Expenses
  const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Estimated Net Profit = Active Revenue - COGS - Expenses
  const estimatedNetProfit = totalRevenue - cogsTotal - totalExpenses;

  // Realized Net Profit = Confirmed Delivered Revenue - Delivered COGS - Expenses
  const confirmedNetProfit = deliveredRevenue - cogsDelivered - totalExpenses;

  // Order Counts by Status
  const statusCounts = {
    total: filteredOrders.length,
    pendentes: filteredOrders.filter(o => o.status === 'Pendente').length,
    aguardandoPagamento: filteredOrders.filter(o => o.status === 'A aguardar pagamento').length,
    emPreparacao: filteredOrders.filter(o => o.status === 'Em preparação').length,
    emTransporte: filteredOrders.filter(o => o.status === 'Em transporte').length,
    entregues: deliveredOrders.length,
    cancelados: filteredOrders.filter(o => o.status === 'Cancelado').length,
  };

  // Average Order Value (Ticket Médio)
  const averageOrderValue = activeOrders.length > 0 ? Math.round(totalRevenue / activeOrders.length) : 0;

  // Products stock status (live from products catalog)
  const totalProducts = products.length;
  const availableProducts = products.filter(p => p.isActive && p.stock > 0).length;
  const lowStockProducts = products.filter(p => p.stock > 0 && p.stock <= 5);
  const outOfStockProducts = products.filter(p => p.stock === 0);

  // 7-Day sales history for charting
  const last7Days: { date: string; label: string; sales: number; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = d.toLocaleDateString('pt-PT', { weekday: 'short', day: '2-digit', month: '2-digit' });
    
    const dayOrders = orders.filter(o => o.status !== 'Cancelado' && o.createdAt.startsWith(dateStr));
    const daySales = dayOrders.reduce((sum, o) => sum + o.total, 0);
    
    last7Days.push({
      date: dateStr,
      label: dayLabel,
      sales: daySales,
      count: dayOrders.length,
    });
  }

  // Sales by category
  const categorySalesMap = new Map<string, { name: string; totalSales: number; unitsSold: number }>();
  for (const o of activeOrders) {
    for (const item of o.items) {
      const prod = products.find(p => p.id === item.productId);
      const catName = prod?.categoryName || 'Geral';
      const existing = categorySalesMap.get(catName) || { name: catName, totalSales: 0, unitsSold: 0 };
      existing.totalSales += item.price * item.quantity;
      existing.unitsSold += item.quantity;
      categorySalesMap.set(catName, existing);
    }
  }

  res.json({
    period: period || (date ? 'custom-date' : 'all'),
    selectedDate: (date as string) || (period === 'today' ? now.toISOString().split('T')[0] : null),
    currency: 'Kz',
    totalRevenue,
    confirmedPaidRevenue,
    deliveredRevenue,
    cogsTotal,
    totalExpenses,
    estimatedNetProfit,
    confirmedNetProfit,
    averageOrderValue,
    statusCounts,
    productStats: {
      total: totalProducts,
      available: availableProducts,
      lowStockCount: lowStockProducts.length,
      outOfStockCount: outOfStockProducts.length,
      lowStockList: lowStockProducts,
      allProductsList: products,
    },
    last7Days,
    categorySales: Array.from(categorySalesMap.values()),
    formulaDescription: 'Lucro Líquido Estimado = Receita Bruta de Vendas (Pedidos Activos) - Custo das Mercadorias Vendidas (CPV) - Despesas Operacionais Registadas',
  });
});

// GET all expenses (Admin only)
financialsRouter.get('/expenses', requireAdmin, (_req, res) => {
  const sorted = [...db.data.expenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  res.json({ expenses: sorted });
});

// POST new expense (Admin only)
financialsRouter.post('/expenses', requireAdmin, (req: AuthenticatedRequest, res) => {
  const { title, category, amount, date, note } = req.body;

  if (!title || !category || amount === undefined) {
    return res.status(400).json({ error: 'Título, categoria e valor da despesa são obrigatórios.' });
  }

  const numAmount = Number(amount);
  if (isNaN(numAmount) || numAmount <= 0) {
    return res.status(400).json({ error: 'O valor da despesa deve ser um número positivo.' });
  }

  const newExpense: Expense = {
    id: `exp-${crypto.randomUUID()}`,
    title: title.trim(),
    category,
    amount: numAmount,
    date: date || new Date().toISOString().split('T')[0],
    note: note ? note.trim() : undefined,
    createdById: req.user?.id || 'admin',
    createdByName: req.user?.name || 'Administrador',
    createdAt: new Date().toISOString(),
  };

  db.data.expenses.unshift(newExpense);
  db.save();

  res.status(201).json({ message: 'Despesa registada com sucesso.', expense: newExpense });
});

// PUT update expense (Admin only)
financialsRouter.put('/expenses/:id', requireAdmin, (req: AuthenticatedRequest, res) => {
  const target = db.data.expenses.find(e => e.id === req.params.id);
  if (!target) {
    return res.status(404).json({ error: 'Despesa não encontrada.' });
  }

  const { title, category, amount, date, note } = req.body;
  if (title !== undefined) target.title = String(title).trim();
  if (category !== undefined) target.category = category;
  if (amount !== undefined) {
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'O valor da despesa deve ser um número positivo.' });
    }
    target.amount = numAmount;
  }
  if (date !== undefined) target.date = date;
  if (note !== undefined) target.note = note ? String(note).trim() : undefined;

  db.save();
  res.json({ message: 'Despesa atualizada com sucesso.', expense: target });
});

// DELETE expense (Admin only)
financialsRouter.delete('/expenses/:id', requireAdmin, (req, res) => {
  const index = db.data.expenses.findIndex(e => e.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Despesa não encontrada.' });
  }

  const removed = db.data.expenses.splice(index, 1)[0];
  db.save();

  res.json({ message: `Despesa "${removed.title}" removida com sucesso.`, id: req.params.id });
});
