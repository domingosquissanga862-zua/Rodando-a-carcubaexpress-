import { Router } from 'express';
import { db } from '../db.js';
import { requireAdmin } from '../auth.js';

export const customersRouter = Router();

// GET all registered customers with purchase metrics (Admin only)
customersRouter.get('/', requireAdmin, (_req, res) => {
  const customers = db.data.users.filter(u => u.role === 'customer');

  const customerList = customers.map(c => {
    const orders = db.data.orders.filter(
      o => o.customerId === c.id || o.customerPhone.replace(/[^0-9]/g, '') === c.phone.replace(/[^0-9]/g, '')
    );
    const nonCancelled = orders.filter(o => o.status !== 'Cancelado');
    const totalSpent = nonCancelled.reduce((sum, o) => sum + o.total, 0);

    return {
      id: c.id,
      name: c.name,
      email: c.email,
      phone: c.phone,
      createdAt: c.createdAt,
      ordersCount: orders.length,
      totalSpent,
      lastOrderDate: orders.length > 0 ? orders[0].createdAt : null,
    };
  });

  res.json({ customers: customerList });
});
