import { Router } from 'express';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { requireAdmin } from '../auth.js';
import type { Category } from '../types.js';
import {
  fetchCategoriesFromSupabase,
  insertCategoryToSupabase,
  updateCategoryInSupabase,
  deleteCategoryFromSupabase,
} from '../supabase.js';

export const categoriesRouter = Router();

// GET all categories (Synchronized with Supabase)
categoriesRouter.get('/', async (_req, res) => {
  try {
    const supabaseCategories = await fetchCategoriesFromSupabase();

    if (supabaseCategories && supabaseCategories.length > 0) {
      const mergedMap = new Map<string, Category>();

      // 1. Add categories from Supabase
      for (const sc of supabaseCategories) {
        mergedMap.set(String(sc.id), {
          id: String(sc.id),
          name: sc.name,
          slug: sc.slug || String(sc.id),
          description: sc.description || '',
          icon: sc.icon || 'Tag',
        });
      }

      // 2. Add local categories if not present in Supabase
      for (const lc of db.data.categories) {
        const found = supabaseCategories.find(
          sc => sc.id === lc.id || sc.slug === lc.slug || sc.name.toLowerCase() === lc.name.toLowerCase()
        );
        if (!found) {
          mergedMap.set(lc.id, lc);
        }
      }

      return res.json({ categories: Array.from(mergedMap.values()) });
    }
  } catch (err: any) {
    console.warn('[Categories Router] Fallback para categorias locais:', err.message);
  }

  res.json({ categories: db.data.categories });
});

// POST new category (Admin only)
categoriesRouter.post('/', requireAdmin, async (req, res) => {
  const { name, description, icon } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Nome da categoria é obrigatório.' });
  }

  const slug = name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');

  const newCat: Category = {
    id: `cat-${slug || crypto.randomUUID().slice(0, 8)}`,
    name: name.trim(),
    slug,
    description: description ? description.trim() : undefined,
    icon: icon || 'Layers',
  };

  // Save locally
  db.data.categories.push(newCat);
  db.save();

  // Sync to Supabase
  const supaResult = await insertCategoryToSupabase({
    id: newCat.id,
    name: newCat.name,
    slug: newCat.slug,
    description: newCat.description,
    icon: newCat.icon,
  });

  let message = `Categoria "${newCat.name}" criada com sucesso no Supabase e na loja.`;
  if (supaResult.error) {
    if (supaResult.code === '42501') {
      message = `Categoria criada no painel. Nota: Para gravar na tabela Supabase, execute o comando SQL de RLS no editor do Supabase.`;
    } else {
      message = `Categoria criada localmente. Aviso Supabase: ${supaResult.error}`;
    }
  }

  res.status(201).json({
    message,
    category: newCat,
    supabase: supaResult,
  });
});

// PUT update category (Admin only)
categoriesRouter.put('/:id', requireAdmin, async (req, res) => {
  const targetId = req.params.id;
  const target = db.data.categories.find(c => c.id === targetId || c.slug === targetId);

  const { name, description, icon } = req.body;
  const updateData: Partial<Category> = {};
  if (name) updateData.name = name.trim();
  if (description !== undefined) updateData.description = description.trim();
  if (icon) updateData.icon = icon;

  // Sync to Supabase
  await updateCategoryInSupabase(targetId, updateData);

  if (target) {
    if (name) {
      target.name = name.trim();
      // Update products using this category
      for (const p of db.data.products) {
        if (p.categoryId === target.id) {
          p.categoryName = target.name;
        }
      }
    }
    if (description !== undefined) target.description = description.trim();
    if (icon) target.icon = icon;
    db.save();
  }

  res.json({
    message: 'Categoria atualizada com sucesso no Supabase e na loja.',
    category: target || { id: targetId, ...updateData },
  });
});

// DELETE category (Admin only)
categoriesRouter.delete('/:id', requireAdmin, async (req, res) => {
  const targetId = String(req.params.id);

  // 1. Delete from Supabase
  const supaResult = await deleteCategoryFromSupabase(targetId);

  // 2. Delete from local database
  const index = db.data.categories.findIndex(c => c.id === targetId || c.slug === targetId);
  let removedName = supaResult.deletedCategory?.name || 'Categoria';

  if (index !== -1) {
    removedName = db.data.categories[index].name;
    db.data.categories.splice(index, 1);

    // Reassign products belonging to this category to the fallback category
    const fallbackCat = db.data.categories[0];
    for (const p of db.data.products) {
      if (p.categoryId === targetId || p.categoryName === removedName) {
        p.categoryId = fallbackCat ? fallbackCat.id : 'cat-geral';
        p.categoryName = fallbackCat ? fallbackCat.name : 'Geral';
      }
    }
    db.save();
  }

  if (supaResult.error) {
    console.warn('[Categories DELETE] Supabase erro/aviso:', supaResult.error);
    return res.status(200).json({
      success: true,
      message: `Categoria "${removedName}" removida do catálogo. (Aviso Supabase: ${supaResult.error})`,
      warning: supaResult.error,
      id: targetId,
    });
  }

  res.json({
    success: true,
    message: `Categoria "${removedName}" eliminada com sucesso no Supabase e na loja.`,
    id: targetId,
    deletedCategory: supaResult.deletedCategory,
  });
});

