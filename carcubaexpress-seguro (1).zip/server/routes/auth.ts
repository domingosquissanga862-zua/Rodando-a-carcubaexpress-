import { Router } from 'express';
import crypto from 'node:crypto';
import { db } from '../db.js';
import { hashPassword, verifyPassword, createSession, destroySession, requireAuth, type AuthenticatedRequest } from '../auth.js';
import type { User } from '../types.js';
import { supabaseServer, syncUserToSupabase, fetchUserFromSupabaseByEmail, fetchUserFromSupabaseById } from '../supabase.js';

export const authRouter = Router();

// Check if admin is set up
authRouter.get('/setup-status', (_req, res) => {
  const hasAdmin = db.data.users.some(u => u.role === 'admin');
  res.json({ hasAdmin });
});

// Check whether Google or Apple OAuth provider is enabled in Supabase
authRouter.get('/provider-status', async (req, res) => {
  const provider = String(req.query.provider || 'google').toLowerCase();
  try {
    const supaUrl = process.env.SUPABASE_URL || 'https://jglvxsvhumrbypmgooic.supabase.co';
    const cleanUrl = supaUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
    const checkUrl = `${cleanUrl}/auth/v1/authorize?provider=${provider}`;

    const resp = await fetch(checkUrl, {
      method: 'GET',
      redirect: 'manual',
    });

    if (resp.status === 400) {
      const data: any = await resp.json().catch(() => ({}));
      if (data?.msg?.includes('provider is not enabled') || data?.error_code === 'validation_failed') {
        return res.json({
          enabled: false,
          provider,
          message: `O provedor ${provider === 'google' ? 'Google' : 'Apple'} ainda não está ativado no painel do Supabase.`,
          hint: `No Supabase Dashboard, aceda a Authentication > Providers > ${provider === 'google' ? 'Google' : 'Apple'} e ative-o.`,
        });
      }
    }

    return res.json({
      enabled: true,
      provider,
    });
  } catch (err: any) {
    return res.json({
      enabled: false,
      provider,
      message: err.message,
    });
  }
});

// Initial admin setup if no admin or store owner claim
authRouter.post('/setup-admin', (req, res) => {
  const { name, email, phone, password, adminKey } = req.body;

  if (!email || !password || password.length < 6) {
    return res.status(400).json({ error: 'Email e palavra-passe (mínimo 6 caracteres) são obrigatórios.' });
  }

  const existingAdmin = db.data.users.find(u => u.role === 'admin');
  // If an admin already exists, permanently block setup-admin to prevent account takeover
  if (existingAdmin) {
    return res.status(403).json({ error: 'A conta de administrador já foi configurada. Esta rota está permanentemente bloqueada por motivos de segurança. Utilize o início de sessão normal.' });
  }

  const { salt, hash } = hashPassword(password);
  
  const newAdmin: User = {
    id: `user-admin-${Date.now()}`,
    name: name || 'Administrador CarcubaExpress',
    email: email.toLowerCase().trim(),
    phone: phone || '+244 951 556 411',
    passwordHash: hash,
    salt,
    role: 'admin',
    createdAt: new Date().toISOString(),
  };

  db.data.users.push(newAdmin);
  db.save();

  // Sync to Supabase
  syncUserToSupabase(newAdmin, password).catch(err => {
    console.warn('[Supabase Admin Sync]:', err);
  });

  const token = createSession(newAdmin);
  res.json({
    message: 'Conta administrativa criada com sucesso.',
    token,
    user: {
      id: newAdmin.id,
      name: newAdmin.name,
      email: newAdmin.email,
      phone: newAdmin.phone,
      role: newAdmin.role,
    },
  });
});

// Customer Sign Up
authRouter.post('/register', async (req, res) => {
  const { name, email, phone, password } = req.body;

  if (!name || !email || !phone || !password) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios (Nome, Email, Telefone, Palavra-passe).' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'A palavra-passe deve ter pelo menos 6 caracteres.' });
  }

  const normalizedEmail = email.toLowerCase().trim();

  // Check locally
  let existingUser = db.data.users.find(u => u.email.toLowerCase() === normalizedEmail);

  // Check in Supabase public.users
  if (!existingUser) {
    try {
      const supaUser = await fetchUserFromSupabaseByEmail(normalizedEmail);
      if (supaUser) {
        existingUser = {
          id: String(supaUser.id),
          name: supaUser.name,
          email: supaUser.email,
          phone: supaUser.phone || '',
          passwordHash: '',
          salt: '',
          role: supaUser.role as 'admin' | 'customer',
          createdAt: supaUser.created_at || new Date().toISOString(),
        };
        db.data.users.push(existingUser);
        db.save();
      }
    } catch {
      // Continue
    }
  }

  if (existingUser) {
    return res.status(409).json({ error: 'Já existe uma conta associada a este endereço de email. Se já tem conta, inicie sessão.' });
  }

  const { salt, hash } = hashPassword(password);
  let authId: string | undefined;

  // Sign up in Supabase Auth & public.users
  try {
    const syncRes = await syncUserToSupabase({
      id: '',
      name: name.trim(),
      email: normalizedEmail,
      phone: phone.trim(),
      role: 'customer',
    }, password);

    if (syncRes.supabaseAuthId) {
      authId = syncRes.supabaseAuthId;
    }
  } catch (err: any) {
    console.warn('[Register Supabase Sync]:', err.message);
  }

  const userId = authId || `user-${crypto.randomUUID()}`;
  const newUser: User = {
    id: userId,
    name: name.trim(),
    email: normalizedEmail,
    phone: phone.trim(),
    passwordHash: hash,
    salt,
    role: 'customer',
    createdAt: new Date().toISOString(),
  };

  db.data.users.push(newUser);
  db.save();

  const token = createSession(newUser);
  res.status(201).json({
    message: 'Conta criada com sucesso! Bem-vindo à CarcubaExpress.',
    token,
    user: {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      role: newUser.role,
    },
  });
});

// In-memory brute-force protection map (tracks failed attempts and lockout expiration)
interface LockoutRecord {
  attempts: number;
  lockedUntil: number;
}
const loginAttemptsMap = new Map<string, LockoutRecord>();

// Check lockout status
authRouter.get('/lockout-status', (req, res) => {
  const email = (req.query.email as string)?.toLowerCase().trim();
  const key = email || (req.ip || 'client');
  const record = loginAttemptsMap.get(key);

  if (record && Date.now() < record.lockedUntil) {
    const remainingSeconds = Math.ceil((record.lockedUntil - Date.now()) / 1000);
    return res.json({ isLocked: true, lockedUntil: record.lockedUntil, remainingSeconds });
  }

  // If lockout expired, reset
  if (record && Date.now() >= record.lockedUntil) {
    loginAttemptsMap.delete(key);
  }

  return res.json({ isLocked: false, remainingSeconds: 0 });
});

// Log In (for both Customers and Admin)
authRouter.post('/login', async (req, res) => {
  const { email, password, isAdminTab } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Por favor, introduza o seu email e palavra-passe.' });
  }

  const normalizedEmail = email.toLowerCase().trim();
  const key = normalizedEmail || (req.ip || 'client');
  const record = loginAttemptsMap.get(key);

  // Check if currently locked out
  if (record && Date.now() < record.lockedUntil) {
    const remainingSeconds = Math.ceil((record.lockedUntil - Date.now()) / 1000);
    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    const timeFormatted = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    return res.status(429).json({
      error: `Bloqueio de segurança ativo: 3 tentativas falhadas consecutivas. Aguarde ${timeFormatted} minutos para tentar novamente.`,
      isLocked: true,
      lockedUntil: record.lockedUntil,
      remainingSeconds,
    });
  }

  // Reset expired record if time passed
  if (record && Date.now() >= record.lockedUntil) {
    loginAttemptsMap.delete(key);
  }

  // If attempting to log in via Admin Tab with any other email, reject immediately
  if ((isAdminTab || req.body.isAdmin) && normalizedEmail !== 'domingosquissanga862@gmail.com') {
    return res.status(403).json({
      error: 'Acesso restrito. Apenas o email domingosquissanga862@gmail.com tem autorização para aceder ao Painel de Administração.',
    });
  }

  let authenticatedUser: User | null = null;

  // 1. ATTEMPT SUPABASE AUTHENTICATION FIRST
  try {
    const { data: supaAuthData, error: supaAuthErr } = await supabaseServer.auth.signInWithPassword({
      email: normalizedEmail,
      password,
    });

    if (!supaAuthErr && supaAuthData?.user) {
      const supaUser = supaAuthData.user;
      const supaProfile = await fetchUserFromSupabaseByEmail(normalizedEmail);
      const isStoreAdminEmail = normalizedEmail === 'domingosquissanga862@gmail.com';
      const role = (isStoreAdminEmail ? 'admin' : 'customer') as 'admin' | 'customer';

      authenticatedUser = {
        id: supaUser.id,
        name: isStoreAdminEmail ? 'Domingos Quissanga' : (supaProfile?.name || supaUser.user_metadata?.name || normalizedEmail.split('@')[0]),
        email: normalizedEmail,
        phone: supaProfile?.phone || supaUser.user_metadata?.phone || '',
        passwordHash: '',
        salt: '',
        role,
        createdAt: supaProfile?.created_at || supaUser.created_at || new Date().toISOString(),
      };

      // Keep local db.data.users synchronized
      const idx = db.data.users.findIndex(u => u.email.toLowerCase() === normalizedEmail);
      if (idx >= 0) {
        db.data.users[idx] = { ...db.data.users[idx], ...authenticatedUser };
      } else {
        db.data.users.push(authenticatedUser);
      }
      db.save();
    } else if (supaAuthErr) {
      if (supaAuthErr.message.toLowerCase().includes('email not confirmed')) {
        return res.status(403).json({
          error: 'A sua conta requer confirmação de email antes de iniciar sessão. Por favor, verifique a sua caixa de entrada.',
        });
      }
    }
  } catch (err: any) {
    console.warn('[Supabase Login Check]:', err.message);
  }

  // 2. FALLBACK TO LOCAL DATABASE (Admin master credentials or accounts created locally)
  if (!authenticatedUser) {
    let localUser = db.data.users.find(u => u.email.toLowerCase() === normalizedEmail);

    // If Domingos Quissanga is accessed, ensure admin account exists
    const isKnownAdminEmail = normalizedEmail === 'domingosquissanga862@gmail.com';

    if (!localUser && isKnownAdminEmail) {
      const { salt, hash } = hashPassword('carcuba@2026');
      localUser = {
        id: 'user-admin-domingos',
        name: 'Domingos Quissanga',
        email: 'domingosquissanga862@gmail.com',
        phone: '+244 951 556 411',
        passwordHash: hash,
        salt,
        role: 'admin',
        createdAt: new Date().toISOString(),
      };
      db.data.users.unshift(localUser);
      db.save();
    }

    if (localUser) {
      const isPasswordValid = Boolean(
        localUser.passwordHash && localUser.salt && verifyPassword(password, localUser.salt, localUser.passwordHash)
      );

      if (isPasswordValid) {
        authenticatedUser = localUser;
        // Also sync user to Supabase in the background
        syncUserToSupabase(localUser, password).catch(() => {});
      }
    }
  }

  // 3. FAILED LOGIN HANDLING
  if (!authenticatedUser) {
    const cur = loginAttemptsMap.get(key) || { attempts: 0, lockedUntil: 0 };
    cur.attempts += 1;

    if (cur.attempts >= 3) {
      cur.lockedUntil = Date.now() + 3 * 60 * 1000; // 3 minutes lockout
      loginAttemptsMap.set(key, cur);
      return res.status(429).json({
        error: 'Bloqueio de segurança ativado: 3 tentativas consecutivas com dados incorretos. O acesso está bloqueado durante 3 minutos por motivos de segurança.',
        isLocked: true,
        lockedUntil: cur.lockedUntil,
        remainingSeconds: 180,
      });
    }

    loginAttemptsMap.set(key, cur);
    const attemptsLeft = 3 - cur.attempts;
    return res.status(401).json({
      error: `Email ou palavra-passe incorretos. Tentativa ${cur.attempts} de 3 (${attemptsLeft} restante${attemptsLeft > 1 ? 's' : ''} antes do bloqueio de 3 minutos).`,
      attemptsLeft,
      failedAttempts: cur.attempts,
    });
  }

  // Clear any failed attempts upon successful login
  loginAttemptsMap.delete(key);

  const token = createSession(authenticatedUser);
  res.json({
    message: 'Sessão iniciada com sucesso.',
    token,
    user: {
      id: authenticatedUser.id,
      name: authenticatedUser.name,
      email: authenticatedUser.email,
      phone: authenticatedUser.phone,
      role: authenticatedUser.role,
    },
  });
});

// Get Current User Profile
authRouter.get('/me', (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Nenhuma sessão ativa.' });
  }

  res.json({
    user: {
      id: req.user.id,
      name: req.user.name,
      email: req.user.email,
      phone: req.user.phone,
      role: req.user.role,
    },
  });
});

// Update Profile
authRouter.put('/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { name, phone, currentPassword, newPassword } = req.body;

  const target = db.data.users.find(u => u.id === user.id);
  if (!target) {
    return res.status(404).json({ error: 'Utilizador não encontrado.' });
  }

  if (name) target.name = name.trim();
  if (phone) target.phone = phone.trim();

  if (newPassword) {
    if (!currentPassword || !verifyPassword(currentPassword, target.salt, target.passwordHash)) {
      return res.status(400).json({ error: 'Palavra-passe atual incorreta.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'A nova palavra-passe deve ter pelo menos 6 caracteres.' });
    }
    const { salt, hash } = hashPassword(newPassword);
    target.salt = salt;
    target.passwordHash = hash;
  }

  db.save();

  // Sync to Supabase
  syncUserToSupabase(target, newPassword || undefined).catch(err => {
    console.warn('[Supabase Profile Sync]:', err);
  });

  res.json({
    message: 'Perfil atualizado com sucesso.',
    user: {
      id: target.id,
      name: target.name,
      email: target.email,
      phone: target.phone,
      role: target.role,
    },
  });
});

// Log out
authRouter.post('/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : (req.body.token as string);
  if (token) {
    destroySession(token);
  }
  res.json({ message: 'Sessão terminada com sucesso.' });
});
