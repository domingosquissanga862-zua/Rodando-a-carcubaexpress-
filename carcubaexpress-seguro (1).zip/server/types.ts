export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  salt: string;
  role: 'admin' | 'customer';
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number; // in Kz
  costPrice: number; // in Kz (for financial profit calculation)
  promoPrice?: number; // optional discounted price
  categoryId: string;
  categoryName: string;
  images: string[];
  stock: number;
  sizes?: string[];
  colors?: string[];
  isActive: boolean;
  isFeatured: boolean;
  freeShipping: boolean; // "entrega grátis"
  createdAt: string;
  updatedAt: string;
}

export type OrderStatus =
  | 'Pendente'
  | 'A aguardar pagamento'
  | 'Pagamento confirmado'
  | 'Em preparação'
  | 'Em transporte'
  | 'Entregue'
  | 'Cancelado';

export type PaymentStatus =
  | 'Pendente'
  | 'Confirmado'
  | 'No acto da entrega'
  | 'Cancelado'
  | 'Reembolsado';

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  costPrice: number;
  quantity: number;
  image: string;
  size?: string;
  color?: string;
}

export interface StatusHistoryEntry {
  status: OrderStatus;
  timestamp: string;
  changedBy: string;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. CAR-2026-001
  customerId?: string;
  customerName: string;
  customerEmail?: string;
  customerPhone: string;
  deliveryAddress: string;
  deliveryMunicipality: string; // Luanda, Talatona, Viana, etc.
  deliveryReference?: string;
  items: OrderItem[];
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'Dinheiro (no acto da entrega)' | 'Multicaixa Express' | 'Pagamento no acto da entrega' | 'Transferência Multicaixa';
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  statusHistory: StatusHistoryEntry[];
  deliveryAgent?: string;
  courierName?: string;
  courierPhone?: string;
  estimatedDeliveryDate?: string;
  notes?: string;
  whatsappSent?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  title: string;
  category: 'Transporte & Logística' | 'Embalagens' | 'Marketing & Publicidade' | 'Comunicação & Net' | 'Salários & Operacional' | 'Outros';
  amount: number; // in Kz
  date: string;
  note?: string;
  createdById: string;
  createdByName: string;
  createdAt: string;
}

export interface StoreSettings {
  storeName: string;
  storeDescription?: string;
  whatsappNumber: string; // e.g. 244951556411
  supportPhone: string;
  email: string;
  city: string;
  country: string;
  address?: string;
  currency: string;
  currencySymbol: string;
  defaultShippingFee: number;
  freeShippingMinAmount: number;
  deliveryMunicipalities: {
    name: string;
    fee: number;
    estimatedHours: string;
  }[];
  deliveryPolicyTitle?: string;
  deliveryPolicyText?: string;
  paymentPolicyTitle?: string;
  paymentPolicyText?: string;
  termsPolicyTitle?: string;
  termsPolicyText?: string;
  supportPolicyTitle?: string;
  supportPolicyText?: string;
  footerDepartments?: string[];
}
