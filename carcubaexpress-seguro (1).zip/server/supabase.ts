import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Order, Product, StoreSettings } from './types.js';

const rawUrl =
  process.env.SUPABASE_URL || 'https://jglvxsvhumrbypmgooic.supabase.co';
export const SUPABASE_URL = rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
export const SUPABASE_ANON_KEY =
  process.env.SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpnbHZ4c3ZodW1yYnlwbWdvb2ljIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI0MTQ0MjYsImV4cCI6MjEwNzk5MDQyNn0.OsRyWri7JPz9d01IVnWQ-wq07JtgDAF4k0rGHq-o-wU';

export const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

// Server client: Uses service_role if available, otherwise anon_key
export const supabaseServer: SupabaseClient = createClient(
  SUPABASE_URL,
  SUPABASE_SERVICE_ROLE_KEY || SUPABASE_ANON_KEY,
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  }
);

export interface SupabaseStatus {
  connected: boolean;
  projectUrl: string;
  productsCount: number;
  ordersCount: number;
  error?: string;
  checkedAt: string;
}

/**
 * Dynamically resolves the table name: checks if 'produtos' or 'products' exists in Supabase
 */
let cachedTableName: string | null = null;
export async function getProductsTableName(): Promise<string> {
  if (cachedTableName) return cachedTableName;

  try {
    // Check if 'produtos' table exists
    const { data, error } = await supabaseServer.from('produtos').select('id').limit(1);
    if (!error && Array.isArray(data)) {
      cachedTableName = 'produtos';
      return 'produtos';
    }
  } catch {
    // Ignore and fallback
  }

  cachedTableName = 'products';
  return 'products';
}

/**
 * Tests connection with the configured Supabase project
 */
export async function testSupabaseConnection(): Promise<SupabaseStatus> {
  const checkedAt = new Date().toISOString();
  try {
    const tableName = await getProductsTableName();
    const [productsRes, ordersRes] = await Promise.all([
      supabaseServer.from(tableName).select('*', { count: 'exact' }),
      supabaseServer.from('orders').select('*', { count: 'exact', head: true }),
    ]);

    if (productsRes.error && ordersRes.error) {
      return {
        connected: false,
        projectUrl: SUPABASE_URL,
        productsCount: 0,
        ordersCount: 0,
        error: productsRes.error.message || ordersRes.error?.message,
        checkedAt,
      };
    }

    return {
      connected: true,
      projectUrl: SUPABASE_URL,
      productsCount: productsRes.count ?? (productsRes.data?.length || 0),
      ordersCount: ordersRes.count ?? 0,
      checkedAt,
    };
  } catch (err: any) {
    return {
      connected: false,
      projectUrl: SUPABASE_URL,
      productsCount: 0,
      ordersCount: 0,
      error: err.message || 'Falha de comunicação com o Supabase',
      checkedAt,
    };
  }
}

/**
 * Fetches all products directly from Supabase and transforms them to standard Product type
 */
export async function fetchProductsFromSupabase(): Promise<Product[]> {
  const tableName = await getProductsTableName();
  const { data, error } = await supabaseServer
    .from(tableName)
    .select('*')
    .order('id', { ascending: true });

  if (error) {
    throw error;
  }

  if (!data || !Array.isArray(data)) {
    return [];
  }

  return data.map((row: any) => {
    // Default image resolver
    let images: string[] = [];
    if (Array.isArray(row.images) && row.images.length > 0) {
      images = row.images;
    } else if (row.image_url) {
      images = [row.image_url];
    } else {
      // Map existing products to their visual assets
      const lowerName = (row.name || '').toLowerCase();
      if (lowerName.includes('asad') || lowerName.includes('lattafa')) {
        images = ['/assets/aistudio/IMG-20261018-WA0022_10800326.jpg'];
      } else if (lowerName.includes('quadrado') || lowerName.includes('tx')) {
        images = ['/assets/aistudio/mic-quadrado_3e698234.jpg'];
      } else {
        images = ['/assets/aistudio/mic-circular_f8930c2d.jpg'];
      }
    }

    const price = Number(row.price_kz ?? row.price ?? 0);
    const costPrice = Number(row.cost_price ?? Math.round(price * 0.6));
    const promoPrice = row.promo_price ? Number(row.promo_price) : undefined;
    const stock = Number(row.stock ?? 10);
    const isActive = Boolean(row.is_active ?? row.active ?? true);
    const isFeatured = Boolean(row.is_featured ?? false);
    const freeShipping = Boolean(row.free_shipping ?? false);

    let categoryId = row.category_id || 'cat-eletronicos';
    let categoryName = row.category_name;
    const lowerName = (row.name || '').toLowerCase();

    if (
      categoryId === 'perfumaria' ||
      categoryId === 'cat-perfumes' ||
      lowerName.includes('asad') ||
      lowerName.includes('lattafa') ||
      lowerName.includes('perfum') ||
      lowerName.includes('fragrân')
    ) {
      categoryId = 'perfumaria';
      categoryName = 'Perfumaria & Fragrâncias';
    } else if (
      categoryId === 'audio' ||
      (!categoryName && (lowerName.includes('microfone') || lowerName.includes('lapela') || lowerName.includes('sound')))
    ) {
      categoryId = 'audio';
      categoryName = categoryName || 'Áudio & Gravação';
    } else if (!categoryName) {
      categoryName = 'Eletrónicos & Som';
    }

    return {
      id: String(row.id),
      name: row.name || 'Produto sem nome',
      slug: row.slug || `prod-${row.id}`,
      description: row.description || '',
      price,
      costPrice,
      promoPrice,
      categoryId,
      categoryName,
      images,
      stock,
      isActive,
      isFeatured,
      freeShipping,
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
    };
  });
}

/**
 * Inserts a product into Supabase table with exact schema columns
 */
export async function insertProductToSupabase(productData: Partial<Product>): Promise<{
  success: boolean;
  insertedProduct?: any;
  error?: string;
  code?: string;
  hint?: string;
}> {
  try {
    const tableName = await getProductsTableName();

    const price = Number(productData.price || 0);
    const costPrice = productData.costPrice !== undefined ? Number(productData.costPrice) : Math.round(price * 0.6);
    const promoPrice = productData.promoPrice ? Number(productData.promoPrice) : null;
    const stock = productData.stock !== undefined ? Math.max(0, parseInt(String(productData.stock), 10)) : 10;
    const imageUrl = Array.isArray(productData.images) && productData.images.length > 0 ? productData.images[0] : null;

    const slug = (productData.name || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');

    // Payload strictly respecting Supabase columns
    const payload: Record<string, any> = {
      name: (productData.name || '').trim(),
      slug: `${slug}-${Date.now().toString().slice(-4)}`,
      description: productData.description ? productData.description.trim() : null,
      price_kz: price,
      cost_price: costPrice,
      promo_price: promoPrice,
      stock: stock,
      category_id: productData.categoryId || 'cat-eletronicos',
      category_name:
        productData.categoryName ||
        (productData.categoryId === 'perfumaria'
          ? 'Perfumaria & Fragrâncias'
          : productData.categoryId === 'audio'
          ? 'Áudio & Gravação'
          : 'Eletrónicos & Som'),
      image_url: imageUrl,
      images: Array.isArray(productData.images) && productData.images.length > 0 ? productData.images : (imageUrl ? [imageUrl] : []),
      active: productData.isActive !== undefined ? Boolean(productData.isActive) : true,
      is_active: productData.isActive !== undefined ? Boolean(productData.isActive) : true,
      is_featured: productData.isFeatured !== undefined ? Boolean(productData.isFeatured) : false,
      free_shipping: productData.freeShipping !== undefined ? Boolean(productData.freeShipping) : false,
    };

    const { data, error } = await supabaseServer
      .from(tableName)
      .insert(payload)
      .select('*')
      .single();

    if (error) {
      console.error('[Supabase Insert Error]:', error);
      return {
        success: false,
        error: error.message,
        code: error.code,
        hint: error.hint,
      };
    }

    return {
      success: true,
      insertedProduct: data,
    };
  } catch (err: any) {
    console.error('[Supabase Unexpected Insert Error]:', err);
    return {
      success: false,
      error: err.message || 'Erro inesperado ao contactar o Supabase',
    };
  }
}

/**
 * Updates a product in Supabase by ID
 */
export async function updateProductInSupabase(id: string | number, productData: Partial<Product>): Promise<{
  success: boolean;
  error?: string;
  code?: string;
}> {
  try {
    const tableName = await getProductsTableName();

    const numericId = parseInt(String(id).replace(/\D/g, ''), 10);
    const filterQuery = isNaN(numericId) ? { slug: String(id) } : { id: numericId };

    const updatePayload: Record<string, any> = {};
    if (productData.name) updatePayload.name = productData.name.trim();
    if (productData.description !== undefined) updatePayload.description = productData.description.trim();
    if (productData.price !== undefined) updatePayload.price_kz = Number(productData.price);
    if (productData.costPrice !== undefined) updatePayload.cost_price = Number(productData.costPrice);
    if (productData.promoPrice !== undefined) updatePayload.promo_price = productData.promoPrice ? Number(productData.promoPrice) : null;
    if (productData.stock !== undefined) updatePayload.stock = Math.max(0, parseInt(String(productData.stock), 10));
    if (productData.categoryId) updatePayload.category_id = productData.categoryId;
    if (productData.categoryName) updatePayload.category_name = productData.categoryName;
    if (Array.isArray(productData.images) && productData.images.length > 0) {
      updatePayload.images = productData.images;
      updatePayload.image_url = productData.images[0];
    }
    if (productData.isActive !== undefined) {
      updatePayload.active = Boolean(productData.isActive);
      updatePayload.is_active = Boolean(productData.isActive);
    }
    if (productData.isFeatured !== undefined) updatePayload.is_featured = Boolean(productData.isFeatured);
    if (productData.freeShipping !== undefined) updatePayload.free_shipping = Boolean(productData.freeShipping);

    let query = supabaseServer.from(tableName).update(updatePayload);
    if (!isNaN(numericId)) {
      query = query.eq('id', numericId);
    } else {
      query = query.eq('slug', String(id));
    }

    const { error } = await query;
    if (error) {
      return { success: false, error: error.message, code: error.code };
    }

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Deletes a product in Supabase by ID or slug
 */
export async function deleteProductFromSupabase(id: string | number): Promise<{
  success: boolean;
  error?: string;
  code?: string;
  deletedProduct?: any;
}> {
  try {
    const tableName = await getProductsTableName();
    const rawId = String(id).trim();
    const isPureNumeric = /^\d+$/.test(rawId);

    // 1. Try to find the matching row in Supabase first
    let rowToDelete: any = null;
    if (isPureNumeric) {
      const { data } = await supabaseServer.from(tableName).select('*').eq('id', Number(rawId)).maybeSingle();
      if (data) rowToDelete = data;
    }

    if (!rowToDelete) {
      const { data: bySlug } = await supabaseServer.from(tableName).select('*').eq('slug', rawId).maybeSingle();
      if (bySlug) {
        rowToDelete = bySlug;
      } else {
        const { data: allRows } = await supabaseServer.from(tableName).select('*');
        if (allRows && allRows.length > 0) {
          const match = allRows.find((r: any) =>
            String(r.id) === rawId ||
            r.slug === rawId ||
            (rawId.includes('asad') && (r.slug?.includes('asad') || r.name?.toLowerCase().includes('asad'))) ||
            (rawId.includes('circular') && (r.slug?.includes('circular') || r.name?.toLowerCase().includes('circular'))) ||
            ((rawId.includes('quadrado') || rawId.includes('tx')) && (r.slug?.includes('quadrado') || r.name?.toLowerCase().includes('quadrado')))
          );
          if (match) rowToDelete = match;
        }
      }
    }

    // 2. Perform delete
    let query = supabaseServer.from(tableName).delete().select('*');
    if (rowToDelete && rowToDelete.id) {
      query = query.eq('id', rowToDelete.id);
    } else if (isPureNumeric) {
      query = query.eq('id', Number(rawId));
    } else {
      query = query.eq('slug', rawId);
    }

    const { data, error } = await query;
    if (error) {
      return { success: false, error: error.message, code: error.code };
    }
    return {
      success: true,
      deletedProduct: (data && data[0]) || rowToDelete,
    };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Removes all products from Supabase products table
 */
export async function clearAllProductsFromSupabase(): Promise<{ success: boolean; count?: number; error?: string }> {
  try {
    const tableName = await getProductsTableName();
    const { data, error } = await supabaseServer
      .from(tableName)
      .delete()
      .neq('id', -999999)
      .select('id');

    if (error) {
      console.warn('[Supabase Clear Products] Aviso:', error.message);
      return { success: false, error: error.message };
    }
    return { success: true, count: data?.length || 0 };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Fetches all categories directly from Supabase
 */
export async function fetchCategoriesFromSupabase(): Promise<any[]> {
  try {
    const { data, error } = await supabaseServer
      .from('categories')
      .select('*')
      .order('name', { ascending: true });

    if (error) {
      console.warn('[Supabase Categories] Erro ao carregar categorias:', error.message);
      return [];
    }
    return data || [];
  } catch (err: any) {
    console.warn('[Supabase Categories] Erro inesperado ao carregar:', err.message);
    return [];
  }
}

/**
 * Inserts a category into Supabase
 */
export async function insertCategoryToSupabase(categoryData: {
  id?: string;
  name: string;
  slug?: string;
  description?: string;
  icon?: string;
}): Promise<{
  success: boolean;
  insertedCategory?: any;
  error?: string;
  code?: string;
}> {
  try {
    const slug = (categoryData.slug || categoryData.name || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');

    const id = categoryData.id || slug;
    const payload = {
      id,
      name: categoryData.name.trim(),
      slug,
      description: categoryData.description ? categoryData.description.trim() : null,
      icon: categoryData.icon || null,
    };

    const { data, error } = await supabaseServer
      .from('categories')
      .insert(payload)
      .select('*')
      .single();

    if (error) {
      console.error('[Supabase Category Insert Error]:', error);
      return { success: false, error: error.message, code: error.code };
    }
    return { success: true, insertedCategory: data };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Updates a category in Supabase
 */
export async function updateCategoryInSupabase(
  id: string,
  categoryData: { name?: string; slug?: string; description?: string; icon?: string }
): Promise<{
  success: boolean;
  error?: string;
  code?: string;
}> {
  try {
    const payload: Record<string, any> = {};
    if (categoryData.name) payload.name = categoryData.name.trim();
    if (categoryData.slug) payload.slug = categoryData.slug;
    if (categoryData.description !== undefined) payload.description = categoryData.description.trim();
    if (categoryData.icon !== undefined) payload.icon = categoryData.icon;

    const { error } = await supabaseServer
      .from('categories')
      .update(payload)
      .or(`id.eq.${id},slug.eq.${id}`);

    if (error) {
      return { success: false, error: error.message, code: error.code };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Deletes a category from Supabase by ID or slug
 */
export async function deleteCategoryFromSupabase(id: string): Promise<{
  success: boolean;
  error?: string;
  code?: string;
  deletedCategory?: any;
}> {
  try {
    const rawId = String(id).trim();

    // Check if category exists in Supabase first
    const { data: existing } = await supabaseServer
      .from('categories')
      .select('*')
      .or(`id.eq.${rawId},slug.eq.${rawId}`)
      .maybeSingle();

    let query = supabaseServer.from('categories').delete().select('*');
    if (existing && existing.id) {
      query = query.eq('id', existing.id);
    } else {
      query = query.or(`id.eq.${rawId},slug.eq.${rawId}`);
    }

    const { data, error } = await query;
    if (error) {
      console.error('[Supabase Category Delete Error]:', error);
      return { success: false, error: error.message, code: error.code };
    }

    return {
      success: true,
      deletedCategory: (data && data[0]) || existing,
    };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Status mapping for Supabase orders table check constraint (orders_status_check).
 * Allowed values in Postgres check constraint: 'pendente', 'confirmada', 'cancelada', 'entregue'
 */
export function mapStatusToSupabase(status?: string): 'pendente' | 'confirmada' | 'cancelada' | 'entregue' {
  const s = (status || '').toLowerCase().trim();
  if (s.includes('entregue')) return 'entregue';
  if (s.includes('cancel')) return 'cancelada';
  if (s.includes('confirm') || s.includes('prepara') || s.includes('caminho') || s.includes('transporte')) return 'confirmada';
  return 'pendente';
}

export function mapStatusFromSupabase(status?: string): 'Pendente' | 'Confirmado' | 'Entregue' | 'Cancelado' {
  const s = (status || '').toLowerCase().trim();
  if (s === 'entregue') return 'Entregue';
  if (s === 'cancelada' || s === 'cancelado') return 'Cancelado';
  if (s === 'confirmada' || s === 'confirmado') return 'Confirmado';
  return 'Pendente';
}

/**
 * Attempts to push a newly created order to Supabase orders & order_items tables.
 * Returns result without interrupting local order completion.
 */
export async function syncOrderToSupabase(order: Order): Promise<{ success: boolean; supabaseOrderId?: number | string; error?: string }> {
  try {
    const formattedAddress = [
      order.deliveryMunicipality,
      order.deliveryAddress,
      order.deliveryReference ? `Ref: ${order.deliveryReference}` : null,
    ]
      .filter(Boolean)
      .join(', ');

    const notesDetail = [
      order.notes ? `[${order.orderNumber}] ${order.notes}` : `Pedido ${order.orderNumber}`,
      order.customerId ? `CID: ${order.customerId}` : null,
    ].filter(Boolean).join(' | ');

    const orderPayload = {
      customer_name: (order.customerName || 'Cliente').trim(),
      customer_email: order.customerEmail ? order.customerEmail.trim() : null,
      phone: (order.customerPhone || '+244 951 556 411').trim(),
      customer_phone: (order.customerPhone || '+244 951 556 411').trim(),
      address: (formattedAddress || order.deliveryAddress || 'Luanda, Angola').trim(),
      delivery_address: (order.deliveryAddress || formattedAddress || 'Luanda, Angola').trim(),
      delivery_municipality: (order.deliveryMunicipality || 'Luanda').trim(),
      delivery_reference: order.deliveryReference ? order.deliveryReference.trim() : null,
      subtotal: Number(order.subtotal || order.total || 0),
      shipping_fee: Number(order.shippingFee || 0),
      total: Number(order.total || 0),
      total_kz: Number(order.total || 0),
      payment_method: order.paymentMethod || 'Pagamento no acto da entrega',
      payment_status: order.paymentStatus || 'No acto da entrega',
      status: mapStatusToSupabase(order.status),
      notes: notesDetail,
      order_number: order.orderNumber,
      whatsapp_sent: Boolean(order.whatsappSent),
    };

    let insertedOrder: any = null;
    let orderErr: any = null;
    const currentPayload: Record<string, any> = { ...orderPayload };

    for (let attempt = 0; attempt < 5; attempt++) {
      const res = await supabaseServer
        .from('orders')
        .insert(currentPayload)
        .select('id')
        .single();

      if (!res.error && res.data) {
        insertedOrder = res.data;
        orderErr = null;
        break;
      }

      orderErr = res.error;
      const errMsg = res.error?.message || '';

      const match1 = errMsg.match(/Could not find the '([^']+)' column of 'orders'/i);
      if (match1 && match1[1]) {
        delete currentPayload[match1[1]];
        continue;
      }

      const match2 = errMsg.match(/column ["']?([^"'\s]+)["']? of relation ["']?orders["']? does not exist/i);
      if (match2 && match2[1]) {
        delete currentPayload[match2[1]];
        continue;
      }

      if (attempt === 0) {
        delete currentPayload.customer_id;
        delete currentPayload.customer_email;
        delete currentPayload.delivery_date;
        delete currentPayload.estimated_delivery_date;
        delete currentPayload.delivery_reference;
        delete currentPayload.whatsapp_sent;
        continue;
      }

      break;
    }

    if (orderErr && !insertedOrder) {
      console.warn('[Supabase Sync] Aviso ao sincronizar pedido:', orderErr.message);
      return {
        success: false,
        error: orderErr.message,
      };
    }

    const supabaseOrderId = insertedOrder?.id;

    // Insert order items if order was created and has items
    if (supabaseOrderId && Array.isArray(order.items) && order.items.length > 0) {
      const itemsPayload = order.items.map(item => ({
        order_id: supabaseOrderId,
        product_name: item.productName,
        quantity: item.quantity,
        unit_price_kz: item.price,
      }));

      const { error: itemsErr } = await supabaseServer
        .from('order_items')
        .insert(itemsPayload);

      if (itemsErr) {
        console.warn('[Supabase Sync] Aviso ao sincronizar itens do pedido:', itemsErr.message);
      }
    }

    return {
      success: true,
      supabaseOrderId,
    };
  } catch (err: any) {
    console.warn('[Supabase Sync] Erro inesperado ao sincronizar com Supabase:', err.message);
    return {
      success: false,
      error: err.message,
    };
  }
}

/**
 * Fetches all orders directly from Supabase, including joined order_items
 */
export async function fetchOrdersFromSupabase(): Promise<Order[]> {
  try {
    const { data, error } = await supabaseServer
      .from('orders')
      .select('*, order_items(*)')
      .order('id', { ascending: false });

    if (error) {
      console.warn('[Supabase Orders] Erro ao carregar pedidos:', error.message);
      return [];
    }

    if (!data || !Array.isArray(data)) return [];

    return data.map((row: any) => {
      const orderNumber = row.order_number || `CAR-2026-${String(row.id).padStart(3, '0')}`;
      const items = Array.isArray(row.order_items) && row.order_items.length > 0
        ? row.order_items.map((it: any) => ({
            productId: String(it.product_id || it.id || 'prod'),
            productName: it.product_name || 'Produto CarcubaExpress',
            price: Number(it.unit_price_kz ?? it.price ?? 0),
            costPrice: Math.round(Number(it.unit_price_kz ?? it.price ?? 0) * 0.6),
            quantity: Number(it.quantity || 1),
            image: '/assets/aistudio/mic-circular_f8930c2d.jpg',
          }))
        : [
            {
              productId: 'prod-order-item',
              productName: row.notes ? row.notes.replace(/^\[.*?\]\s*/, '') : 'Item de Encomenda',
              price: Number(row.total_kz || row.total || 0),
              costPrice: Math.round(Number(row.total_kz || row.total || 0) * 0.6),
              quantity: 1,
              image: '/assets/aistudio/mic-circular_f8930c2d.jpg',
            },
          ];

      const total = Number(row.total ?? row.total_kz ?? 0);
      const shippingFee = Number(row.shipping_fee ?? 0);
      const subtotal = Number(row.subtotal ?? (total - shippingFee));
      const appStatus = mapStatusFromSupabase(row.status);

      return {
        id: `ord-supa-${row.id}`,
        orderNumber,
        customerId: row.customer_id ? String(row.customer_id) : undefined,
        customerName: row.customer_name || 'Cliente CarcubaExpress',
        customerEmail: row.customer_email || undefined,
        customerPhone: row.customer_phone || row.phone || '',
        deliveryAddress: row.delivery_address || row.address || 'Luanda, Angola',
        deliveryMunicipality: row.delivery_municipality || 'Luanda',
        deliveryReference: row.delivery_reference || undefined,
        items,
        subtotal,
        shippingFee,
        total,
        paymentMethod: row.payment_method || 'Pagamento no acto da entrega',
        paymentStatus: (row.payment_status || 'No acto da entrega') as any,
        status: appStatus as any,
        statusHistory: [
          {
            status: appStatus as any,
            timestamp: row.created_at || new Date().toISOString(),
            changedBy: 'Supabase Database',
            note: 'Registo sincronizado com a base de dados Supabase.',
          },
        ],
        notes: row.notes || undefined,
        whatsappSent: Boolean(row.whatsapp_sent),
        createdAt: row.created_at || new Date().toISOString(),
        updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
      };
    });
  } catch (err: any) {
    console.warn('[Supabase Orders] Erro inesperado ao carregar pedidos:', err.message);
    return [];
  }
}

/**
 * Updates an order status in Supabase
 */
export async function updateOrderStatusInSupabase(
  orderIdOrNumber: string | number,
  status: string,
  extra?: { paymentStatus?: string; notes?: string }
): Promise<{ success: boolean; error?: string }> {
  try {
    const supaStatus = mapStatusToSupabase(status);
    const cleanId = String(orderIdOrNumber).replace(/^ord-supa-/, '');
    const isNum = /^\d+$/.test(cleanId);

    const updatePayload: Record<string, any> = {
      status: supaStatus,
    };
    if (extra?.paymentStatus) {
      updatePayload.payment_status = extra.paymentStatus;
    }
    if (extra?.notes) {
      updatePayload.notes = extra.notes;
    }

    let query = supabaseServer.from('orders').update(updatePayload);

    if (isNum) {
      query = query.or(`id.eq.${cleanId},order_number.eq.${orderIdOrNumber}`);
    } else {
      query = query.eq('order_number', String(orderIdOrNumber));
    }

    const { error } = await query;
    if (error) {
      console.warn('[Supabase Status Update] Aviso:', error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Deletes an order from Supabase safely:
 * 1. Finds the order by numeric ID or order_number
 * 2. Deletes associated order_items first to preserve foreign key constraints
 * 3. Deletes the order record from orders table
 * 4. Ensures customers, products, and expenses are completely untouched
 */
export async function deleteOrderFromSupabase(
  orderIdOrNumber: string | number
): Promise<{ success: boolean; error?: string; deletedOrderNumber?: string }> {
  try {
    const rawInput = String(orderIdOrNumber).trim();
    const cleanId = rawInput.replace(/^ord-supa-/, '').trim();
    const isNum = /^\d+$/.test(cleanId);

    // 1. Locate the exact order
    let foundId: number | null = isNum ? parseInt(cleanId, 10) : null;
    let foundOrderNumber: string = rawInput;

    try {
      let findQuery = supabaseServer.from('orders').select('id, order_number');
      if (isNum) {
        findQuery = findQuery.or(`id.eq.${cleanId},order_number.eq.${rawInput}`);
      } else {
        findQuery = findQuery.eq('order_number', rawInput);
      }
      const { data: found } = await findQuery.maybeSingle();
      if (found) {
        foundId = found.id;
        foundOrderNumber = found.order_number || rawInput;
      }
    } catch (lookupErr: any) {
      console.warn('[Supabase Delete Order Lookup Warning]:', lookupErr.message);
    }

    // 2. Safe deletion of related items in order_items first
    if (foundId !== null) {
      const { error: itemsErr } = await supabaseServer
        .from('order_items')
        .delete()
        .eq('order_id', foundId);
      if (itemsErr) {
        console.warn('[Supabase Delete Order Items Warning]:', itemsErr.message);
      }
    }

    // 3. Delete from orders table
    let deleteQuery = supabaseServer.from('orders').delete();
    if (foundId !== null) {
      deleteQuery = deleteQuery.or(`id.eq.${foundId},order_number.eq.${foundOrderNumber}`);
    } else {
      deleteQuery = deleteQuery.eq('order_number', rawInput);
    }

    const { error } = await deleteQuery;
    if (error) {
      console.error('[Supabase Delete Order Error]:', error);
      return { success: false, error: error.message };
    }

    console.log(`[Supabase Delete Order] Pedido ${foundOrderNumber} (ID #${foundId}) eliminado com sucesso.`);
    return { success: true, deletedOrderNumber: foundOrderNumber };
  } catch (err: any) {
    console.error('[Supabase Delete Order Exception]:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Synchronizes user accounts with Supabase Auth and public.users
 */
export async function syncUserToSupabase(
  user: { id: string; name: string; email: string; phone?: string; role: 'admin' | 'customer'; createdAt?: string },
  plainPassword?: string
): Promise<{ success: boolean; supabaseAuthId?: string; error?: string }> {
  try {
    let authId: string | undefined;
    const cleanEmail = user.email.toLowerCase().trim();

    // 1. If password provided, attempt Supabase Auth signUp
    if (plainPassword && cleanEmail) {
      try {
        const { data: authData, error: authErr } = await supabaseServer.auth.signUp({
          email: cleanEmail,
          password: plainPassword,
          options: {
            data: {
              name: user.name,
              phone: user.phone || null,
              role: user.role,
            },
          },
        });

        if (!authErr && authData?.user) {
          authId = authData.user.id;
        } else if (authErr) {
          // If already registered, not an issue; continue to profile upsert
          if (!authErr.message.toLowerCase().includes('already registered')) {
            console.warn('[Supabase Auth Sync]:', authErr.message);
          }
        }
      } catch (err: any) {
        console.warn('[Supabase Auth Sync Warn]:', err.message);
      }
    }

    // 2. Save in public.users
    try {
      const userPayload: Record<string, any> = {
        name: user.name,
        email: cleanEmail,
        phone: user.phone || null,
        role: user.role,
        updated_at: new Date().toISOString(),
      };
      if (authId) {
        userPayload.id = authId;
      } else if (user.id && !user.id.startsWith('user-')) {
        userPayload.id = user.id;
      }

      const { data: upsertData, error: upsertErr } = await supabaseServer
        .from('users')
        .upsert(userPayload, { onConflict: 'email' })
        .select('id')
        .maybeSingle();

      if (!authId && upsertData?.id) {
        authId = upsertData.id;
      }
      if (upsertErr) {
        console.warn('[Supabase public.users upsert warn]:', upsertErr.message);
      }
    } catch (err: any) {
      console.warn('[Supabase public.users upsert err]:', err.message);
    }

    return { success: true, supabaseAuthId: authId };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

/**
 * Fetches a user record directly from Supabase public.users by email
 */
export async function fetchUserFromSupabaseByEmail(email: string): Promise<any | null> {
  try {
    const cleanEmail = email.toLowerCase().trim();
    const { data, error } = await supabaseServer
      .from('users')
      .select('*')
      .eq('email', cleanEmail)
      .maybeSingle();

    if (error) {
      console.warn('[Supabase User] Aviso ao procurar utilizador por email:', error.message);
      return null;
    }
    return data;
  } catch (err: any) {
    console.warn('[Supabase User] Erro ao procurar utilizador por email:', err.message);
    return null;
  }
}

/**
 * Fetches a user record directly from Supabase public.users by ID
 */
export async function fetchUserFromSupabaseById(id: string): Promise<any | null> {
  try {
    const { data, error } = await supabaseServer
      .from('users')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      return null;
    }
    return data;
  } catch {
    return null;
  }
}

/**
 * Fetches store settings directly from Supabase public.store_settings
 */
export async function fetchStoreSettingsFromSupabase(): Promise<Partial<StoreSettings> | null> {
  try {
    const { data, error } = await supabaseServer
      .from('store_settings')
      .select('*')
      .eq('id', 'default')
      .maybeSingle();

    if (error || !data) {
      return null;
    }

    return {
      storeName: data.store_name || undefined,
      whatsappNumber: data.whatsapp_number || undefined,
      supportPhone: data.support_phone || undefined,
      email: data.email || undefined,
      address: data.address || undefined,
      city: data.city || undefined,
      country: data.country || undefined,
      currency: data.currency || undefined,
      defaultShippingFee: data.default_shipping_fee !== null ? Number(data.default_shipping_fee) : undefined,
      freeShippingMinAmount: data.free_shipping_min_amount !== null ? Number(data.free_shipping_min_amount) : undefined,
    };
  } catch (err: any) {
    console.warn('[Supabase Settings] Aviso ao carregar configurações:', err.message);
    return null;
  }
}

/**
 * Synchronizes store settings with Supabase public.store_settings
 */
export async function syncStoreSettingsToSupabase(
  settings: Partial<StoreSettings>
): Promise<{ success: boolean; error?: string }> {
  try {
    const payload: Record<string, any> = {
      id: 'default',
      updated_at: new Date().toISOString(),
    };

    if (settings.storeName !== undefined) payload.store_name = settings.storeName.trim();
    if (settings.whatsappNumber !== undefined) payload.whatsapp_number = settings.whatsappNumber.replace(/\D/g, '');
    if (settings.supportPhone !== undefined) payload.support_phone = settings.supportPhone.trim();
    if (settings.email !== undefined) payload.email = settings.email.trim();
    if (settings.city !== undefined) payload.city = settings.city.trim();
    if (settings.country !== undefined) payload.country = settings.country.trim();
    if (settings.currency !== undefined) payload.currency = settings.currency.trim();
    if (settings.defaultShippingFee !== undefined) payload.default_shipping_fee = Number(settings.defaultShippingFee);
    if (settings.freeShippingMinAmount !== undefined) payload.free_shipping_min_amount = Number(settings.freeShippingMinAmount);
    if (settings.address !== undefined) payload.address = settings.address.trim();

    // 1. Try upserting with all fields including address
    let { error } = await supabaseServer
      .from('store_settings')
      .upsert(payload, { onConflict: 'id' });

    // 2. If 'address' column does not exist yet in Supabase schema cache, retry without it
    if (error && error.message.toLowerCase().includes('address')) {
      const fallbackPayload = { ...payload };
      delete fallbackPayload.address;
      const retry = await supabaseServer
        .from('store_settings')
        .upsert(fallbackPayload, { onConflict: 'id' });
      error = retry.error;
    }

    if (error) {
      console.warn('[Supabase Settings] Erro ao sincronizar configurações:', error.message);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

