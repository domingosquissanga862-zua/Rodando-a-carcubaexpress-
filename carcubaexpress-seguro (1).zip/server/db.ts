import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type { User, Product, Category, Order, Expense, StoreSettings } from './types.js';

export interface DatabaseSchema {
  users: User[];
  categories: Category[];
  products: Product[];
  orders: Order[];
  expenses: Expense[];
  settings: StoreSettings;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

function hashWithSalt(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

export const initialCategories: Category[] = [
  { id: 'perfumaria', name: 'Perfumaria & Fragrâncias', slug: 'perfumaria', icon: 'Sparkles', description: 'Perfumes originais Lattafa e fragrâncias premium' },
  { id: 'audio', name: 'Áudio & Gravação', slug: 'audio', icon: 'Headphones', description: 'Microfones wireless de lapela e tecnologia sonora' },
  { id: 'cat-eletronicos', name: 'Eletrónicos & Som', slug: 'eletronicos-som', icon: 'Headphones', description: 'Microfones wireless, auscultadores e acessórios de tecnologia' },
  { id: 'cat-beleza', name: 'Beleza & Cuidados', slug: 'beleza-cuidados', icon: 'Sparkles', description: 'Perfumes árabes de luxo e cuidados pessoais' },
  { id: 'cat-moda-fem', name: 'Moda Feminina', slug: 'moda-feminina', icon: 'Shirt', description: 'Vestidos, conjuntos de alfaiataria, saias de cetim e bodys' },
  { id: 'cat-moda-masc', name: 'Moda Masculina', slug: 'moda-masculina', icon: 'UserCheck', description: 'T-shirts básicas em algodão e camisas' },
  { id: 'cat-bolsas', name: 'Bolsas & Pastas', slug: 'bolsas-pastas', icon: 'Briefcase', description: 'Pastas térmicas duplas e bolsas masculinas' },
  { id: 'cat-casa', name: 'Casa & Conforto', slug: 'casa-conforto', icon: 'Home', description: 'Pijamas e utilidades domésticas' },
];

export const initialProducts: Product[] = [];

export const initialSettings: StoreSettings = {
  storeName: 'CarcubaExpress Comércio',
  storeDescription:
    'A sua loja online de referência em Luanda, Angola. Tecnologia, eletrónicos, microfones profissionais, perfumes árabes originais, moda feminina e artigos para o lar com entrega rápida.',
  whatsappNumber: '244951556411', // Official Luanda WhatsApp contact: +244 951 556 411
  supportPhone: '+244 951 556 411',
  email: 'carcubaexpress@gmail.com',
  address: 'Luanda, Angola (Entregas ao domicílio)',
  city: 'Luanda',
  country: 'Angola',
  currency: 'Kz',
  currencySymbol: 'Kz',
  defaultShippingFee: 0,
  freeShippingMinAmount: 40000,
  deliveryMunicipalities: [
    { name: 'Luanda (Ingombota, Maianga, Rangel, Sambizanga)', fee: 0, estimatedHours: '' },
    { name: 'Talatona (Benfica, Morro Bento, Camama)', fee: 0, estimatedHours: '' },
    { name: 'Belas (Kilamba, Centralidade do Kilamba)', fee: 0, estimatedHours: '' },
    { name: 'Kilamba Kiaxi (Golf 1 e 2, Palanca)', fee: 0, estimatedHours: '' },
    { name: 'Viana (Zango 1 a 4, Estalagem, Vila)', fee: 0, estimatedHours: '' },
    { name: 'Cazenga (Hoji-ya-Henda, Tala Hady)', fee: 0, estimatedHours: '' },
    { name: 'Cacuaco (Vila, Sequele, Kifangondo)', fee: 0, estimatedHours: '' },
    { name: 'Icolo e Bengo (Catete)', fee: 0, estimatedHours: '' },
    { name: 'Quiçama', fee: 0, estimatedHours: '' },
  ],
  deliveryPolicyTitle: 'Entregas em Luanda & Municípios',
  deliveryPolicyText:
    'Realizamos entregas rápidas ao domicílio em todos os municípios de Luanda (Talatona, Kilamba, Maianga, Viana, Cazenga, Cacuaco e arredores). O estafeta entra em contacto por telefone ou WhatsApp antes da deslocação para confirmar a sua localização e ponto de referência.',
  paymentPolicyTitle: 'Formas de Pagamento (Apenas Dinheiro e Express)',
  paymentPolicyText:
    'Garantimos total segurança na sua compra. O pagamento é realizado apenas no acto da entrega: aceitamos Dinheiro em mão ou transferência por Multicaixa Express na presença do estafeta após verificar e aprovar a sua encomenda.',
  termsPolicyTitle: 'Termos e Condições de Compra',
  termsPolicyText:
    'Todos os produtos comercializados pela CarcubaExpress dispõem de garantia de conformidade. O cliente tem o direito e o dever de inspecionar o produto no momento da entrega antes de efetuar o pagamento. Caso o artigo apresente alguma anomalia, procedemos à troca imediata.',
  supportPolicyTitle: 'Apoio ao Cliente & Contactos',
  supportPolicyText:
    'A nossa equipa de apoio ao cliente funciona de Segunda a Sábado das 08h00 às 19h00 via WhatsApp comercial oficial (+244 951 556 411) ou por chamada telefónica direta.',
  footerDepartments: [
    'Eletrónicos & Som',
    'Perfumaria & Fragrâncias',
    'Moda Feminina & Vestuário',
    'Bolsas & Acessórios',
    'Beleza, Saúde & Cuidados',
    'Casa & Utilidades',
  ],
};

class Database {
  data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          users: parsed.users || [],
          categories: parsed.categories || initialCategories,
          products: Array.isArray(parsed.products) ? parsed.products : [],
          orders: parsed.orders || [],
          expenses: parsed.expenses || [],
          settings: { ...initialSettings, ...(parsed.settings || {}) },
        };
      } catch (err) {
        console.error('Erro ao ler base de dados, reinicializando:', err);
      }
    }

    // Initialize fresh with default administrator and sample orders
    const adminSalt = crypto.randomBytes(16).toString('hex');
    const adminHash = hashWithSalt('carcuba@2026', adminSalt);

    const initialUsers: User[] = [
      {
        id: 'user-admin-domingos',
        name: 'Domingos Quissanga',
        email: 'domingosquissanga862@gmail.com',
        phone: '+244 951 556 411',
        passwordHash: adminHash,
        salt: adminSalt,
        role: 'admin',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'user-client-1',
        name: 'Mateus Manuel',
        email: 'mateus.manuel@gmail.com',
        phone: '+244924112233',
        passwordHash: hashWithSalt('cliente123', adminSalt),
        salt: adminSalt,
        role: 'customer',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ];

    const initialOrders: Order[] = [];

    const initialExpenses: Expense[] = [];

    const initialData: DatabaseSchema = {
      users: initialUsers,
      categories: initialCategories,
      products: initialProducts,
      orders: initialOrders,
      expenses: initialExpenses,
      settings: initialSettings,
    };

    this.saveData(initialData);
    return initialData;
  }

  save() {
    this.saveData(this.data);
  }

  private saveData(data: DatabaseSchema) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Erro ao guardar base de dados:', err);
    }
  }

  resetToDefault() {
    this.data = this.load();
    this.save();
    return this.data;
  }
}

export const db = new Database();
