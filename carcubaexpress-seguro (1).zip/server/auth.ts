import crypto from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import { db } from './db.js';
import type { User } from './types.js';

// Secret for signing tokens. Define SESSION_SECRET no ambiente (valor longo e aleatório).
// Sem a variável, gera-se uma chave aleatória por arranque (as sessões do servidor local
// terminam ao reiniciar), em vez de usar uma chave fixa conhecida no código.
const SESSION_SECRET =
  process.env.SESSION_SECRET ||
  (() => {
    console.warn('[CarcubaExpress] SESSION_SECRET não definido: a usar chave aleatória temporária.');
    return crypto.randomBytes(48).toString('hex');
  })();

// In-memory session store cache mapped to token
const sessions = new Map<string, { userId: string; role: 'admin' | 'customer'; expiresAt: number }>();

export function hashPassword(password: string): { salt: string; hash: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return { salt, hash };
}

export function verifyPassword(password: string, salt: string, originalHash: string): boolean {
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === originalHash;
}

/**
 * Creates an HMAC-signed token that never expires upon server restarts
 */
export function createSession(user: User): string {
  const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 days
  const payload = Buffer.from(
    JSON.stringify({ userId: user.id, role: user.role, email: user.email, expiresAt })
  ).toString('base64url');
  const signature = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  const token = `${payload}.${signature}`;

  sessions.set(token, {
    userId: user.id,
    role: user.role,
    expiresAt,
  });

  return token;
}

/**
 * Validates a session token: checks memory cache or decodes and verifies cryptographic signature
 */
export function getSession(token: string): { userId: string; role: 'admin' | 'customer'; expiresAt: number } | null {
  if (!token || typeof token !== 'string') return null;

  // 1. Check in-memory session cache
  const cached = sessions.get(token);
  if (cached) {
    if (Date.now() > cached.expiresAt) {
      sessions.delete(token);
      return null;
    }
    return cached;
  }

  // 2. Verify and decode HMAC-signed token (survives dev server restarts!)
  try {
    const parts = token.split('.');
    if (parts.length === 2) {
      const [payload, signature] = parts;
      const expectedSignature = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
      if (signature === expectedSignature) {
        const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
        if (decoded.expiresAt && Date.now() < decoded.expiresAt) {
          const entry = {
            userId: decoded.userId,
            role: decoded.role as 'admin' | 'customer',
            expiresAt: decoded.expiresAt,
          };
          sessions.set(token, entry);
          return entry;
        }
      }
    }
  } catch {
    // Ignore invalid tokens
  }

  return null;
}

export function destroySession(token: string) {
  sessions.delete(token);
}

export interface AuthenticatedRequest extends Request {
  user?: User;
}

import { supabaseServer, fetchUserFromSupabaseById, fetchUserFromSupabaseByEmail } from './supabase.js';

export const ADMIN_EMAILS = [
  'domingosquissanga862@gmail.com',
];

export async function authenticate(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : (req.query.token as string);

  if (!token) {
    return next();
  }

  // 1. Try local HMAC session token
  const session = getSession(token);
  if (session) {
    let user = db.data.users.find(u => u.id === session.userId);

    // Fallback: look up in Supabase if not found locally
    if (!user) {
      try {
        const supaUser = await fetchUserFromSupabaseById(session.userId);
        if (supaUser) {
          const isStoreAdmin = (supaUser.email && ADMIN_EMAILS.includes(supaUser.email.toLowerCase())) || supaUser.role === 'admin';
          user = {
            id: String(supaUser.id),
            name: supaUser.name,
            email: supaUser.email,
            phone: supaUser.phone || '',
            passwordHash: '',
            salt: '',
            role: isStoreAdmin ? 'admin' : 'customer',
            createdAt: supaUser.created_at || new Date().toISOString(),
          };
          db.data.users.push(user);
          db.save();
        }
      } catch {
        // Continue
      }
    }

    if (!user && session.role === 'admin') {
      user = db.data.users.find(u => u.role === 'admin' || (u.email && ADMIN_EMAILS.includes(u.email.toLowerCase())));
    }

    if (user) {
      if (user.email && ADMIN_EMAILS.includes(user.email.toLowerCase().trim())) {
        user.role = 'admin';
      }
      req.user = user;
    }
    return next();
  }

  // 2. Try Supabase JWT access token (3 segments separated by dots)
  if (typeof token === 'string' && token.split('.').length === 3) {
    try {
      const { data, error } = await supabaseServer.auth.getUser(token);
      if (!error && data?.user) {
        const supaAuthUser = data.user;
        const email = supaAuthUser.email?.toLowerCase().trim();
        const isStoreAdmin = (email && ADMIN_EMAILS.includes(email)) || supaAuthUser.user_metadata?.role === 'admin';

        // Check local users first
        let user = db.data.users.find(u => u.id === supaAuthUser.id || (email && u.email.toLowerCase() === email));

        if (!user) {
          // Fetch profile from public.users
          const supaProfile = email ? await fetchUserFromSupabaseByEmail(email) : await fetchUserFromSupabaseById(supaAuthUser.id);
          const role: 'admin' | 'customer' = (isStoreAdmin || supaProfile?.role === 'admin') ? 'admin' : 'customer';

          user = {
            id: String(supaProfile?.id || supaAuthUser.id),
            name: supaProfile?.name || supaAuthUser.user_metadata?.name || email?.split('@')[0] || 'Cliente',
            email: email || '',
            phone: supaProfile?.phone || supaAuthUser.user_metadata?.phone || '',
            passwordHash: '',
            salt: '',
            role,
            createdAt: supaProfile?.created_at || supaAuthUser.created_at || new Date().toISOString(),
          };
          db.data.users.push(user);
          db.save();
        } else if (isStoreAdmin) {
          user.role = 'admin';
        }

        if (user) {
          req.user = user;
        }
      }
    } catch {
      // Ignore token verification errors
    }
  }

  next();
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Não autorizado. Inicie sessão para continuar.' });
  }
  next();
}

export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const userEmail = req.user?.email?.toLowerCase().trim();
  const isAuthorizedEmail = userEmail === 'domingosquissanga862@gmail.com';

  if (isAuthorizedEmail) {
    if (req.user) req.user.role = 'admin';
    return next();
  }

  // Check bearer token in session cache
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : (req.query.token as string);
  if (token) {
    const session = getSession(token);
    if (session?.role === 'admin') {
      const u = db.data.users.find(usr => usr.id === session.userId);
      if (u?.email?.toLowerCase().trim() === 'domingosquissanga862@gmail.com') {
        return next();
      }
    }
  }

  return res.status(403).json({
    error: 'Acesso restrito. Apenas o email Domingosquissanga862@gmail.com tem permissão de administrador.',
  });
}
